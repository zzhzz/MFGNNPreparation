#include<stdio.h>

int main()

{
	int test,temp=0;
	long i,j,size,count;
	long long int ar[100000];
	scanf("%d",&test);
	while(temp<test)
	{
		scanf("%ld",&size);
		count=size;
		for(i=0;i<size;i++)
		scanf("%lld",&ar[i]);
		
		for(i=0;i<size;i=j+1)
		{
		
			j=i;
			while(ar[j]<=ar[j+1])
			j++;
			int k=j-i+1;
			count+=((k*(k-1))/2);
		}
		printf("%ld",count);
		temp++;
	}
	return 0;
}
	