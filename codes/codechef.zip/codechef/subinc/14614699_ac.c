#include <stdio.h>

int main(void) {
	int t;
	scanf("%d",&t);
	while (t--){
		int n, i;
		scanf("%d",&n);
		if (n==1)	printf("1\n");
		else {
			long long int a[n];
			
			for (i = 0; i < n; i++)
				scanf("%lld",&a[i]);
			long long int b[n];
			for (i = 0; i < n; i++)
				b[i] = 1;
			
			for ( i = 1; i < n; i++) {
				if (a[i] >= a[i-1])
				b[i] = b[i-1]+b[i];
				
			}
			long long int sum = 0;
			for (i = 0; i < n; i++)
				sum += b[i];
			printf("%lld\n",sum);	
		}
	} 
return 0;
}
