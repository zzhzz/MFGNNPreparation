#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,i,j;
        scanf("%d",&n);
        long int a[n];
        for(i=0;i<n;i++)
            scanf("%ld",&a[i]);
        int count=0,x=1;
        for(i=1;i<n;i++)
        {
            if(a[i]>=a[i-1])
                x++;
            else
            {
                count+=x*(x+1)/2;
                x=1;
            }
        }
        count+=x*(x+1)/2;
        printf("%d\n",count);
    }
}
