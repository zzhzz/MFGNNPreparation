#include<stdio.h>
 
int main(void)
{
	int t,count = 0,temp = 1;
	long int n;
	int i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		long long int a[n];
		scanf("%lld",&a[0]);
		if(n==1)
		count = n;
		for(i = 1; i < n; i++)
		{
			scanf("%lld",&a[i]);
			if(a[i-1] > a[i])
			{
				count = count +(((temp * temp) - temp) / 2);
				temp = 1;
			}
			else
			{
				temp++;
			
			}
		
		}
		if(temp!=1 && i == n-1)
 		count = count +(((temp * temp) - temp) / 2);
		printf("%d",count);
	
	}
 
 
 
 
	return 0;
} 