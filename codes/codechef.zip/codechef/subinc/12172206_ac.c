#include <stdio.h>

typedef long long int ll;

int main()
{
    int t;
    scanf("%d", &t);
    while(t--){
        int n;
        scanf("%d", &n);
        int arr[100001];
        int i, j;
        ll ans = 0, x = 0;
        
        for(i=1; i <= n; i++)
            scanf("%d", &arr[i]);
        
        for(i=1; i <= n; i++){
            int flag = 1;
            for(j=i; j <= n && flag; j++){
                if(arr[j] <= arr[j+1])
                    x++;
                
                else{
                    ans += (x * (x+1))/2;
                    i = j;
                    x = 0;
                    flag = 0;
                }
            }
        }
        
        printf("%lld\n", ans+n);
        
    }
    
}