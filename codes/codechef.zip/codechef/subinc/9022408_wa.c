#include<stdio.h>
int main()
{int N,index,count=0,pos=0,f=0;
	int t,i;long long int ar[N];
	scanf("%d",&t);
	while(t-->0)
	{ scanf("%d",&N);
		count=N;
		f=0;
	   for(i=0;i<N;i++)
	   {
	   	scanf("%lld",&ar[i]);
	   }// array has been entered
	   
	   for(i=0;i<N-1;i++)
	   {    index=i;
	     	while(1==1)
	     	{
	     		if(ar[index+1]>=ar[index]) { f=1;pos=index+1;index++;
	     									if(index>=N-1) break;
	     								  }
	     		else break;
	     	}
	     	if(f==1) {count+=(pos-i)*(pos-i+1)/2;}
	     	i=pos;
	     	f=0;
	   }
	   printf("%d\n",count);

	}
	return 0;
}