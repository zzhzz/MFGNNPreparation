#include <stdio.h>
#include <stdlib.h>

int cnt(int*, int);

int main(void) {
	int t, s, i, *a = NULL;

	scanf("%d", &t);
	while(t--) {
		scanf("%d", &s);
		a = malloc(sizeof(int) * s);
		for(i = 0; i < s; i++)
			scanf("%d", a + i);
		printf("%d\n", cnt(a, s));
		free(a);
	}

	return 0;
}

int cnt(int *a, int n) {
	int i, r = 0;
	for(i = 0; i + 1 < n; i++)
		if(a[i] <= a[i + 1]) r++;
	return r + n;
}