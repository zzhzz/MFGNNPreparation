#include<stdio.h>
#define MAX 100005
int a[MAX];
main()
{
	int t,count,ans,n,i;
	scanf("%d",&t);
	while(t--)
	{
	    ans=0;
		scanf("%d",&n);
		for(i=0;i<n;++i)
			scanf("%d",&a[i]);
		for(i=0;i<n;++i)
		{
			count=1;
			while(a[i]<a[i+1])
			{
				count++;
				i++;
			}
			for(count;count>0;--count)
				ans+=count;
		}
		printf("%d\n",ans);
	}
	return 0;
}
