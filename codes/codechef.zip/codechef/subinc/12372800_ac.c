#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[])
{
	int t;
	scanf("%d", &t);
	while(t-- ) {
		int i, n, a, c, num, old;
		scanf("%d", &n);
		for(i = 0, a = 0; i < n ; i++) {
			scanf("%d", &num);
			if(i == 0) {
				old = num;
				c = 1;
			}
			else if(old > num) {
				a += (c * (c + 1) / 2);
				c = 1;
			} else {
				c++;
			}
			old = num;
		}
		a += (c * (c + 1) / 2);
		printf("%d\n", a);
	}
	return 0;
}