#include<stdio.h>
int main( )
{
int t,n,i,k,a[100000];
scanf("%d",&t);
while(t--)
{
int k=0;
scanf("%d",&n);
for(i=0;i<n;i++)
scanf("%d",&a[i]);
for(i=0;i<n;i++)
if(a[i+1]>=a[i])
k++;
printf("%d\n",k+n);
}
return 0;
}
