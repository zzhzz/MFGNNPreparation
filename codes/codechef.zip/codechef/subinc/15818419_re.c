#include<stdio.h>
#include<string.h>
int main()
{
       int T;
       scanf("%d",&T);
       while(T--)
       {
             int N,p=0,j;
             scanf("%d",&N);
             int i,a[N];
             for(i=0;i>N;i++)
             {
                    scanf("%d",a[i]);
             }
             for(j=0;j<N-1;j++)
             {
                    if(a[j]<=a[j+1])
                    p++;
             }
             printf("%d\n",p+N);
       }
       return 0;
       
}
