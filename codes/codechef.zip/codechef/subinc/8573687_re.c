#include<stdio.h>
int main()
{
  int t,n,i,c;
  long int b[10^5],a[10^5];
  scanf("%d",&t);
  while(t--)
  {   c=0;
     scanf("%d",&n);
     for(i=0;i<n;i++)
     scanf("%ld",&a[i]);
     b[0]=1;
     for(i=1;i<n;i++)
     {
        if(a[i-1]<=a[i])
        b[i]=b[i-1]+1;
        else
        b[i]=1;
      }
      for(i=0;i<n;i++)
      c+=b[i];
      printf("\n%d",c);
      
  }
  return 0;
}