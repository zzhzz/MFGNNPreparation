#include<stdio.h>
#include<stdlib.h>
int main()
{
   long long i=1,j=1,n,count,num,prev,pres,t;
   // printf("enter the size  of array and value of k\n ");
    
    scanf("%lld",&t);
    while(t--){
    scanf("%lld",&n);
    scanf("%lld",&num);
    prev=num;
    i=1;
    j=1;
    count=0;
    while(i<n)
    {
    
       scanf("%lld",&num);
       
       if(num>=prev)
       {
          prev=num;
          j++;
          i++;
         
       }   
       else
       {
       prev=num;
       i++;
       count=count+j*(j+1)/2;
       j=1;
       
       }
   }
   count=count+j*(j+1)/2;
   printf("%lld",count);
  }
   return 0;
   }
