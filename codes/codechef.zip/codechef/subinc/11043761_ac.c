#include <stdio.h>
long sum(long);
int main(){
	long t, n, arr[100000]={}, i, j, count;
	scanf("%ld", &t);
	while(t--){
		count = 0;
		scanf("%ld", &n);
		for(i = 0; i < n; i++)
			scanf("%ld", &arr[i]);
		for(i = 0; i < n; i++){
			j = 1;
			while ((arr[i] <= arr[i+1]) && (i + 1 < n)){
				i++;
				j++;
			}
			count += sum(j);	
		}
		printf("%lld\n", count);
	}
	return 0;
}
long sum(long n){
	long s;
		s = n*(n+1)/2;  
	return s; 
}