#include<stdio.h>
int main()
{
int t,a[5],i=0,j;
scanf("%d",&t);
while(t--)
{
int n,b[1000],k,count=0,l,big;
scanf("%d",&n);
for(k=0;k<n;k++)
scanf("%d",&b[k]);
for(k=0;k<n;k++)
{
count++;
big=b[k];
for(l=k+1;l<n;l++)
{
if(b[l]>=big)
{
big=b[l];
count++;
}
}
}
a[i]=count;
i++;
}
for(j=0;j<i;j++)
printf("%d\n",a[j]);
return 0;
}
