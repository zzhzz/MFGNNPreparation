#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h> 

#define max(a, b) a > b? a : b
#define min(a, b) a < b? a : b

int main()
{
	int t, N, A[50], i, j, k, sum, product, count, flag;
	scanf("%d", &t);
	
	while(t--)
	{
		scanf("%d", &N);
		
		for(i = 0; i < N; i++)
			scanf("%d", &A[i]);

		count = 0;

		for(i = 0; i < N; i++)
		{
			for(j = i; j < N; j++)
			{
				flag = 1;

				for(k = i; k < j; k++)
				{
					if(A[k] > A[k+1])
					{
						flag = 0;
						break;
					}
				}
				if(flag == 1)
					count++;
			}
		}
		printf("%d\n", count);
	}

	return 0;
}
