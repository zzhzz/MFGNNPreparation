
#include<stdio.h>
#include<stdlib.h>

void main()
{
int N;int T;int t[5];
int *a;int i;int j;
scanf("%d \n",&T);int c=0;int k=0;
while(T>0)
    {
        scanf("%d \n",&N);
        a=(int *)malloc((N+1)*sizeof(int));
        c=0;
        for(i=0;i<N;i++)
        {
            scanf("%d ",&a[i]);
        }
        /*for(i=0;i<N;i++)
        {
            printf("%d ",a[i]);
        }*/
        int length=0;
        for(i=0;i<N;i++)
        {
           // printf("%d \n",a[i]);
             if(a[i]<=a[i+1] )
            {

                length++;
                if(i+1==N)
                {
                c+=(length)*(length-1)/2;
                }

            }
            else
            {
               length++;
                c+=(length)*(length-1)/2;
                length=0;
            }
        }  
        
    c+=N;    
    printf("%d \n",c);
    T--;
    }
    
}
