#include<stdio.h>
#include<stdlib.h>


int main()
{
    int t;
    scanf("%d",&t);
    while(t!=0){
        unsigned long long int n;
        scanf("%llu",&n);
        int *a=malloc(n*sizeof(int));
        unsigned long long int i,s=0,k;
        
        for(i=0,k=0;k<n;i++,k++){
            scanf("%d",&a[i]);
            if(i!=0){
                if(a[i-1]<=a[i]);
                else{
                    s=s+(i*(i+1))/2;

                    a[0]=a[i];
                    i=0;    
                    }        
            }
        }
         s=s+(i*(i+1))/2;
        printf("%llu\n",s);
    t--;
    }
}