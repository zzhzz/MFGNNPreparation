#include<stdio.h>
int main()
{
    int t,n,a[100000],b,i,j,k,s,p;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        b=0;
        scanf("%d",&n);
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[j]);
        }
        for(j=0;j<n;j++)
        {
            p=0;
            s=a[j];
            for(k=j+1;k<n;k++)
            {
                if(s<=a[k])
                {
                    s=a[k];
                    b++;
                }
                else
                {
                    break;
                }
            }
        }
        printf("%d\n",b+n);
    }
    return 0;
}
