#include<stdio.h>
int main()
{
    int t,i,n,j,flag=1,k,temp;
    unsigned int a[100000];
    unsigned long long int sum;
    scanf("%d",&t);
    if(t>=1 && t<=5)
    {
        for(i=0;i<t;i++)
        {
            scanf("%d",&n);
            sum=(unsigned long long int)n;
            flag=1;
            if(n>=1 && n<=100000)
            {
                for(j=0;j<n;j++)
                {
                    scanf("%u",&a[j]);
                    if(!(a[i]<=1000000000 && a[i]>=1))
                    flag=2;

                }
                if(flag==1)
                {
                    j=0;
                    while(j<n)
                    {
                        temp=0;
                        k=j;
                        while(a[k+1]>=a[k]&& k<(n-1))
                        {
                            temp++;
                            k++;
                        }
                        if(k<=(n-1))
                        {
                            j=k+1;
                            if(temp>=1)
                            sum+=(unsigned long long int)((unsigned long long int)((double)temp/2.0)*(unsigned long long int)((double)temp+1.0));

                        }
                        else
                        break;
                    }
                }
            }
            printf("%llu\n",sum);
        }
    }
    return 0;
}
