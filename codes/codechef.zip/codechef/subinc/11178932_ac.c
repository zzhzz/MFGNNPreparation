#include <stdio.h>

int main(void) {
	int t,i,j;
	long int n,a[100002],k;
	char c;
	t=0;
	c=getchar();
	while((c<'0')||(c>'9'))
	c=getchar();
	while((c>='0')&&(c<='9'))
	{
		t=t*10+(c-'0');
		c=getchar();
	}
	while(t--)
	{
	    n=0;
	    while((c<'0')||(c>'9'))
	    c=getchar();
	    while((c>='0')&&(c<='9'))
	    {
	    	n=n*10+(c-'0');
	    	c=getchar();
	    }
	    k=0;
	    for(i=0;i<n;i++)
	    {
	        a[i]=0;
	        while((c<'0')||(c>'9'))
	        c=getchar();
	        while((c>='0')&&(c<='9'))
	        {
	        	a[i]=a[i]*10+(c-'0');
	        	c=getchar();
	        }
	        k++;
	        for(j=i-1;j>=0;j--)
	        {
	            if(a[j]<=a[j+1])
	            k++;
	            else
	            break;
	        }
	    }
	    printf("%d\n",k);
	}
	return 0;
}