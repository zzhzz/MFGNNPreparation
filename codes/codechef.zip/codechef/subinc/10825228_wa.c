#include <stdio.h>
int main() 
{
    int n,i,x=0,c=0,t=0;
    scanf("%d",&t);
    while(t--)
    {        
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        for(i=0;i<n-1;i++)
        { 
            if(a[i]<=a[i+1])
            {
                x++;
                c=c+x;
            }
            else
                x=0;
        }
        if(n!=1)
            printf("%d\n",n+c);
        else 
            printf("1");
        
    }
    return 0;
}