#include <stdio.h>

int main(void) {
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int i,n;
		scanf("%d",&n);
		long long int a[n],c=2,k=0;
		for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
		if(n==1) {printf("1\n");break;}
		for(i=0;i<n-1;i++)
		{  
			   
				if(a[i]<=a[i+1]) c+=(i+2)-k;
				else k=i+1;
			
		}
		printf("%lld\n",c);
	}
	return 0;
}
