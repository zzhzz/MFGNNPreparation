#include<stdio.h>

int main(void)
{
	int t,n,i;

	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		int x,y,counter;
		scanf("%d",&y);
		counter=0;
		for(i=1;i<n;i++)
		{
			x=y;
			scanf("%d",&y);
			while(x<=y)
			{
					counter++;
					x=y;
					if(++i==n)break;
					scanf("%d",&y);

			}
		}
		printf("%d\n",n+counter);
	}

	return 0;

}
