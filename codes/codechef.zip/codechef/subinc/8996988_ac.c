#include<stdio.h>
int main()
{
	int t;
	long long int n,j,count,ans;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		long long int a[n];
		count=0,ans=0;
		for(j=0;j<n;j++)
		{
			scanf("%lld",&a[j]);
		}
	
			for(j=1;j<n;j++)
			{
				if(a[j]>=a[j-1])
				{
					count++;
					if(j==n-1)
						ans+=count*(count+1)/2;
				}
				else
				{
				ans+=count*(count+1)/2;
				count=0;	
				}	
			}
		printf("%lld\n",ans+n);
	}
	return 0;
}