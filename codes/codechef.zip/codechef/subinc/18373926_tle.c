#include<stdio.h>

int main()
{
    int tc;
    int d[100000];
    scanf("%d",&tc);
    while(tc--)
    {
        int n,count=0,i,j,k,flag=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            scanf("%d",&d[i]);
        }
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                flag=0;
                for(k=i;k<j;k++)
                {

                       if(d[k]<d[k+1])
                       {
                           flag++;
//                           break;
                       }
                       else
                        break;
                }
                if(flag==0)
                    count++;

            }
        }
        printf("%d\n",count+n);
    }
    return 0;
}
