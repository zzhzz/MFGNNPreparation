#include<stdio.h>

int main ( void )
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long n;
		scanf("%ld", &n);
		int i;
		long arr[n];
		for ( i = 0 ; i < n ; i++ ) scanf("%ld", arr+i );
		int count = n, start = 0, end = 1;
		while( end != n )
		{
			if( arr[end] >= arr[end-1] )	count += end-1;
			else start = end;
			end++;
		}
		
		printf("%d", count);
		printf("\n");
	}
return 0;
}
