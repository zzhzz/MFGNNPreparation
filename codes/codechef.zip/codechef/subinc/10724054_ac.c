#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,i;
		scanf("%d",&n);
		long int a[n],c=0;
		int b[n];
		for(i=0;i<n;i++)
		{
			scanf("%ld",&a[i]);
			b[i]=1;
		}
		for(i=n-2;i>=0;i--)
		{
			if(a[i]<=a[i+1])
			{
				b[i]=b[i]+b[i+1];
			}
		}
		for(i=0;i<n;i++)
		{
			c=c+b[i];
		}
		printf("%ld\n",c);
	}
	return 0;
} 