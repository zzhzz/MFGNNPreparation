#include <stdio.h>
#include <stdlib.h>
int subArrCount = 0;
int *arr;
/*
void countCurrentSubarr(int LoopStart, int size)
{
	int i;
	subArrCount++;
	for (i = LoopStart; i < size-1; i++)
	{
		if (arr[i] < arr[i + 1])
		{
			subArrCount++;
    	}
		else
			return;
	}

}
*/
int getdata()
{
	int arrSize, i;
	scanf("%d", &arrSize);
	arr = (int*)malloc(sizeof(int)*arrSize);
	for (i = 0; i < arrSize; i++)
	{
		scanf("%d", &arr[i]);
		while (arr[i] == ' ' || arr[i] == '\n')
			scanf("%c", &arr[i]);

	}
	return arrSize;
}

int main(void)
{
	int totalTest, testLoop, arrSize, arrLoop;
	int i;
//	FILE *Fp;
//	freopen("d:\\UGC\\decreasingSubarray.txt", "rt", stdin);
	setbuf(stdout, NULL);

	scanf("%d", &totalTest);
	for (testLoop = 0; testLoop < totalTest; testLoop++)
	{
		arrSize = getdata();
		for (arrLoop = 0; arrLoop < arrSize; arrLoop++)
		{
			//countCurrentSubarr(arrLoop,arrSize);
			subArrCount++;
			for (i = arrLoop; i < arrSize - 1; i++)
			{
				if (arr[i] < arr[i + 1])
				{
					subArrCount++;
				}
				else
					return;
			}
		}
		printf("%d\n", subArrCount);
		subArrCount = 0;
		free(arr);
	}
}