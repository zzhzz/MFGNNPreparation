#include<stdio.h>
int main()
{
 int t,i,j,n;
 scanf("%d",&t);
 while(t--)
 {
  scanf("%d",&n);
  long long int a[n],fact=1;
  int k=n;
  for(i=0;i<n;i++)
  scanf("%lld",&a[i]);
   for(i=0;i<n-1;i++)
    {
     for(j=1;j<n;j++)
     { 
      if(a[i]<a[j])
       k++;
     }
    } 
   while(k>0)
   { fact=(fact*k);
     k--;
   } 
  printf("%d\n",fact+n);
 }
return 0;
}