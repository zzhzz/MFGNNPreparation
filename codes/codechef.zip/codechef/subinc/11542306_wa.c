#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int compare(const void *a,const void *b)
{
	return (*(int*)a - *(int*)b);
}

int main() {
	int TestCaseCount,ArraySize,i,j,k,TotalCombinations;
	int Resultarray[100000]={0};
	
	scanf("%d",&TestCaseCount);
	while(TestCaseCount--)
	{
		int ArrayMatrix[100000]={0};
		scanf("%d",&ArraySize);
		
		for(i=0;i<ArraySize;i++)
		scanf("%d",&ArrayMatrix[i]);
		
		qsort(ArrayMatrix,ArraySize,sizeof(int),compare);
		
		TotalCombinations=0;
		
		for(i=1;i<ArraySize;i++)
		{
			//printf("the value at the index %d is %d\n",i,ArrayMatrix[i]);
			TotalCombinations = TotalCombinations + (ArraySize-i);
		}
		//printf("\n");
		printf("%d\n",TotalCombinations);
	}
	return 0;
}