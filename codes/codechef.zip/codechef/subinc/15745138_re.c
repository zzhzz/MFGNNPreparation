#include<stdio.h>
int main(){
	int t,i,j,c=0,n,temp;
	long long int a[10000];
	scanf("%d",&t);
	while(t>0){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%lld",&a[i]);
		}
		for(i=0;i<n;i++){
			temp=i;
			for(j=i;j<n;j++){
				if(a[temp]<=a[j]){
					c++;
					temp=j;
				}else{
					break;
				}
			}
		}
		printf("%d\n",c);
		c=0;
		t--;
	}
}