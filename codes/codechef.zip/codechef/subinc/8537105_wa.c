#include<stdio.h>
int main()
{
	
	int i,j,t,c=0; 
	long int n; 
   	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		long long int a[n];
		for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
		c=n;
		for(i=0;i<n;i++)
           {
            for(j=i+1;j<n;j++)
            {
 
                if(a[j-1]<=a[j])
                c++;
                else
                break;
            }
 
          }
		printf("%d",c);
	}
	
	
	return 0;
}