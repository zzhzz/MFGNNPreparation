#include<stdio.h>
int main()
{
   long i,j,a[10],n,count,k;
   int t,m=1;
   printf("Enter the number of test cases");
   scanf("%d",&t);
   while(m<=t)
   {
     count=0;
     printf("Enter the size of an array");
     scanf("%ld",&n);
     printf("\nEnter the array elements");
     for(i=0;i<n;i++)
       scanf("%ld",&a[i]);
     for(i=0;i<n;i++)
     {
	k=i;
	for(j=i;j<n;j++)
	{
	  if(a[k]<=a[j])
	  {
	    count++;
	    k=j;
	  }
	  else
	    break;
       }
     }
     printf("The no. of subarrays are:%ld\n",count);
     m++;
   }
   return 0;
}
