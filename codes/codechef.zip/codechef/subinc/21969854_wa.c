#include<stdio.h>

int main(){

    int a[100002], t, n, i, j, k;

    scanf("%d\n",&t);

    for(i = 0; i < t; i++){

        scanf("%d",&n);

        long long ans = 0;

        for(j = 0; j < n; j++){

            scanf("%d",&a[j]);
        }
        k = 1;

        for(j = 1; j < n; j++){

            if(a[j] >= a[j - 1]){

                k++;
            }
            else{

                ans = ans + (long long)(k*(k + 1)/2);

                k = 1;

                a[j] = 0;
            }
        }
        ans = ans + (long long)(k*(k + 1)/2);

        printf("%lld\n",ans);
    }
    return 0;
}
