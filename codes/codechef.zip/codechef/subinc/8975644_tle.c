#include <stdio.h>
#include <stdlib.h>
void main()
{
int cases,n,i,j,t,ans;
i=j=0;
t=1;
long temp1,temp2;
scanf("%d",&cases);
for(;i<cases;i++)
{
	scanf("%d",&n);
	ans=0;
	t=1;
	scanf("%li",&temp1);
	for(;j<n-1;j++)
	{
		scanf("%li",&temp2);
		if(temp1<=temp2)
			t++;
		else
		{
			ans+=t*(t+1)/2;
			t=1;
		}
		temp1=temp2;
	}
	ans+=t*(t+1)/2;
	printf("%d\n",ans);
}
}