#include<stdio.h>
#include<stdlib.h>
int main()
{
	int t;
	scanf("%d",&t);
	int i,j;
	int n,*array;
	int s,count;
	while(t--)
	{
		scanf("%d",&n);
		array=(int*)malloc(sizeof(int)*n);
		for(i=0;i<n;i++)
		{
			scanf("%d",&array[i]);
		}
		s=0;
		count=0;
		i=0;
		j=0;
		while(i<n)
		{
			count=1;
			for(j=i;j<n-1;j++)
			{
				//printf("i=%d    j=%d\n",i,j);
				if(array[j+1]>=array[j])
				{
			        //printf("count=%d\n",count);
					count++;
				}
				else
				{
					break;
				}
			}
			s=s+(count*(count+1)/2);
			i=j+1;
		}
		printf("%d\n",s);
	}
}