#include<stdio.h>
int main()
{
int cf,cf2,n,i=0,*p,x,count=0,ch;
scanf("%d",&ch);
while(ch!=0)
{
scanf("%d",&n);
p=(int*)malloc(n*sizeof(int));
while(i!=n)
  {
    scanf("%d",&p[i]);
    i++;
  }

cf=n-1;
while(cf!=0)
  {
    x=0;
    while(x<(n-cf))
      {
	i=x;
	cf2=0;
	while(i<=(cf+x-1))
	  {
	    if(p[i]<=p[i+1])
	      cf2++;
	    i++;
	  }
	if(cf==cf2)
	  count++;
	x++;
      }

    cf--;
  }
printf("\n%d",(count+n));
ch--;
}
return 0;
}