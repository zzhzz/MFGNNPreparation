#include<stdio.h>
int main(void)
{
   long long  int t,n,ar[100012]={0},count[100010]={0};;
    scanf("%lld",&t);
    while(t--)
    {
        scanf("%lld",&n);
        long long int i=0;
        while(((i^n)!=0))
                {
                    scanf("%lld",&ar[i]);
                    i++;
                }
        i=0;
         count[0]=1;
        long long int k=0;
        while((i^n)!=0)
        {
            if(ar[i+1]>=ar[i])
            {
                count[k]++;
            }
            else
            {
            k++;
            count[k]=1;
            }
            i++;
        }
        i=0;
        long long int sum=0;
        while((i^k)!=0)
        {
            sum+=(count[i]*(count[i]+1))/2;
            i++;
        }
        printf("%lld\n",sum);
    }
    return 0;
}
