#include<stdio.h>
int main()
{
    int n,c,i,j;
    int t,k;
    scanf("%d",&t);
    int ans[t];
    for(k=1;k<=t;k++)
    {
    scanf("%d",&n);
    int ar[n];
    for(i=0;i<=n-1;i++)
    scanf("%d",&ar[i]);
    c=0;
    for(i=0;i<=n-1;i++)
    {
        c++;
        for(j=i+1;j<=n-1;j++)
        {
            if(ar[j]>ar[j-1])
                c++;
            else
                break;
        }
    }
    ans[k-1]=c;
    }
    for(i=0;i<=t-1;i++)
        printf("%d\n",ans[i]);
    return 0;
}
