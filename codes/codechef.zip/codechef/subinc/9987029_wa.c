#include<stdio.h>
#include<stdlib.h>
int main()
{
    int t,i,n,*a,j,x;
    scanf("%d",&t);
    for(i=0;i<t;++i)
    {
        x=0;
        scanf("%d",&n);
        a=(int *)malloc(sizeof(int)*n);
        for(j=0;j<n;++j)
            scanf("%d",a+j);
        for(j=0;j<n-1;++j)
        {
            if(*(a+j)<*(a+j+1))
            {
                while(*(a+j)<*(a+j+1))
                    ++j;
                ++x;
            }
        }
        printf("%d\n",n+x);
    }
}
