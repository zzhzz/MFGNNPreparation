#include<stdio.h>
#include<stdlib.h>

int main()
{
    int t,n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        int i;
        long int total=0;
        long int a[100001];
        long int d[100001];
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        for(i=0;i<n;i++)
        d[i]=1;
        for(i=0;i<n;i++)
        {
            if(a[i+1]>=a[i])
                d[i+1]=d[i]+1;
        }
        for(i=0;i<n;i++)
            total+=d[i];
        printf("%ld\n",total);
    }
    return 0;
}
