#include<stdio.h>
#define MAX 100005
long int a[MAX],ans;
main()
{
	int t,count,n,i;
	scanf("%d",&t);
	while(t--)
	{
	    ans=0;
		scanf("%d",&n);
		for(i=0;i<n;++i)
			scanf("%ld",&a[i]);
		for(i=0;i<n;++i)
		{
			count=1;
			while((a[i]<a[i+1])&&(i<n-1))
			{
				count++;
				i++;
			}
			for(count;count>0;--count)
				ans+=count;
		}
		printf("%ld\n",ans);
	}
	return 0;
}
