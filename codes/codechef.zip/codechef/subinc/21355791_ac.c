#include<stdio.h>
int main()
{
    long long t;
    scanf("%lld",&t);
    for(long long it=0;it<t;it++)
    {
        long long n,arr[100000];
        scanf("%lld",&n);
        for(long long i=0;i<n;i++)
            scanf("%lld",&arr[i]);
        long long l=0,f=0;
        long long sum=0;
        while(f<n)
        {
            if(f!=n-1 && arr[f+1]>=arr[f])
                f++;
            else
            {
                long long n1=f-l+1;
                sum+=(n1*(n1+1))/2;
                f++;
                l=f;
            }
        }
        printf("%lld\n",sum);
    }
    return 0;
}


