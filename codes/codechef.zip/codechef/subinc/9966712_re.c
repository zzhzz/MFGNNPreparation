#include<stdio.h>

int tabulate( long long int arr[],long int n)
{
    int l,i,j,tab[n][n];

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(i == j)
            tab[i][j] = 1;
            else
            tab[i][j] = 0;
        }
    }
    for(l=2;l<=n;l++)
    {
        for(i=1;i<=n-l+1;i++)
        {
            j = l+i-1;
            if(j == (i+1))
            {
                if(arr[j] >= arr[i])
                    tab[i][j] = 1;
            }
            else
            {
              if(tab[i][j-1] == 1)
              {
                  if(arr[j] >= arr[j-1])
                   tab[i][j] = 1;
              }
            }

        }

    }
    int c=0;
   
    for(i=1;i<=n;i++)
    {
       
        for(j=1;j<=n;j++)
        {

            if(tab[i][j] == 1)
                c++;
        }
    }

    return c;

}
int main()
{
    int no,t,i;
    long int n;
  long long int arr[100000];
    scanf("%d",&t);
    if(t>=1 && t<=5)
    {
        while(t>=1)
        {
            scanf("%ld",&n);

            for(i=1;i<=n;i++)
            {
                scanf("%lld",&arr[i]);
            }
            no = tabulate(arr,n);
            printf("%d\n",no);

            t--;
        }




    }


    return 0;

}
