#include <stdio.h>
int main()
{
	long int t,te,n,count,i;
	scanf("%d", &t);
	for(te=0;te<t;te++)
	{
		scanf("%d",&n);
	    long int a[n],b[n];
		for(int i=0; i<n; i++)
		{
			scanf("%ld",&a[i]);
		}
		b[n-1] = 1;
		count = 1;
		for(i=n-2;i>=0; i--)
		{
			b[i] = 1;
			
			if(a[i] <= a[i+1]){
				
				b[i]=b[i]+b[i+1];
			}
			count=count+b[i];			
		}
		printf("%ld \n", count);		
	}
	return 0;
}
