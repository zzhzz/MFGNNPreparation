#include<stdio.h>
int main()
{
	int t,i;
	scanf("%d",&t);
	while(t--)
	{
		int sum=0;
		long long n,test[100000]={1};
		scanf("%ld",&n);
		long long arr[100000];
		for(i=0;i<n;i++)
		{
			scanf("%lld",&arr[i]);
		}
		for(i=1;i<n;i++)
		{
			if(arr[i-1]<arr[i])
			{
				test[i]=test[i-1]+1;
			}
			else
			{
				test[i]=1;
			}
		
		}
		for(i=0;i<n;i++)
		{
			sum=sum+test[i];
		}
		printf("%d\n",sum);
	}
	return 0;
}
