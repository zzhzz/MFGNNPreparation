#include<stdio.h>
#include<stdlib.h>
main()
{

    int t,i,j,k=1,flag=0;
    long long int count=0,ans;
    long int n;
    long long int a[100001];
    scanf("%d",&t);
    while(t--)
    {

         scanf("%ld",&n);


     for(i=0;i<n;i++)
        {
            scanf("%lld",&a[i]);
        }


count=0;
        i=0;
        while(i<n-1)
        {
            if(a[i]>a[i+1])
                i++;
            else
                {
                    j=i;
            k=0;

                while(j<n-1)
                {
                    if(a[j]<=a[j+1])
                    {

                        count++;
                        j++;
                        k++;
                    }
                    else
                        break;
                }
                flag=k;
                while(k--)
                {
                    count=count+k;
                }
                i=i+flag;
        }
        }
        ans=count+n;
        printf("%lld",ans);
}
}