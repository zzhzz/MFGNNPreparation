#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main() {
    int t;
    scanf("%d",&t);
    while(t--)
    {
      long int n;
        scanf("%ld",&n);
       long int a[n],i,s=0,c=1;
        for(i=0;i<n;i++)
        {
            scanf("%ld",&a[i]);
                if((a[i]>=a[i-1])&&(i!=0))
                {
                    c++;
                  
                }      
               else
               {
                   s=s+(c*(c-1))/2;
                   c=1;  
               }
                
              
        }
        s=s+(c*(c-1))/2;
        printf("%ld\n",s+n);
        
    }
}
