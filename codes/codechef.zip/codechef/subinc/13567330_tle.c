#include<stdio.h>

int main()
{   int z;
    scanf("%d",&z);
    while(z--)
	{
		
		long int n,k,l,i,j;
		long long int a[100001],count=0;
		scanf("%ld",&n);
		for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
		for(i=0;i<n-1;i++)
		{
			for(j=0;j<n-i-1;j++)
			{
			l=0;
			for(k=i;k<n-1-j;k++)
				{
				if(a[k]<=a[k+1])
					l++;
				    
				}
				if(l==(n-1-j-i))
				{
				count++;
			    }
			}		
		}
		count=count+n;
		printf("%d\n",count);
	  
	}
	return 0;
}
