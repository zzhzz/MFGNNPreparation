#include <stdio.h>
int main(void)
{
long n,a[1000000],l=0;
int t,i;
scanf("%d",&t);
while(t--)
{
scanf("%ld",&n);
for(i=0;i<n;i++);
{
scanf("%ld",&a[i]);
}
for(i=0;i<n-1;i++)
{
if(a[i]<=a[i+1])
l++;
}
--l;
if(l>0)
printf("%ld",l+n);
else
printf("%ld",n);
}
return 0;
}

