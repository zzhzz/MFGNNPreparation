#include<stdio.h>
int main()
{
	int t;
	long int n,i,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		long long int a[n],count=0;
		for(i=0;i<n;i++)
		{
			scanf("%lld",&a[i]);
		}
		i=1;
			for(j=1;j<n;j++)
			{
				if(a[j]>a[j-1])
				{
					count++;
				}
				else
				{
				j=(++i);	
				}	
			}
		printf("%lld\n",count+n);
	}
	return 0;
}