#include<stdio.h>
#include<stdlib.h>
main()
{
  int T;
  scanf("%d ",&T);
  int i,N;
  for(i=0;i<T;i++)
  {   scanf("%d ",&N);
    int arr[N];
    int j,k,count=0;
    for (j=0;j<N-1;j++)
    {
      for(k=j+1;j<N;j++)
      {
        if(arr[j]<=arr[k])
        continue;
        else {
          count ++;
          break;
        }
      }
    }

printf("%d\n",N+count); 
}
}
