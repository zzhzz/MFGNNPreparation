#include<stdio.h>
#include<stdlib.h>

int main(){
	long int t,i;
	scanf("%lld",&t);
	while(t>0)
	{
		int n,i,j,c=0;
		scanf("%lld",&n);
		long int a[n];
		for(i=0;i<n;i++)
		{
			scanf("%lld",&a[i]);
		}
		c=n;
		for(i=0;i<n;i++)
			{
				for(j=i+1;j<n;j++){
				if(a[j] > a[j-1])
				{	
					//f=1;
					c++;
				}
				else
					break;
				}
			}
		printf("count is %lld",c);
	}

	return 0;
}
