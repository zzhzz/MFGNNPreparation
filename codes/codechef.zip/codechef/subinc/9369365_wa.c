#include<stdio.h>

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,i,c=0;
        scanf("%d",&n);
        long long int a[n];
        for(i=0;i<n;i++)
            scanf("%lld",&a[i]);
        for(i=1;i<n;i++)
            if(a[i-1]<a[i])
                c++;
        printf("%d\n",c+n);
    }
}
