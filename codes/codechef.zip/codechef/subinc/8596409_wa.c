#include <stdio.h>

int main(void) {
	
	int t;
	scanf("%d",&t);
	while(t--)
	{
	    int n,i;
	    scanf("%d",&n);
	    long long int next=0,current=0;
	    long long int count=n;
	    for(i=1;i<=n;i++)
	    {
	        scanf("%lld",&next);
	        if(current<=next&&current!=0)
	         count++;
	         current=next;
	    }
	    printf("%lld\n",count);
	}
	return 0;
}
