#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,i,count=0;

		scanf("%d",&n);
		int a[n],b[n];
		for(i=0;i<n;i++)
		scanf("%d",&a[i]);
		
for(i=1;i<n;i++)
{
    if(a[i-1]<=a[i])
        b[i]=b[i-1]+1;
}
for(i=0;i<n;i++)
{
    count=count+b[i];
}

	printf("%d",count);

	}return 0;
}
