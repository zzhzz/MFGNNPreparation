#include<stdio.h>
int main(){
int t,n,i;
long long count,sum;
int a[100000];
scanf("%d",&t);
while(t--){
        sum=0;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    count=1;
    for(i=0;i<=n-2;i++){
        if(a[i+1]>=a[i]){
            count++;
        }
        else{
            sum+=(count*(count+1))/2;
            count=1;
        }
    }

    sum+=(count*(count+1))/2;
    printf("%lld\n",sum);
}
return 0;
}
