#include <stdio.h>
#include<math.h>
int main(void) {
    int t,n,arr,i,j,count,last; unsigned long long int disp;
    scanf("%d",&t);
    for(i=0;i<t;i++){
        count=0;
        last=0;
        disp=0;
        scanf("%d",&n);
        for(j=0;j<n;j++){
            scanf("%d",&arr);
            if(last<=arr){
                //printf("count1=%d ",count);
                count++;
                last=arr;
            }
            else{
                //printf("count=%d ",count);
                disp+=(count*(count+1))/2;
                count=1;
                last=arr;
            }
        }
        disp+=(count*(count+1))/2;
        printf("%llu\n",disp);
    }
	return 0;
}

