#include<stdio.h>

int main()
{
    int i,j,test_cases,p,sum,max,jold;
    int size;

    scanf("%d",&test_cases);
    for(p=0;p<test_cases;p++)
    {
    scanf("%d",&size);
    long long int arr[size];
sum=(size*(size+1))/2;
    for(i=0;i<size;i++)
    {
        scanf("%lld",&arr[i]);

    }

    for(i=0;i<size;i++)
    {

    for(j=i+1;j<size;j++)
        {
         if(arr[i]>arr[j])
        {


             sum=sum-((size-i)-(j-i));

             break ;
        }
        else
       {
        jold=j;
       }




        }
        if(jold!=j)
        {
            sum=sum-((size-i)-(j-i));
        }
    }

    printf("%d\n",sum);
}
    return 0;
}
