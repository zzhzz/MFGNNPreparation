#include<stdio.h>
int main()
{ int t;
long long int i,j,k,n,c;
scanf("%d",&t);
while(t--)
{
scanf("%lld",&n);
c=n;
long long int a[n];
for(i=0;i<n;i++)
scanf("%lld",&a[i]);
for(i=0;i<n-1;i++)
{
  for(j=i+1;j<n;j++)
  { int flag=1;
     for(k=i;k<j;k++)
     {
         if(a[k]>a[k+1])
            {
                flag=0;
                break;
            }
     }
     if(flag==1)
        c++;

  }
}

    printf("%lld\n",c);
}
return 0;}


