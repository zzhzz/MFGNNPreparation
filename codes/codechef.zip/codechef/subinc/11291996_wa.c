#include<stdio.h>
int main()
{
    int t,n,i,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        int a[n],s=n;
        for(i=0;i<n;i++)
        scanf("%d",&a[i]);
        for(i=0;i<n-1;i++)
        {
            for(j=i;j<n;j++)
            {
                if(a[j]<=a[j+1])
                s++;
                else;
                break;
        }}
        printf("%d\n",s);
    }
}
