#include <stdio.h>

int main(void) {
	// your code goes here
	int t,n,i,j,z,k;
	long long int a[100009],sum;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		sum=0;
		for(z=0;z<n;z++)
		{
			scanf("%lld",&a[z]);
		}
		i=0;
		j=0;
		while(j<n)
		{
			if(a[j]>a[j+1] || n==j+1)
			{
				k=j-i+1;
				sum+=(k*(k+1)/2);
				i=j+1;
				}
				j++;
		}
		printf("%lld\n",sum);
	}
	return 0;
}
