#include <stdio.h>

long long count=0;

void subset(long long a[],long n,long start, long index, long num_sub)
{
    long long i, j,t=0;

    if (index - start + 1  ==  num_sub)
    {
        if (num_sub  ==  1)
        {
            for (i = 0;i < n;i++){
                    count++;
                    //printf("%lld COUNT:%lld\n", a[i],count);
            }
        }
        else
        {
            for (j = index;j < n;j++)
            {

                if(a[j-1] > a[j] && j != 0)break;

                for (i = start;i < index;i++){

                    if(a[i-1] > a[i] && i!=0 && i!= start){
                            //printf("\n");
                            break;
                    }

                    //printf("%lld", a[i],count);
                }

                if(i != index)break;

                count++;

                //printf("%lld COUNT: %lld\n", a[j],count);
            }
            if (start != n - num_sub)
                subset(a,n,start + 1, start + 1, num_sub);
        }
    }
    else
    {
        subset(a,n,start, index + 1, num_sub);
    }
}

int main(){

    int t;

    scanf("%d",&t);

    while(t--){

        count = 0;

        long n,index = 0, start = 0,i,j;

        scanf("%ld",&n);

        long long a[n];

        for(i=0;i<n;i++){

            scanf("%lld",&a[i]);
        }

        for (i = 1;i <= n;i++)
            subset(a,n,0, 0, i);

        printf("%lld",count);
        printf("\n");
    }

    return 0;
}
