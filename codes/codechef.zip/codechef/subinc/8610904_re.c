#include<stdio.h>
#include<stdlib.h>
int run();
int main()
{	
	int t,x;scanf("%d",&t);
	int *p;x=0;
	p=(int*) malloc(sizeof(int)*t);	
	while(x<t)
		p[x++]=run();
	x=0;
	while(x<t)
		printf("%d\n",p[x++]);
	return 0;
}
int run()
{
		int  c=0,y;
		long int n;
		scanf("%ld",&n);
		c=n;
		long int *ar;
		ar=(long int*)malloc(sizeof(long int)*n);
		int x=0;
		while (scanf("%ld", &ar[x]) ==1)
			x++;
		fflush(stdin);
		for(x=0; x<n; x++)
		{
			for(y=x; y<n-1; y++)
			{
				if(ar[y]<=ar[y+1])
					c++;
				else
					break;
			}
		}
		return c;	
}