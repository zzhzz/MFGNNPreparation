#include<stdio.h>
long int A[100000]={0},N=0,j=0,sub=0,z=0;
main()
{
    int T,i,j;
    scanf("%d",&T);
    for(i=0;i<T;i++)
    {
        scanf("%ld",&N);
        for(j=0;j<N;j++)
            {
            scanf("%ld",&A[j]);
            if(A[j-1]<=A[j])
                {
                    sub++;
                   if((j-1)!=z)
                    {
                        sub = sub + ((j-1)-z);
                        continue;
                    }
                }
                else
                {
                    z = j;
                    continue;
                }
            }
        sub = sub + N;
        printf("%ld\n",sub);
        sub = 0;
    }
}
