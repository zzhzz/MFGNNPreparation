#include <stdio.h>

int main(void) {
	int T, N;
	scanf("%d", &T);
	int t,i;
	for (t = 0; t<T; t++) {
		scanf("%d", &N);
		int prev,curr;
		prev = scanf("%d", &prev);
		int count = 0;
		int contin = 0;
		for (i = 1; i<N; i++) {
			scanf("%d", &curr);
			if (curr >= prev) contin++;
			else {
				count += (contin * (contin + 1))/2;
				contin = 0;
			}
			prev = curr;
		}
		count += (contin * (contin + 1))/2;
		count += N;
		printf("%d\n", count);
	}
	return 0;
}