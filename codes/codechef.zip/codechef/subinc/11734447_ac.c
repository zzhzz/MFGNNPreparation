#include <stdio.h>
int main()
{
    int t,i,j,n;
    long long int sum;
    int arr[100001];
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        int b[n];
        for(i=0;i<n;i++)
            scanf("%d",&arr[i]);
        sum=1;
        b[0]=1;
        for(i=1;i<n;i++)
        {
            if(arr[i-1]<=arr[i])
                b[i]=b[i-1]+1;
            else
                b[i]=1;
            sum+=b[i];
        }
        printf("%lld\n",sum);
    }
    return 0;
}