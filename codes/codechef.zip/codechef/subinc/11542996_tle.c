#include <stdio.h>
int main() {
	int TestCaseCount,i,j,k,TotalCombinations;
	long ArraySize;	
	int Results[5]={0};	
	scanf("%d",&TestCaseCount);	
	for(j=0;j<TestCaseCount;j++)
	{
		int ArrayMatrix[100000]={0};
		scanf("%ld",&ArraySize);		
		for(i=0;i<ArraySize;i++)
		scanf("%ld",&ArrayMatrix[i]);		
		TotalCombinations=0;
		
		for(i=0;i<ArraySize;i++)
		{
			if(ArrayMatrix[i]>=1)	
			{
				TotalCombinations = TotalCombinations+1;	
			}
			k=i;
			while(k+1<ArraySize)
			{
				if(ArrayMatrix[i]<=ArrayMatrix[i+1])
				{
					TotalCombinations=TotalCombinations+1;
					k++;
				}
				else
				{
					break;
				}
			}
		}
		Results[j] = TotalCombinations;
	}	
	for(j=0;j<TestCaseCount;j++)
	{
		printf("%d\n",Results[j]);
	}
	return 0;
}