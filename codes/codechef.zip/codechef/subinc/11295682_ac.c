#include<stdio.h>	
int main()			
{
	int t;
	long long int n,i,cnt,a,b,r;
	scanf("%d",&t);
	while(t--)
	{
		r = 1,cnt =1; 
		scanf("%lld",&n);
		scanf("%lld",&a);
		for(i=1;i<n;i++)
		{
			scanf("%lld",&b);
			if(b>a)
			  cnt = cnt+1;
			else
			  cnt =1;
			r = r+cnt;
			a=b;
		}
		printf("%lld\n",r);
	}
	return 0;
}
