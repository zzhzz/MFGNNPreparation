#include<stdio.h>
#include<string.h>
#include<malloc.h>
#define MAX 100000
void sol()
{
    int i,n,j,count;
    long int arr[MAX];
    scanf("%d",&n);
    for(i=0;i<n;i++)
        scanf("%ld",&arr[i]);
        count=n;
    for(i=0;i<n;i++)
    {
        j=i+1;
        while(arr[j]>arr[j-1]&&j<n)
        {
            count++;
            j++;
        }
    }
    printf("%ld\n",count);
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
        sol();
    return 0;
}
