#include<stdio.h>
int main()
{
	int t;
	long n,i;
	long long int count,val;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		long long int a[n];
		for(i=0;i<n;i++)
			scanf("%lld",&a[i]);
		count=1;
		val=0;
		for(i=0;i<n;i++)
		{
			if(a[i]<=a[i+1])
				count++;
			else
			{
				val+=count*(count+1)/2;
				count=1;
			}
			val+=count*(count+1)/2;
			printf("%lld\n",val);
		}
	}
		return 0;
}