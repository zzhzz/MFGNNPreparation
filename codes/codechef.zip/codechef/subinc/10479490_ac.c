#include <stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while (t--) {
        int n;
        scanf("%d",&n);
        int a[n+1],i;
        for (i=1; i<=n; i++) {
            scanf("%d",&a[i]);
        }
        int index=0;
        long long int count=1;
        for (i=2;i<=n;i++) {
            if(a[i]<a[i-1]){
                index=i-1;
                count++;
            }
            else{
                count+=i-index;
            }
        }
        printf("%lld\n",count);
    }
    return 0;
}
