#include<stdio.h>
int main(){
int t;
scanf("%d",&t);
while(t--){
int n;
scanf("%d",&n);
long long int A[n];
int i,j,count=0;
for(i=0;i<n;i++){
    scanf("%lld",&A[i]);
}
int count1=0;
for(i=0;i<n;i++){
        count =1;
    for(j=i;j<n-1;j++){
        if(A[j]<=A[j+1]){
            count++;
        }else{
        break;
        }

}
if(count>1){
count1++;
}
}
printf("%d\n",count1+n);
}
return 0;
}
