#include <stdio.h>

// Driver Code
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,arr[10000],i,j,count = 0,old_res,flag=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			scanf("%d",&arr[i]);
		}
		for(i=1;i<=n;i++)
		{
			flag = 0;
			for(j=i;j<=n;j++)
			{
				if(i==j)
				{
					count= count + 1;
					old_res = arr[i];
				}
				else
				{
					if(arr[j]>old_res)
					{
						old_res = arr[j];
						count = count + 1;
					}
					else
					{
						break;
					}
				}
			}
		}
		printf("%d\n",count);
	}
    return 0;
}
