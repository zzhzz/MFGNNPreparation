#include<stdio.h>
#include<stdlib.h>


int main()
{
    int t;
    scanf("%d",&t);
    while(t!=0){
        int n;
        scanf("%d",&n);
        int *a=malloc(n*sizeof(int));
        int j=n,i=0,k;
        while(n!=0){
            scanf("%d",&k);
            if(k<=j){
                a[i]=k;
                i++;
            }
            n--;
        }
        i=i-1;
        printf("%d\n",(2*j)-1);
    t--;
    }
}