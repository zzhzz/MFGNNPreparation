#include<stdio.h>
#include<stdlib.h>
int main()
{
 int t;
 long long int n,a,b,k,i,g,l,s,m;
 scanf("%d",&t);
 while(t--)
 {
  scanf("%lld",&n);
  a=0;k=0;m=0;l=0;s=0;g=1;
  for(i=1;i<=n;i++)
  {
   scanf("%lld",&b);
   if(b>=a)
   {
    k=k+1+m;
    m++; g=1;
   l=k;}
   else if(b<a)
   {
    s=k;
    k=1;m=0;l=0;
    s=s+g;
    g++;
   }
   a=b;
  }
  printf("\n%lld",s+l);
 }
 return 0;
}