#include<stdio.h>
main()
{
    int t,i;
    scanf("%d",&t);
    while(t--)
    {
        long int n,count=0,sum=0;
        scanf("%ld",&n);
        int a[n];
        scanf("%d",&a[0]);
        for(i=1;i<n;i++)
        {
            scanf("%d",&a[i]);
            if(a[i]>=a[i-1])
                count++;
            else
            {
                sum+=(count*(count+1))/2;
                count=0;
            }
        }
        sum+=(count*(count+1))/2;
        printf("%ld\n",sum+n);
    }
}
