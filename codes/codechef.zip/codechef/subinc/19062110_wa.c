#include<stdio.h>
main()
{
    int t;
    long int n,i,j;
    scanf("%d",&t);
    while(t--)
    {

        scanf("%ld",&n);
        long int arr[n];
        for(i=0;i<n;i++)
        {
            scanf("%ld",&arr[i]);
        }
        long int ans=n;
        int valid=0;
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {


            if(arr[i]<=arr[j])
            {
                i++;
                j++;
                valid=1;
            }

            }
            if(valid==1)
            {

                ans++;
                valid=0;
            }
        }
        printf("%ld\n",ans);
    }
}
