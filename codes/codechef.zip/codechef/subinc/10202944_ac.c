#include <stdio.h>

int main(void)
{
	long long t,n,f,s,ret,j,a;

	scanf(" %lld",&t);
	while(t-->0){
		scanf(" %lld",&n);
		scanf(" %lld",&f);
		s = f;
		ret = 1;
		a=1;
		for(j=1;j<n;j++){
			s=f;
			scanf(" %lld",&f);
			if(s<=f)
				++a;
			else
				a=1;
			ret+=a;
		}
		printf("%lld\n",ret);
	}
	return 0;
}