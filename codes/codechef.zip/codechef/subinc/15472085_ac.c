#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long int a[100001],n,i,j,count=0,x=0,c=1;
		scanf("%ld",&n);
		for(i=0;i<n;++i)
		scanf("%ld",&a[i]);x=a[0];
		for(i=1;i<n;++i)
		{
			if(x<=a[i])
			c++;
			else
			{
				count+=(c*(c+1))/2;c=1;
			}
			x=a[i];
		}
		//if(a[n-2]<=a[n-1])
		count+=(c*(c+1))/2;
		printf("%ld\n",count);
	}
	return 0;
}  