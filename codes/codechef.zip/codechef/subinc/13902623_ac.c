#include<stdio.h>
typedef long long ll;
ll pair(ll c)
{
    return (c*(c+1))/2;
}
int main()
{
    int t, n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        ll a[n], c=0, i, j;
        for(i=0;i<n;i++)
        scanf("%lld",&a[i]);
        for(i=0,j=i+1;i<n && j<n;j++)
        {
            if(a[j-1]<=a[j])
            continue;
            else
            {
                c+=pair(j-i);
                i = j;
            }
        }
        c+=pair(j-i);
        printf("%lld\n",c);
    }
    return 0;
}