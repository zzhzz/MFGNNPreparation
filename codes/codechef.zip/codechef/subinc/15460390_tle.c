#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int t;
    long long int n,i,count,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%lld",&n);
        long long int *a = (long long int *)malloc(n*sizeof(long long int));
        for(i=0;i<n;i++)
        scanf("%lld",&a[i]);
        count=0;
        if(n==1)
        count=1;
        else
        {
        for(i=0;i<(n);i++)
        {
            for(j=0;j<n;j++)
            {
                if(a[i]<a[j])
                count++;
            }
        }
        }
        printf("%lld\n",count);
        free(a);
    }
    return 0;
}