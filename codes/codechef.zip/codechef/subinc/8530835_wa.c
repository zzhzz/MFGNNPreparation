#include<stdio.h>
int main(){
	int x;
	scanf("%d",&x);
	int i;
	for(i=0;i<x;i++){
		long d=0,l=0;
		long y;
		long n=1,k=0,j;
		long a[100000];
		scanf("%d",&y);
		for(j=1;j<=y;j++){
			scanf("%ld",&a[j]);
		}
		if(y==1){
			printf("1");
		}
		else{
		for(n=1;n<y;n++){
			if(a[n]<=a[n+1]){
				k++;
				
			}
			else{
				if(a[n-1]<=a[n]&&n>1){
				l=k+1;
				d=d+((l*(l+1))/2);
				k=0;
				l=0;
		        }       
			}
		}
		if(k!=0){
			d=d+(((k+1)*(k+2))/2);
		}
		printf("%ld",d);
	   }
}}