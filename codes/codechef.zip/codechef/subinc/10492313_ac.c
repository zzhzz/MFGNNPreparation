#include <stdio.h>
 
int main(void) {
	// your code goes here
	int t,i,j,count,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		long long int a[n];
		for(i=0;i<n;i++)scanf("%lld",&a[i]);
		int b[n];
		b[0]=1;count=1;
		for(i=1;i<n;i++){
			if(a[i]>=a[i-1])b[i]=b[i-1]+1;
			else b[i]=1;
			count+=b[i];
		}
		printf("%d\n",count);
	}
	return 0;
}
 