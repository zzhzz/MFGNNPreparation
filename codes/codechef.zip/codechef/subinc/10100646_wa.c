#include<stdio.h>

int compare(int arr[],int i,int size)
{if((i+1)<size)
    {if(arr[i]<arr[i+1])
        return (1+compare(arr,i+1,size));
    else
        return 0;
    }
    else
        return 0;
}

int main()
{
    int size,i,t,n,mm;

    scanf("%d",&n);

    for(mm=0;mm<n;mm++)
    {


    scanf("%d",&size);
    long arr[size];
    for(i=0;i<size;i++)
    {
        scanf("%ld",&arr[i]);
    }
    int sum=0;
    for(i=0;i<size-1;i++)
    {
        t=compare(arr,i,size);
        sum+=t;
    }

    printf("%d\n",size+sum);
    }
    return 0;


}