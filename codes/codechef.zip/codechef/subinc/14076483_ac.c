#include <stdio.h>
#include <stdlib.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long int n;
        scanf("%ld",&n);
        long int i,k=0,x=0;
        long int a[100000]={0};
        for(i=0;i<n;i++)
        {
            scanf("%ld",&a[i]);
        }
        for(i=0;i<n-1;i++)
        {
            if(a[i]<=a[i+1])
            k++;
            else
                k=0;
            if(a[i]<=a[i+1])
                x=x+k;

        }
        printf("%d\n",x+n);
    }
    return 0;
}
