#include<stdio.h>


long long int countsub(long long int arr[], long long int n)
{
    long long int cnt = 0;

    long long int len = 1,i;


    for (i=0; i < n-1; ++i)
    {

        if (arr[i + 1] >=arr[i])
            len++;


        else
        {
            cnt += (((len - 1) * len) / 2);
            len = 1;
        }
    }


    if (len > 1)
        cnt += (((len - 1) * len) / 2);

    return cnt+n;
}
int main()
{
    int t,i;
    long long int l,n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%lld",&n);
        long long int a[n];
        for(i=0;i<n;i++)
            scanf("%lld",&a[i]);
        l=countsub(a,n);
        printf("%lld\n",l);
    }
    return 0;
}
