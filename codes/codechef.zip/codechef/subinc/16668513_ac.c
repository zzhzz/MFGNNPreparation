#include <stdio.h>

#define LLI long long int

int main(void) 
{
    int T,N;
    int A[100000],p,i;
    LLI count;
    
    scanf("%d ",&T);
    while(T--)
    {
        scanf("%d",&N);
        
        for(i=0;i<N;i++)
            scanf("%d",&A[i]);
        
        p=0;
        count=0;
        for(i=0;i<N-1;i++)
        {
            if(A[i]<=A[i+1])
            {
                p++;
            }
            else
            {
                count += p*(p+1)/2;
                p=0;
            }
                
        }
        count += p*(p+1)/2 + N;
            
        printf("%lld\n",count);
    }
    
	return 0;
}

