#include <stdio.h>
int count_subarray(int A[],int size) 
{
		int i,j,c = 0;
		for(j = 0; j < size; j++) {
			i = j;
			while (A[i] < A[i+1]) {
				c++;
				if(i == size-1) {
					break;
				}
				else {
					i++;
				}
			}
		}
		c += size;
		return c;
}
	int main()
	{
		int T,N,i,j;
		unsigned int a[100001];
	
		scanf("%d", &T);
		for(j = 0; j < T; j++) {
			scanf("%d", &N);

			for(i = 0; i < N; i++) {
				scanf("%u", &a[i]);	
			}
			printf("%d\n",count_subarray(a,N));	

		}

		return 0;
	}
