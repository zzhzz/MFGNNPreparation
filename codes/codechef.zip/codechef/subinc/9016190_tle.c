#include <stdio.h>

int main(){
    int t,n,i,k,l;
    long int a[100000],b[10000];
    scanf("%d", &t);
    while(t){
        k=0;
        l=0;
        scanf("%d", &n);
        for(i=0; i<n; i++){
            scanf("%d", &a[i]);
        }
        for(i=0; i<(n-1); i++){
            if(a[i]<=a[i+1]){
                l++;
            }
            else{
                if(l!=0){
                    k++;
                }
                l=0;
            }
        }
        k+=n;

         for (i=0; i<n; i++){
                if(a[i]==0)continue;
            for(l=i+1; l<n; l++){
                if(a[i]==a[l]){
                    a[l]=0;k--;
                }
            }
         }
        printf("%d", k+1);
        t--;
    }
    return 0;
}
