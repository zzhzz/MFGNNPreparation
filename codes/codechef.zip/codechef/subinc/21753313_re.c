#include<stdio.h>
long long A[1000006];
long long dp[1000006];
int main()
{
    int i,j,k;
    int t,n;
    scanf(" %d",&t);
    while(t--)
    {
        scanf(" %d",&n);
        for(int i=1;i<=n;i++)
        {
            scanf(" %lld",&A[i]);
            dp[i]=1;
        }
        long long int sum=dp[A[n]];
        for(int i=n-1;i>0;i--)
        {
                if(A[i]<A[i+1])
                    dp[i]=dp[i+1]+1;

                sum+=dp[i];

        }

        printf("%lld\n",sum);
    }
    return 0;
}
