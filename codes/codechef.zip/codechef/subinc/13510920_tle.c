#include <stdio.h>

int main()
{
    unsigned short int T,i,j,k;
    unsigned int N,M;
    scanf("%d\n",&T);
    while(T--){
     scanf("%d\n",&N);
     int a[N];
         for(j=0;j<N;j++)
         scanf("%d",&a[j]);
         M=N;
         for(i=0;i<N-1;i++)
         {
         if(a[i]<a[i+1])
         M=M+1;
         }
         printf("%d\n",M);
    }
    return 0;
}

