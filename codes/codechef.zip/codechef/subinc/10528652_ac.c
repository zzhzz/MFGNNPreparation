#include <stdio.h>
#include <stdlib.h>
int cmpfunc(const void*a,const void*b)
{
    return *(long long unsigned int*)a-*(long long unsigned int*)b;
}

int main()
{
    long long unsigned int n,a[100000],t,c,l,i,j,p=0;;
    scanf("%llu",&t);
    while(t--)
    {
        c=0;p=0;l=0;
    scanf("%llu",&n);
    for(i=0;i<n;i++)
     scanf("%llu",&a[i]);
if(n==1)
c=1;
else
{
    for(i=0;i<n-1;i++)
    {
        l=i;
    while(a[l]==a[l+1])
          {
        l++;
          }
          if(l==n-1)
            break;
    while(a[l+1]>a[l])
    {
        c++;
        l++;
               if(l==n-1)
            break;
    }
    }
    qsort(a,n,sizeof(long long unsigned int),cmpfunc);
      for(i=0;i<n-1;i++)
        {
            p=0;
            l=i;
        while(a[l]==a[l+1])
          {
        p=1;
        l++;
          }
        if(l==i || l-i ==1)
        c++;
        else
            c+=l-i-1;
        if(p==0 && i==n-2)
           {
               c++;
               break;
           }
            }
}
    printf("%llu\n",c);
    }
    return 0;
}