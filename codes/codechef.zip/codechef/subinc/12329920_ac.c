#include <stdio.h>

int main() {
    int t;
    long n,i;
    long long res;
    scanf("%d",&t);
    while(t--) {
        scanf("%ld",&n);
        res=n;
        long long arr[n];
        for(i=0;i<n;i++) {
            scanf("%lld",&arr[i]);
        }
        long prev=0;
        for(i=1;i<n;i++) {
            if(arr[i-1]>arr[i]) {
                res+=(i-prev)*(i-1-prev)/2;
                prev=i;
            }
        }
        res+=(i-prev)*(i-1-prev)/2;
        printf("%lld\n",res);
    }
    return 0;
}