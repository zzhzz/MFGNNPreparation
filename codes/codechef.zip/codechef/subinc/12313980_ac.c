#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long int n;
		scanf("%d",&n);
		long int A[n];
		long int i;
		for(i=0;i<n;i++)
		   scanf("%ld",&A[i]);
		   
		long int c,j,k;
		c=0;
		for(j=0;j<n-1;j++)
		{
		  for(k=j;k<n-1;k++)
		   {
		   	if(A[k]<=A[k+1])
				 c++;
			else 
			  break;		  	  
		   }
		}
		printf("%ld\n",c+n);
	}
	return 0;
}