#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t-->0)
	{
		long int n;
		scanf("%ld",&n);
		long int a[n];
		int i,j;
		for(i=0;i<n;i++)
		scanf("%d",a+i);
		long int count=n;
		for(i=0;i<n;i++)
		for(j=i+1;j<n;j++)
		if(a[j]>a[j-1])
		{
		count++;
		}
		else
		break;
		printf("%d\n",count);
	}
	
	return 0;
	
}