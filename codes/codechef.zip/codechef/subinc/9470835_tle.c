#include<stdio.h>

int main(void)
{
	int t,n,count = 0,temp = 1;
	int i,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		int a[n];
		scanf("%d",&a[0]);
		if(n==1)
		count == 1;
		for(i = 1; i< n; i++)
		{
			scanf("%d",&a[i]);
			if(a[i-1] >= a[i])
			{
				count +=  (temp * (temp + 1)) / 2;
				temp = 1;
				i = i -1;
			}
			else
			{
				temp++;
			
			}
		
		}

		printf("%d",count);
	
	}




	return 0;
}