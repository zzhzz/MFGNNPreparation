#include<stdio.h>
int main()
{
	int n,t,count=0;
	scanf("%d", &n);
	while(n--)
	{
		int i,j,sum,sum1 ;
		int a[t];
		scanf("%d",&t);
		for(i=0;i<t;i++)
		{
			sum=a[i];
			for(j=i+1;j<t;j++)
			{
				sum1=a[j+1];
				if(((sum1-sum)==1) || (sum1>sum))
				{
					count++;
				}
			}
		}
		
	}
	printf("%d\n", count + t);
}