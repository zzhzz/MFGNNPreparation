#include<stdio.h>
 
int main()
{
    int t;
    scanf("%d",&t);
 
    while(t--)
    {
        int n,i,j;
        scanf("%d",&n);
        long long a[n],c=1,s=1,q,f;
        scanf("%lld",&q);
 
        for(i=0;i<n-1;i++)
        {
            scanf("%lld",&f);
 
            if(f>=q)
            {
                c++;
                q=f;
            }
            else
            {
                c=1; 
                q=f;
            }
            s+=c;
 
            }
 
        printf("%lld \n",s);
         s=1;
         c=1;		
    }
    return 0;
}