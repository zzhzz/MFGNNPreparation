#include <stdio.h>
int tcout[5];
int count_subarray(int A[],int size) 
{
	int i,j,c;
	for(j = 0; j < size; j++) {
		c++;
		i = j;
		while (i < size-1 && A[i] <= A[++i]) {
			c++;		
		}  
	}
	return c;
}
int main()
{
	int T,N,i,j;
	unsigned int a[10];
	scanf("%d", &T);
	for(j = 0; j < T; j++) {
		scanf("%d", &N);

		for(i = 0; i < N; i++) {
			scanf("%u", &a[i]);	
		}
		tcout[j] = count_subarray(a, N);		
	}
	for(j = 0; j < T; j++) {
		printf("%d\n",tcout[j]);	
	}
	return 0;
}
