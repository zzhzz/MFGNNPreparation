#include<stdio.h>
#define mx 100

int chkcount(int n){
    return ((n)*(n+1))/2;
}

int main(){
    int i,j,A[mx],N,T,count,sum=0;
    scanf("%d",&T);
    for(i=0;i<T;i++){
        count=1;
        sum=0;
        scanf("%d",&N);
        for(j=0;j<N;j++)scanf("%d",&A[j]);
        if(N==1)sum=1;
        else if(A[N-1]<A[N-2])sum=1;
        for(j=0;j<N-1;j++){
            count=1;
            while(A[j]<=A[j+1]){
                count++;
                j++;
            }
            sum+=chkcount(count);
        }
        printf("%d\n",sum);
    }
}
