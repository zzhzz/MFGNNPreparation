#include<stdio.h>
void sub(int [], int);
int main()
{
	int t;
	scanf("%d",&t);
	int i, n,j;
	for(i=0;i<t;i++)
	{
		scanf("%d",&n);
		int a[n];
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[j]);
		}
		sub(a,n);
	}
	return 0;
}
void sub(int a[],int n)
{
	int i,j,c=0,count=0,m;
	for(i=0;i<n;i++)
	{
		for(j=i;j<n;j++)
		{
			for(m=i;m<j;m++)
			{
				if(a[m]<a[m+1])
				c++;
				else 
				break;
			}
			if((i+c)==j)
			{
				count++;
			}
			c=0;
		}
	}
	printf("%d\n",count);
}