#include<stdio.h>

int main()
{
    int t;
    
    scanf("%d",&t);
    while (t!=0)
    {
        call();
        t--;
        
    }
    return 0;
}

call()
{
    
    long long int a[100005],c=0,t,n,i,j;
   scanf("%lld",&n);
   for(i=1;i<n+1;i++) scanf("%lld",&a[i]);
   for(i=1;i<n;i++)
   {
       j=0;
       while(j<n-i)
       {
           if(a[i+j]<=a[i+j+1]) j++;
           else break;
       }
       c+=j;
   }
   
   printf("%lld\n",c+n);
    
}
    
