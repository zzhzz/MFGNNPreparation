#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int i,j,n;
		long long int sum=0,k=0;
		scanf("%d",&n);
		int a[n];
		int x=0;
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			if(a[i]>=x)
			{
				x=a[i];
				k++;
			}
			else
			{
				x=a[i];
				sum+=(k*(k+1))/2;
				k=1;
			}
		}
		sum+=(k*(k+1))/2;
		printf("%lld\n",sum);
	}
	return 0;
} 