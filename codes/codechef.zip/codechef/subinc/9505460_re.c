#include <stdio.h>

int main() {
	int t,n,count=0,result[5]={0},i,j;
	long int a[5][100000];
	scanf("%d",&t);
	for(j=1;j<=t;j++)
	{
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	    scanf("%ld",&a[j][i]);
	}
	a[j][i]=-1;
	i=0;
	while(i<n)
	{
		count=0;
	    while((a[j][i]<=a[j][i+1])&&(a[j][i+1]!=-1))
	    {
		i++;
	    count++;
		}
	    if(count>0)
	    result[j]++;
	    i++;
	}
	result[j]=result[j]+n;
}
for(i=1;i<=t;i++)
	printf("%d\n",result[i]);
	return 0;
}
