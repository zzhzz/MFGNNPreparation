#include <stdio.h>
//using namespace std;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int arr[100000],n,i=0;
		long long cnt=0,upr=0,lwr=0;
		scanf("%d",&n);
		for(i=0;i<n;++i){
			scanf("%d",&arr[i]);
		}
		for(i=0;i<n;++i){
			if(i+1<n){
			if(arr[i]<=arr[i+1]){
				upr=i+1;
			}
			else {
				if(upr>lwr)
				cnt+=((upr-lwr+1)*(upr-lwr+2))/2;
				lwr=i+1;
			}
		}
			if(i+1==n){
				if(upr>=lwr)
					cnt+=((upr-lwr+1)*(upr-lwr+2))/2;
			}
			//cout<<i<<" "<<cnt<<endl;
		}
		printf("%lld\n",cnt);
	}
	return 0;
}