#include<stdio.h>
int main()
{
	int t,j,l;
	scanf("%d",&t);
	while(t--)
	{
		int n,i,count=0;
		scanf("%d",&n);
		int ar[n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&ar[i]);
		}
		for(i=0;i<n;i++)
		{
		    for(j=i+1;j<n;j++)
			{
				int k=i;
				for(l=i+1;l<=j;l++)
				{
					if(k<l&&ar[k]<ar[l])
					{
						k++;
						continue;
					}
				}
				if(k==j)
				count++;
			}
	    }
	    int total=count+n;
	    printf("%d\n",total);
    }
}