#include<stdio.h>
int main()
{
        int t;
        scanf("%d",&t);
        while(t!=0)
        {
        int n;
        scanf("\n%d\n",&n);
        long long int arr[n],c=n;
        int i,j=0,k=0;
        for(i=0;i<n;i++)
                scanf("%d",&arr[i]);
        if(n==1)
        printf("%d\n",n);
        else
        {
 
        while(j!=n-1)
        {
 
                if(arr[j]<=arr[j+1])
                        k++;
                else
                 {
                        while(k!=0)
                        {
                                c=c+k;
                                k--;
                                }
                }
        j++;
        }
        if(k!=0)
        {
                while(k!=0)
                        {
                                c=c+k;
                                k--;
                                }
                }
        printf("%lld\n",c);
        }
        t--;
        }
        return 0;
        }