    #include<stdio.h>
    int main()
    {
    	int t;
    	scanf("%d",&t);
    	while(t--)
    	{
    		long long int s=0,i,n,a[100001],dp[100001];
    		scanf("%lld",&n);
    		for(i=0;i<n;i++)
    			scanf("%lld",&a[i]);
    		dp[0]=1;
    		for(i=0;i<n-1;i++)
    		{
    			if(a[i+1]>a[i])
    				dp[i+1]=dp[i]+1;
    			else
    				dp[i+1]=1;
    			s+=dp[i];
    		}
    		s+=dp[n-1];
    		printf("%lld\n",s);
    	} 
    	return 0;
    }
     