#include<stdio.h>
#include<stdlib.h>
#define max 100000
int main()
{
    int t,i,j;
    printf("Enter test cases\n");
    scanf("%d",&t);
    while(t>0&&t<=5)
    {
            long co=0;
            int a[max],n;
            printf("\nEnter N\n");
            scanf("%ld",&n);
            printf("Enter Array-\n");
            for(i=0;i<n;i++)
                scanf("%ld",&a[i]);
            for(i=0;i<n;i++)
            {
                for(j=i;j<n;j++)
                {
                    if(a[j]<=a[j+1]&&j!=(n-1))
                        co++;
                    else
                        break;
                }
            }
            printf("%ld",co+n);
            t--;
        }

    return 0;
}

