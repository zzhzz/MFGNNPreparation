#include<stdio.h>
int count(int[100000],int);
int fact(int);

int main()
{
    int a[100000];
    int size;
    int t,i,c;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&size);
        for(i=0;i<size;i++)
            scanf("%d",&a[i]);
        c=count(a,size);
        printf("%d",c);
    }
     return 0;
}
int count(int a[100000],int n)
{
    int i,count=1,sum=0;
    if(n==1)
        return 1;
    for(i=0;i<n;i++)
    {
        if(a[i+1]>a[i])
        {
            count++;
        }
        else if(count==1)
        {
            sum=sum+1;
            count=1;
        }
        else
        {
            sum=sum+(fact(count)/(2*fact(count-2)))+n;
            //printf("sum is %d\n",sum);
            count =1;
        }
    }
    return sum;
}
int fact(int n)
{
    int i=1;
    while(n!=0)
    {
        i=i*n;
        n--;
    }
    return i;
}
