#include<stdio.h>
int main(void)
{int t;
scanf("%d",&t);
while(t--)
{long long int n,j,k,c,x=0;
scanf("%lld",&n);
long long int a[n];
for(j=0;j<n;j++)
scanf("%lld ",&a[j]);
for(j=0;j<n;j++)
{c=j+1;
for(k=j;k<c;k++)
{if(a[k]<=a[k+1])
{c++;
}
else
break;
}
if(c>0)
x++;
}
printf("%lld\n",x+n);
}
return 0;
}