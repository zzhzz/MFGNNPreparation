#include <stdio.h>               
int main() {int T=0,N,count,i,temp,j;
            scanf("%d",&T);
            if(T>=1&&T<=5){
            while(T--)
                       {count=0;
                        scanf("%d",&N);
                        temp=N;
                        if(N>=1&&N<=100000){
                        long int a[N];
                        for(i=0;i<N;i++){
                            scanf("%ld",&a[i]);
                            if(i>0){
                                if(a[i-1]<a[i])
                                count++;
                            }
                              }
                        for(i=0;i<N-1;i++){
                            for(j=i+1;j<N;j++){
                                if(a[i]==a[j]){temp--;break;}
                                }
                        }
                        }
                        printf("%d\n",count+temp);
                       }
            }
             return 0;
}