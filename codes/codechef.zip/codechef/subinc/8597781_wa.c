#include<stdio.h>
#include<malloc.h>
int main()
{
    int n,t,d,i,j,count,step=0,k;
    int *a;
    scanf("%d",&n);
    a=(int*)malloc(n*sizeof(int));

    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);

    }

for(k=0;k<n-1;k++)
  {
      i=k+1;
      while(i<n)
      {
          count=0;
          if(a[i-1]<=a[i])
          {
              count++;
              step=step+count;
              i++;

      }
      else
        break;

  }
  }
  d=n+step;
  printf("%d",d);


    return 0;
}
