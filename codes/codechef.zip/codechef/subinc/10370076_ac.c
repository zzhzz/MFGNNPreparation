#include<stdio.h>

int main()
{
    int in[100000], i,j,n,count;
    int res[5],t,k = 0;

    scanf("%d",&t);

    if(t < 0 || t > 5)
        return 0;

    while(k < t)
    {
//        printf("Enter value of n\n");
        scanf("%d",&n);



        for(i = 0; i < n; i++)
            scanf("%d",&in[i]);
    
        count = n;
    
        for(i = 0; i < n; i++)
            for(j = i; j < n - 1; j++)
                if(in[j] <= in[j+1])
                    count++;
                else
                    break;
    
        res[k++] = count;
    }
    for(i = 0; i < t; i++)
        printf("%d\n", res[i]);
    return 0;
}
