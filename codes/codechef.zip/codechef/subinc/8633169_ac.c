#include <stdio.h>

int main(void) {
	int t,i;
	long long int n,sum=0;
	scanf("%d\n",&t);

	while(t--){
	    sum=0;
	    scanf("%lld\n",&n);
	   long long int a[n],b[n];
	    for(i=0;i<n;i++) scanf("%lld",&a[i]);
	    for(i=0;i<n;i++)b[i]=1;
	    for(i=1;i<n;i++){
	        if(a[i]>a[i-1])b[i]=b[i]+b[i-1];
	        else if(a[i]<a[i-1]) b[i]=1;
	        
	    }
	    for(i=0;i<n;i++)sum=sum+b[i];
	    printf("%lld\n",sum);
	    
	}
	return 0;
}
