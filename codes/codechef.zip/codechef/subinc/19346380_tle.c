#include<stdio.h>
main()
{long int n, t,i,j;
scanf("%ld",&t);
while(t--)
{scanf("%ld",&n);
long int a[n],count=0;
for(i=1;i<=n;i++)
scanf("%ld",&a[i]);
for(i=1;i<=n;i++)
{for(j=i+1;j<=n;j++)
{if(a[i]>a[j])
count++;}}
printf("%ld\n",count);}}
