#include<stdio.h>
int main(){
    int n,t,i,j,max,count;
    int a[1000];
    scanf("%d",&t);
      // printf("hi%d",t);
    while(t--){
        count=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
       count=n;
       for(i=0;i<n;i++){
           max=a[i];
           for(j=i;j<n;j++){
               if(a[i]<a[j] && max<a[j]){
                   //printf("%d%d\t",i,j);
                    count++;
                    max=a[j];
               }
           }
       }
        printf("%d\n",count);
    }
    return 0;
}