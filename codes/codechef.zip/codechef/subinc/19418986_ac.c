#include<stdio.h>
int main()
{
	int l,t,i,j,count,prev,cur,n,a[100000];
	scanf("%d",&t);
	for(l=0;l<t;l++)
	{
		scanf("%d",&n);
		count=0;
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			count++;
			//printf("%d count %d\n",a[i],count);
			for(j=i;j>0 && (a[j-1]<=a[j]);j--)
			{
				count++;
			}
		}
		
		printf("%d\n",count);
	}
	return 0;
}