#include<stdio.h>
int main()
{int t,n,i,j;
scanf("%d",&t);
while(t--)
{int count=0,b=0;
scanf ("%d",&n);
int a[n];
for (i=0;i<n;i++)
scanf ("%d",&a[i]);
for (i=0;i<n;i++)
{for (j=i+1;j<n;j++)
{if(a[j-1]<=a[j])
count++;
else
break;}
b=b+count;
count=0;}
printf ("%d",b+n);
}
return 0;}