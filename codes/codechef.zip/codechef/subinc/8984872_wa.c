#include <stdio.h>

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long int n,i,k=0,j;
        scanf("%ld",&n);
        long long int ar[n],ns=n;
        for(i=0;i<n;i++)
        {
            scanf("%lld",&ar[i]);
            //printf("%lld",ar[i]);
        }
        long int pos=0;
        int test=0;
        int counter=0;
        
           
                for(j=1;j<n;j++)
                {// printf("%ld\n",i);
                
                    if(ar[j]>=ar[j-1])
                    {
                        pos=j;
                        //printf("%ld\n",pos);
                    }
                    else
                    {   counter=1;
                        long int temp=pos-k;
                        ns=ns+(temp*(temp+1))/2;
                        k=j;
                    }//printf("%ld\t%ld\t%lld\n",pos,k,ns);
                
                }  //printf("%ld\t%ld\t%lld\n",pos,i,ns);
                if(counter==0)
                ns=ns+(n*(n-1))/2;
                //printf("%ld\t%ld\t%lld\n",pos,k,ns);
                ns=ns+((pos-k)*(pos-k+1))/2;

            printf("%lld\n",ns);
        
    }
    return 0;
}
