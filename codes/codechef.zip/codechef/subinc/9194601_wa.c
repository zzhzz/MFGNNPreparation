#include<stdio.h>
#include<stdlib.h>
#define max 100000
int main()
{
    int t,i,j;
    scanf("%d",&t);
    while(t>0&&t<=5)
    {
            long long int co=0;
            long int a[max],n;
            scanf("%ld",&n);
            for(i=0;i<n;i++)
                scanf("%ld",&a[i]);
            for(i=0;i<n;i++)
            {
                for(j=i;j<n;j++)
                {
                    if(a[j]<=a[j+1]&&j!=(n-1))
                        co++;
                    else
                        break;
                }
            }
            printf("%lld",co+n);
            t--;
        }

    return 0;
}
