#include<stdio.h>

int main(){
		
	long long int i,n,t,k,l;
	long long int a[1000];
	long long int count=0,op[5];
	scanf("%d",&t);
	
	for(i=0;i<t;i++){
		
		
		scanf("%d",&n);
		
		for(k=0;k<n && scanf("%d",&a[k]);k++);
		

		//Compare
		
		for(l=0;l<n-1;l++){
			
			for(k=l+1;k<n;k++){
				

				
				if(a[k-1]<a[k]){
					
					count++;
					
				}else{
					
					break;
				}
				
			}
		
		}
		
		op[i]=count+n;
			
			count=0;
		
	}
	
	//print result
	
	for(i=0;i<t;i++){
		
		printf("%d \n",op[i]);
		
	}	
	return 0;
}