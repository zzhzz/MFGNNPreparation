#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		long long int n,i,j=1,k=0;
		scanf("%lld",&n);
		long long int a[n];
		for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
		for(i=1;i<n;i++)
		{
			if(a[i]>a[i-1])
			{
				j++;	
			}
			else if(j>1)
			{
				k++;	
			}
			else
			j=1;
		}
		if(j>1)
		k+=++n;
		else
		k+=n;
		printf("%lld",k);
	}
	return 0;
}