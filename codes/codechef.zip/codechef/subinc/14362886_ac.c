#include<stdio.h>
#include<string.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d",&n);
		int sum=1,ctr=1,current,element,i;
		scanf("%d",&current);
		
		for(i=0;i<n-1;i++){
			scanf("%d",&element);
			if(element>=current){
				ctr++;
				current=element;
			}
			else{
				ctr=1;
				current = element;
			}
			sum+=ctr;
		}
		printf("%d\n",sum);
	}
}