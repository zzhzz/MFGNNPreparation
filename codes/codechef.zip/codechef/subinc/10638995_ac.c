#include<stdio.h>
int main()
{
	int t,n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		long long int arr[n];
		long long int dp[n];
		int i;
		for(i=0;i<n;i++)
		{
			scanf("%lld",&arr[i]);
		}
		for(i=0;i<n;i++)
		{
			dp[i]=0;
		}
		for(i=1;i<n;i++)
		{
			if(arr[i-1]<arr[i])
			{
				dp[i]=dp[i-1]+1;
			}
		}
		long long int sum=0;
		for(i=0;i<n;i++)
		{
			sum=sum+dp[i];
		}
		sum=sum+n;
		printf("%lld\n",sum);
	}
	return 0;
}