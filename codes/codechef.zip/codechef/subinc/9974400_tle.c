#include<stdio.h>
int main()
{
    int a[100000],n,t,i,sum,j,temp;

    scanf("%d",&t);

    while(t--)
    {
        sum=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
        if(n==1)
        {
            printf("a[1,1]\n");
            sum=1;
        }

        else
        {
            for(i=0;i<n;i++)
            {
                for(j=0;j<n;j++)
            {
                if(a[j]>a[i])
                {
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                }
            }
            }


            for(i=0;i<n;i++)
            {
                for(j=i;j<n;j++)
                {
                    if((a[i]==a[j]||(a[i]+1)==a[j]))
                    {
                        printf("a[%d,%d]\n",a[i],a[j]);
                        sum++;
                    }

                }
            }
        }

        printf("%d\n",sum);


    }

    return 0;
}
