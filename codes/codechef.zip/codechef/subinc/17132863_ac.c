#include<stdio.h>

int main()
{
    long long T,count,N,i,val,ans;
    scanf("%lld",&T);
    while(T--)
    {
        scanf("%lld",&N);
        long long A[N+1],dp[N+1];
        A[0]=0;
        for(i=1;i<N+1;i++)
        {
            scanf("%lld",&A[i]);
        }
        dp[0]=0;
        for(i=1,ans=0,count=0;i<N+1;i++)
        {
            if(A[i]<A[i-1])
                count=1;
            else
                count++;
            dp[i]=dp[i-1]+count;
        }
        printf("%lld\n",dp[N]);
    }
    return 0;
}
