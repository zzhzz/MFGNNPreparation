#include <stdio.h>
 
int main(void) {
	int t,n,i,j;
	long long ans,sum;
	scanf("%d",&t);
	while(t--) {
		scanf("%d",&n);
		long a[n];
		for(i=0;i<n;i++)
			scanf("%ld",&a[i]);
		
		ans=0;
		sum=1;
		for(i=0;i<n-1;i++) {
			if(a[i]<=a[i+1]) {
				sum++;
			}
			else {
				ans += sum*(sum+1)/2;
				sum=1;
			}
		}
		ans += sum*(sum+1)/2;
		printf("%lld\n",ans);
	}
	return 0;
}