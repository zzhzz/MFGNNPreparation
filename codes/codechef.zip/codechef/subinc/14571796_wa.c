#include <stdio.h>

int main ( ) {
  int t;
  scanf("%d",&t);
  while(t--) {
    int n;
    scanf("%d",&n);
    long long int arr[n+1];
    int i,j;
    long long int count=0;
    for(i=0;i<n;i++) {
      scanf("%lld",&arr[i]);
      count++;
      for(j=i-1;j>=0;j--){
         if(arr[i]>arr[j])
           count++;
         else
           break;
         }
       }
     printf("%lld\n",count);
   }
  return 0;
 }