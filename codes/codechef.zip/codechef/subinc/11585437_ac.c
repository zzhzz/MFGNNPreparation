#include<stdio.h>
long long int a[100000000];
int main()
{
    long long int j,n,i,c=0;
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%lld",&n);
        c=0;
        for(i=0;i<n;i++)
        {
            scanf("%lld",&a[i]);
        }
        for(i=0;i<n;i++)
        {
            for(j=i;j<n;j++)
            {
                if(a[i]<=a[j])
                c++;
                if(a[j]>a[j+1])
                break;
            }
        }
        printf("%lld\n",c);
    }
    return 0;
}
