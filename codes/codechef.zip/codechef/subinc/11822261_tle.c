#include <stdio.h>
int chck(int a[],int l,int u)
{
int flag=1,i;
for(i=l;i<u;i++)
{
if(a[i]>a[i+1])
flag=0;
}
return flag;
}
int main(void) {
	// your code goes here
	int t,i,j,n,c,a[100001];
	scanf("%d",&t);
	while(t--)
	{
	c=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
    for(j=i;j<n;j++)
    if(i==j)
    c++;
    else if(chck(a,i,j))
    c++;
	printf("%d\n",c);
	}
	return 0;
}
