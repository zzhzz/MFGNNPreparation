#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{ int n,b=0,sum=0,c=0;
      scanf("%d",&n);
      int ar[n];
      while(b<n)
      {
         scanf("%d",&ar[b]);
         ++b;
      }
      while(c<n-1)
      { int d=c,x=0;
         while(d<n)
         { 
            if(ar[d]<=ar[d+1])
            {
               x++;
            }
            else
            {
               break;
            }++d;
         }if(x>0)
         {
            sum=sum+1;
         }++c;
      }
      printf("%d\n",(sum+n));
	}return 0;
}