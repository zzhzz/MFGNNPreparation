#include <stdio.h>
 
int main()
{
    int T;
    long long int k,N;
    scanf("%d\n",&T);
    while(T--){
     scanf("%lli\n",&N);
    long long int a[N],j,M;
         for(j=0;j<N;j++)
         scanf("%lli",&a[j]);
         M=N;
         N= N-1;
         while(N--)
         {
         if(a[N-1]<a[N])
         M=M+1;
         }
         printf("%lli\n",M);
    }
    return 0;
}