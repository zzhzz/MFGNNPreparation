#include<stdio.h>
#include<math.h>
int main()
{
 int t;
 scanf("%d",&t);
 while(t--)
 {
  unsigned long long n,len=1,count,ans=0;
//  unsigned long arr[1000];
  scanf("%llu",&n);
  unsigned long arr[n];
  for(count=0;count<n;count++)
   scanf("%lu",&arr[count]);
  for(count=0;count<n-1;count++)
  {
   if(arr[count+1]>=arr[count])
    len++;
   else
   {
    ans+=(len*(len+1))/2;
    len=1;
   }
  }
  ans+=(len*(len+1))/2;
  printf("%llu\n",ans);
 }
 return 0;
}