#include<stdio.h>

int main()
{
	int arr[100001],n,i,size,j,count=1,sub=0,tc[6],t=0;
	
//	printf("Enter the number of test cases:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		sub=0;
	//	printf("Enter the size of the array :");
		scanf("%d",&size);
		for(j=0;j<size;j++)
		{
			scanf("%d",&arr[j]);
		
		}
		for(j=0;j<size;j++)
		{
		
			count=1;
			while(arr[j+1]>arr[j])
			{
				count++;
				j++;
			}
			sub+=(count*(count+1))/2;
		//	j--;
			
		}
	tc[t++]=sub;
	}
	printf("\n");
	for(i=0;i<t;i++)
	printf("%d\n",tc[i]);
	return 0;
}
