#include <stdio.h>

int main(){
int t;
scanf("%d",&t);
while(t-- > 0){
    int n,i;
    long long int sum=0;
    scanf("%d",&n);
    long long int a[n];
    for(i=0;i<n;i++){
        scanf("%lld",&a[i]);
    }

    int d[n];
    d[n-1]=0;
    for(i=n-2;i>=0;i--){
        if(a[i]<=a[i+1]){
        d[i]=d[i+1]+1;
        }else{
        d[i]=d[i+1];
        }
    }
    printf("%d\n",d[0]+n);
}

return 0;
}
