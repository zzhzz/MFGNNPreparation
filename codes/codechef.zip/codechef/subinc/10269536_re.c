#include<stdio.h>
long  int a[10000];
int main()
{
	long int n,t,i,s,j,k,p;
	scanf("%ld",&t);
	while(t--)
	{
		k=0;
		scanf("%ld",&n);
		for(i=0;i<n;i++)
		{
			scanf("%ld",&a[i]);
		}
		for(i=0;i<n;i++)
		{
			
			for(j=i;j<n;j++)
			{
				if(a[i]<=a[j])
				{
					if(i==j || j==i+1)
					k++;
				}
				
    		}
		}
		printf("%ld\n",k);
	
	}
}