#include <stdio.h>
int func(int A[],int i,int j){
int n=i,flag=1;
  for(n=i;n<j;n++){
   if(A[n]>A[n+1]){flag=0; 
     break;
  }
  }
  return flag;
}
 
int main(){
int i,test_no;
scanf("%d",&test_no);
  for(i=0;i<test_no;i++){
   int N;
   scanf("%d",&N);
   int A[N];
   int z;
   for(z=0;z<N;z++)scanf("%d",&A[z]);
   int a,b,t_c=0;
      for(a=0;a<N;a++){
          for(b=a;b<N;b++){
             if(func(A,a,b))t_c++;
            }   
       }
       printf("%d",t_c);
    }
} 