#include <stdio.h>
 
int main() 
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,i,j,k=0,m=0,d,b=0;
        scanf("%d",&n);
        long long int a[n];
        for(i=0;i<n;i++)
        {
            scanf("%lld",&a[i]);
        }
            for(j=0;j<n;j++)
            {
                if(j!=n-1&&a[j+1]-a[j]>=0)
                k++;
                else if(a[j]-a[j-1]>=0&&j>0)
                {
                d=k-b;
                m=m+(d*(d+1))/2;
                b=k;
                }
                else
                continue;
        
            }
        printf("%d\n",m+n);
    }
	return 0;
}