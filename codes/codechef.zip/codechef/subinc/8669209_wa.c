#include <stdio.h>

int main(void) {
		int t,n,a[100000],i,ctr[100000],j=0;
	scanf("%d",&t);
	int x=t;
	while(t--)
	{
		ctr[j]=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			if(i!=0)
			{
				if(a[i]>a[i-1])
				ctr[j]=ctr[j]+1;
			}
		}
		ctr[j]=ctr[j]+n;
		j=j+1;
	}
	for(i=0;i<x;i++)
	printf("%d\n",ctr[j]);
	
	return 0;
}

