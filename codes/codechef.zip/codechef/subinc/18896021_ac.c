#include<stdio.h>
int main()
 {
  int arr[100000],t,n,i,ans=1,prev=1;
  scanf("%d",&t);
  while(t--)
   {
    scanf("%d",&n);
	ans=1,prev=1;
	for(i=0;i<n;++i)
	 scanf("%d",&arr[i]);
	for(i=1;i<n;++i)
     {
      if(arr[i-1]<arr[i])
	   {
		prev=prev+1;   
        ans=ans+prev;
	   }
      else
       {
        prev=1;
        ans=ans+prev;
       } 
     }
    printf("%d\n",ans);
   }
  return 0;
 }  