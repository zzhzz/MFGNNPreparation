#include <stdio.h>
int a[100001];
int main(void) {
       int t,n,i,j,C,c,x;
      long long  int s;
       scanf("%d",&t);
       while(t--)
       {
       	scanf("%d",&n);
       	for(i=0;i<n;i++)
       	{
       		scanf("%d",&a[i]);
       	}
       	for(i=1,C=0;i<n;i++)
        {
            if(a[i]==a[0])
                C++;
        }
        for(i=0,s=0;i<n-1;i++)
        {
            for(j=i+1,x=0,c=0;j<n;j++)
            {
                if(a[j]>=a[j-1])
                    c++;
                else
                {
                    x=1;
                    break;
                }
            }
            if(x)
            {
            s=s+(c*(c+1))/2;
            i=j-1;
            }else
                s=s+c;

        }
  if(C+1==n && n!=1)
    printf("%d\n",n+1);
  else
    printf("%lld\n",s+n);
       }
	return 0;
}
