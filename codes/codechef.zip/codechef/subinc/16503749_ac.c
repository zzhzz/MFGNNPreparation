#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        int a[n];
        for(int i=0;i<n;i++)
            scanf("%d",&a[i]);
        long long int max=n;
        for(int i=0;i<n;i++)
        {
            int x=i+1;
            while(x<n && a[x]>=a[x-1])
            {
                max++;
                x++;
            }
        }
        printf("%lld\n",max);
    }
    return 0;
}
