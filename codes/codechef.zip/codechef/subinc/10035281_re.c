#include<stdlib.h>
#include<stdio.h>
void main()
{
    int i,c=1,sum=0;
    int a[1000],n,t,j;
    scanf("%d",&t);
 for(j=0;j<t;j++)
        
 {
     
    scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }

    for(i=0;i<n-1;i++)
    {
         if(a[i]<=a[i+1])
        {
            c++;

        }
        else
        {
            sum=sum+((c*(c+1))/2);
            c=1;
        }
    }
        sum+=c*(c+1)/2;

    printf("%d\n",sum);

 }

}
