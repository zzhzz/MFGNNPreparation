#include<stdio.h>
main()
{
      int i,j,k,n,m,l,c,t;
      scanf("%d",&i);
      for(j=1;j<=i;j++)
      {
                       
                       c=0;
                       printf("\n");
                       scanf("%d",&n);
                       int a[n];
                       for(k=0;k<n;k++)
                       scanf("%d",&a[k]);
                       for(l=0;l<n;l++)
                       {
                                       t=0;
                                       for(m=l;m<n;m++)
                                       {
                                                       if(a[l]<=a[m])
                                                       {if(a[m]>t)
                                                       {c++;
                                                       t=a[m];
                                                       printf("\n%d %d",a[l],a[m]);
                                                       }
                                                       }
                                       }
                       }
                       printf("\n%d",c);
                       }
                       return 0;
                       }
