#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long long int a[100000];
		long long int i,n,count=0,n1=1;
		scanf("%lld",&n);
		for(i=0;i<n;i++)
			scanf("%lld",&a[i]);
		for(i=0;i<n-1;i++)
		{
			if(a[i]<a[i+1])
				n1++;
			else
			{
				count+=((n1*n1)/2)-(n1/2);
				n1=1;
			}
		}
		count+=((n1*n1)/2)-(n1/2);
		printf("%lld\n",count+n);
	}
	return 0;
}