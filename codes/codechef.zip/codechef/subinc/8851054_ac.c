#include<stdio.h>
int main()
{
    long long int n, a[100000], i, j, ct[100000], sum[5], t, x;

    scanf("%lld", &t);
    x=t;
    while(t)
    {
        scanf("%lld", &n);
        for(i=0; i<n; i++)
            scanf("%lld", &a[i]);

        i=0;
        j=0;
        while(1)
        {
            ct[j]=1;
            while(a[i+1]>=a[i])
            {
                ct[j]++;
                i++;
            }
            j++;
            i++;
            if(i==n)
                break;
        }

        sum[t]=0;
        for(i=0; i<j; i++)
            sum[t]+=ct[i]*(ct[i]+1)/2;
        t--;
    }

    for(i=x; i>0; i--)
       printf("%lld\n", sum[i]);

    return 0;
}
