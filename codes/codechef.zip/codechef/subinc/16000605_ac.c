#include <stdio.h>
#include<string.h>
#include<math.h>
#define fo(i,n)   for(i=0;i<n;++i)
	int t,n,*a,i,c,j;

int count()
{
    for(j=i,c++;a[j]<=a[j+1];++j)   c++;
}

int main(void) {
	scanf(" %d",&t);
	while(t--)
	{
	    scanf(" %d",&n);
	    a=(int *)(malloc(sizeof(int)*n));
	    fo(i,n)         scanf(" %d",&a[i]);
	    c=0;
	    fo(i,n)         count();
	    printf("%d\n",c);
	}
	return 0;
}

