#include<stdio.h>
int main()
{
    long long int n,a[100000],i,t,k=0,j;
    scanf("%lld",&t);
    while(t)
    {
        scanf("%lld",&n);
        for(i=0;i<n;i++)
        scanf("%d",&a[i]);
        k=0;
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n-1;j++)
            {
                if(a[i]<a[j])
                {
                    k++;
                }
            }
        }
        printf("%lld\n",k+n);
        t--;
    }
}