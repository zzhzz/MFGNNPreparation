#include<stdio.h>
void main(){
int t,n,i,j,x;
int a[10000],b[10000];
scanf("%d",&t);
while(t--){
scanf("%d",&n);
scanf("%d",&j);
 for(i=0;i<n;i++){
   scanf("%d",x);
if(x>=j){
b[i]=b[i-1]+1;
}
else{b[i]=1;}
 }
for(i=0;i<n;i++){printf("%d",b[i]);}
}
return 0;
}
