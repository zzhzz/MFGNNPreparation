#include <stdio.h>

int main(void) {
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; i++) {
	    long long int k;
	    scanf("%lld", &k);
	    long long int a[k];
	    int f = 0, count = k;
	    for(int j = 0; j < k; j++)
	        scanf("%lld", &a[j]);
	   for(int j = 0; j < k; j++) {
	       int s = j;
	       while(a[s + 1] >= a[s] && s < k - 1) {
	           count++;
	           s++;
	       }
	   }
	   printf("%d\n", count);
	}
	return 0;
}

