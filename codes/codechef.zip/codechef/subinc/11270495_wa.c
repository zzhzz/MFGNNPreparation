#include<stdio.h>
void main()
{
	int t,n,i=0,j,max,sum=0;
	long long int a[100000];
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
		i=0;
		while(i<n)
		{
			j=i;
			max=a[i];
			while(a[j]>=max)
			{
				max=a[j];
				j++;
			}
			sum+=((j-i)*(j-i-1))/2;
			i=j;
		}
		printf("%d\n",sum+n);
		sum=0;
	}
}