#include <stdio.h>
long long sum(long long);
int main(){
	long long t, n, arr[100000]={}, i, j, count;
	scanf("%lld", &t);
	while(t--){
		count = 0;
		scanf("%lld", &n);
		for(i = 0; i < n; i++)
			scanf("%lld", &arr[i]);
		for(i = 0; i < n; i++){
			j = 1;
			while ((arr[i] <= arr[i+1]) && (i + 1 < n)){
				i++;
				j++;
			}
			count += sum(j);	
		}
		printf("%lld\n", count);
	}
	return 0;
}
long long sum(long long n){
	long long s;
		s = n*(n+1)/2;  
	return s; 
}