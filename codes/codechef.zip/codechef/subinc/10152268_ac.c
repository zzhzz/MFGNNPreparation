#include<stdio.h>
int main(){
	int t,i;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		long long int n,j;
		scanf("%lld",&n);
		long long int a[n];
		for(j=0;j<n;j++) 
			{
				scanf("%lld",&a[j]);
			}
			if(n==1) printf("1\n");
			else{
		unsigned long long int ans=0;
		long long int x=0;
		long long int y=0;
		while(x<n-1){
		for(j=x;j<n-1;j++){
			if(a[j]<=a[j+1]) y++; 
			else break;
			}
			ans=ans+((y-x+2)*(y-x+1)/2);
			x=y+1;
			y=x;
		}
		if(a[n-1]<a[n-2]) ans++;
		printf("%llu\n",ans);
			}
		}
			return 0;
		}
		