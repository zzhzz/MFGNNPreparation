#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>

int main()
{
    unsigned int T,p;
    T=p=0;
    scanf("%u",&T);
    for(p=0;p<T;p++)
    {
       unsigned long int N,i,j,op;
       N=i=j=op=0;
       scanf("%lu",&N);
       unsigned long int A[N];
       memset(A,0,sizeof(A));
       i=0;
       op=N;
       for(i=0;i<N;i++)
       {
           scanf("%lu",&A[i]);
       }
       i=0;
       for(i=0;i<N;i++)
       {
           for(j=i+1;j<N && (A[j]>=A[j-1]);j++,op++)
           {
                /**
                if(A[j]>=A[j-1])
                {
                    op++;
                }
                else
                break;
                **/
                
           }
       }
       printf("%lu\n",op);
    }
    
    return 0;  
}

