#include<stdio.h>
int main(){
    int n,t,i,j,max,count;
    int a[1000];
    scanf("%d",&t);
    while(t--){
        count=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        for(i=0;i<n;i++){
            max=i;
            for(j=0;j<n;j++){
                if(j>max)
                    max=j;
                else
                    count++;
            }
        }
        printf("%d\n",count);
    }
    return 0;
}