#include<stdio.h>
int main()
{
	unsigned long long a[100000],n,c,count,i;
	int t;
	scanf("%d",&t);
	while(t--)
	{
	count=0;
	scanf("%llu",&n);
	c=(n*(n+1))/2;
	for(i=0;i<n;i++)
	scanf("%llu",&a[i]);
	for(i=0;i<n-1;i++)
	{
	if(a[i+1]<a[i])
		count+=2*(i+1);
	}
	printf("%llu\n",c-count);	
	} 
	return 0;
}