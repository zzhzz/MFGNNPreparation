#include<stdio.h>
int main()
{
int t;
long long n,i,c,cs,x,a[100002];
scanf("%d",&t);
while(t--)
{
cs=0;
scanf("%lld",&n);
a[n]=0;
for(i=0;i<n;i++)
{
scanf("%lld",&a[i]);
}
c=1;
for(i=0;i<n;i++)
{

if(a[i]<=a[i+1])
{
c++;
}
else
{
if(c>1)
{
x=(c*(c-1))/2;
cs=cs+x;
}
c=1;
}

}
cs+=n;
printf("%lld\n",cs);
}
return 0;
}
