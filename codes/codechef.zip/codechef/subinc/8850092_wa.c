#include<stdio.h>


int main(){
    long long int i,j,A[100000],N,T,count,sum=0,m;
    scanf("%lld",&T);
    for(i=0;i<T;i++){
        count=1;
        sum=0;
        scanf("%lld",&N);
        m=N;
        for(j=0;j<N;j++)scanf("%lld",&A[j]);
            for(j=1;j<N;j++){
                count=1;
                while(A[j-1]<=A[j]){
                    count++;
                    j++;
                }
                sum+=((count)*(count+1))/2;
            }
            if(N==1)sum=1;
            printf("%lld\n",sum);
    }

}
