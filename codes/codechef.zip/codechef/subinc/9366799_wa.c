#include<stdio.h>
#include<stdlib.h>
int main()
{
	int i,t,j,k=0,count=0,n=0;
	long int N,*A;

	scanf("%d",&t);
	while(t>0)
	{
	
	
	scanf("%ld",&N);
	if(N>=1&&N<=100000)
	{
	
	A=(long int*)malloc(N*sizeof(long int));
	for(i=0;i<N;i++)
	{
		scanf("%ld",&A[i]);
	
		
	}
	
	for(i=0;i<N;i++)
	{	if(A[i]>=1&&A[i]<=1000000000)
		{
		j=i+1;
		k=i;
		count=0;
		while(j<N)
		{ 
			if(A[k]<=A[j])
			{
				k=j;
				j++;
				count++;
				continue;
			}
			else
			break;
	}
		n=n+count;
	}
	}
}
	t--;
}
	printf("\n%d",n+N);
	return 0;
	
}