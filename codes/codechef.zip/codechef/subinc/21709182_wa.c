
#include<stdio.h>
#include<stdlib.h>

void main()
{
int N;int T;int t[5];
int *a;int i;int j;
scanf("%d \n",&T);int c=0;int k=0;
while(T>0)
    {
        scanf("%d \n",&N);
        a=(int *)malloc(N*sizeof(int));
        for(i=0;i<N;i++)
        {
            scanf("%d ",&a[i]);
        }
        /*for(i=0;i<N;i++)
        {
            printf("%d ",a[i]);
        }*/
        int length=1;
        for(i=0;i<N-1;i++)
        {
           // printf("%d \n",a[i]);
            if (a[i + 1] >= a[i]) 
                length++;
            else
            {   
                c += (((length +1) * length) / 2); 
                length = 1; 

            }    
        }
        c += (((length +1) * length) / 2); 
    printf("%d \n",c);
    c=0;
    T--;
    }
    
}
