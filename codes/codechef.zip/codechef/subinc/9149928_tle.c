#include<stdio.h>
int main()
{
long long int t,i,j,k,n[7][100000],flag;
scanf("%lld",&t);
for(i=0;i<t;i++)
{
scanf("%lld",&n[i][0]);
for(j=1;j<n[i][0];j++)
scanf("%lld",&n[i][j]);
}
for(i=0;i<t;i++)
{k=1;flag=0;
while(k<n[i][0])
{j=1;
	while(j<n[i][0])
	{
	if(n[i][j]<n[i][j+1])
	flag++;
	j++;
	}
	k++;
}
flag=flag+n[i][0];
printf("%lld\n",flag);
}
return 0;
}