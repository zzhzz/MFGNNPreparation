#include<stdio.h>
int main(){
    long int t,n,i,j,c,temp;
    scanf("%ld",&t);
    while(t--){
        scanf("%ld",&n);
        long int a[n];
        for(i=0;i<n;i++)
        scanf("%ld",&a[i]);
        temp=0;
        for(i=0;i<n;i++){
        c=0;
        for(j=0;j<n;j++){
            if(i==j)
            continue;
            else if(a[i]<a[j])
            c++;
        }  temp+=c;  //printf("%ld\n",c);
        }if(n==1)
        printf("1\n");
        else
        printf("%ld\n",temp);
    }
    return 0;
}