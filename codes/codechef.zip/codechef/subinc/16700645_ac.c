#include <stdio.h>

int main(void) {
	// your code goes here
	long long int t;
	scanf("%lld",&t);
	long long int a[t],i,j,k,count,ans,sum,h=0;
	for(i=0;i<t;i++)
     {      count=0;
            sum=0;
            h=0;
     	scanf("%lld",&a[i]);
     	long long int b[a[i]];
     	
     	for(j=0;j<a[i];j++)
     	{
     		scanf("%lld",&b[j]);
     	}
     	if(a[i]==1)
     	{
     		printf("1\n");
     	}
     	else{
     	for(j=0;j<a[i];j++)
     	{    count=0;
     	     h=0;
     	     ans=0;
     		for(k=j;k<a[i]-1;k++)
     		{   
     		    if(b[k]<=b[k+1])
     		    {       
     		    
     		    	count++;
     		    	ans=count*(count+1)/2;
     		    	if(k==a[i]-2)
     		    	{
     		    		h=1;
     		    		
 
     		    	}
     		    	
     		    
     		    }
     		    else{   
     		    	j=k;
     		    	break;
     		    	
     		    }
     			
     		}
     		
     		
     		sum=sum+ans;
     		if(h==1)
     		{
     			break;
     		}
     		
     	}
     	
     	printf("%lld\n",sum+a[i]);}
     	
     }
	return 0;
}
