#include <stdio.h>
long long int a[1000000];
int main(void) {
int t,n,i,size,count;
scanf("%d",&t);
while(t--){
	size=0;count=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
	for(i=1;i<n;i++)
	{
		if(a[i]<a[i-1])
		{
			if(size>1)
			{
				count++;
				size=1;
			}
			else{
				size=1;
			}
		}
		else{
			size++;
		}
	}
	if(size>1)
	printf("%d\n",count+n+1);
	else
	printf("%d\n",count+n);
}
	return 0;
}
