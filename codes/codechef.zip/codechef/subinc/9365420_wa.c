#include<stdio.h>
 main()
  { int i,j,k,n, count=0;
    int a[1000];
    printf("enter no. of elements of an array");
    scanf("%d",&n);
    printf("enter the elements of array");
      for(i=0;i<n;i++)
      scanf("%d",&a[i]);
   i=0;
    for(i=0;i<n;i++)
      {   for(j=i;j<n;j++)
            {k=j+1;
               if(a[k]<a[j])
                  break;
                
                 else if(k>n)
                  count++;
             }
        }
   }
                  
     