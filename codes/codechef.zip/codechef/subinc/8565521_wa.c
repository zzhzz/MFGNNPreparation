#include<stdio.h>
int main(){
	int t,n,i,j,k,count=0;
	long long int a[100000];
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d",&n);
		for(j=0;j<n;j++){
	scanf("%lld",&a[j]);
}
for(j=0;j<n-1;j++){
	for(k=j+1;k<n;k++){
		if(a[k-1]>a[k])
		break;
		count+=1;
	}
}
printf("%d\n",count+n);
}
return 0;
}