#include <stdio.h>

int main() 
{
    int i,j,t,k,count;
    long int a[100000],n;
    scanf("%d",&t);
    while(t--)
    {  
        scanf("%ld",&n);
        for(j=0;j<n;j++)
            scanf("%ld",&a[j]);
        count=0,j=0;
        while(j+1<n)
        {   k=j;
            if((a[j+1]>a[j]))
            {    j++;
            if(k!=j)
                count++;
            }else
                j++;
            
        }
        printf("%d\n",count+n);
        
    }
    
	// your code goes here
	return 0;
}