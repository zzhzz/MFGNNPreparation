#include<stdio.h>
int main(void)
{
    long long int t,i,j,n,k,c,a[100001],x,f;
    scanf("%lld",&t);
    for(i=0;i<t;i++)
    {
        scanf("%lld",&n);
        for(j=0;j<n;j++)
        {
            scanf("%lld",&a[j]);
        }
        if(n==1)
            printf("1\n");
        else
        {
            k=0;
            c=0;
            x=0;
        for(j=0;j<n;j++)
        {
            if(k==j)
            {
               if(a[k]<=a[j])
               {
                   c++;
               }
            }
            else
                {
                if(a[k]<=a[j])
               {
                   c++;
                   k++;

               }
                else
                {
                    x=x+(c*(c+1))/2;
                    c=0;
                    k=j;
                    j--;
                }
                }
        }
        x=x+(c*(c+1))/2;
                printf("%lld\n",x);
       }
    }
}


