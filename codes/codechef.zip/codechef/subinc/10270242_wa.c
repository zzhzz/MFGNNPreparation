#include<stdio.h>
int main()
{
	int test;
	scanf("%d",&test);
	while(test>0){
		long int i,j,n,count=0,a[100005],megacount=0;
		scanf("%ld",&n);

		for(i=1;i<=n;i++)
		{
			scanf("%ld",&a[i]);
		}

		count=1;
		for(j=2;j<=n;j++)
		{
			if(a[j]>=a[j-1]){
				count++;
			}
			else 
			{
				megacount=megacount+((count*(count+1))/2);
				count=1;
			}
			if(j==n && a[j]>=a[j-1])
			{
				megacount=megacount+((count*(count+1))/2);
			}
                        else if(j==n && a[j]<a[j-1])
                               megacount=megacount+1;
		}

if(a[1]>a[2])
megacount=megacount+1;
                 
                if(n>1)
		printf("%ld\n",megacount);
                else
                printf("1\n");
    
		test--;}
	return 0;
}
