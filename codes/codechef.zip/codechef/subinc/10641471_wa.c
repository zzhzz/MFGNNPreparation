#include <stdio.h>
#include <string.h>

int main()
{
	int N = 0, A[100000] = {0}, i = 0, T = 0;
	long long int count = 1, val = 0;

	scanf("%d", &T);

	while(T--)
	{
		scanf("%d", &N);
		for (i = 0; i < N; i++)
		{
			scanf("%d", &A[i]);
		}
		for(i = 0; i < (N-1); i++)
		{
			while(A[i] < A[i+1])
			{
				count++;
				++i;
			}
			val += (count*(count+1))/2;
			count = 1;
		}

		if(N==1)
		{
			val = 1;
		}
		printf("%lld\n", val);
		memset((void*)A, 0, sizeof(A));
		val = 0;
		count = 1;
	}
	return (0);
}
