#include<stdio.h>

int main()
{
int n,i,e,count;
int a[50];
int dp[50];
scanf("%d",&n);
while(n--)
{
    count=0;
    scanf("%d",&e);
 for(int i = 0; i < e ; i++ ) {
            scanf("%d", &a[i]);
        }

        
        dp[0] = 1;

for( int i = 1 ; i < e ; i++ ) {
            if(a[i] >= a[i-1]) {
                dp[i] = 1 + dp[i-1];
            }
            else {
                dp[i] = 1;
            }
        }

        for( int i = 0 ; i < e ; i++ ) {
            count+= dp[i];
        }

        printf("%d\n",count);
    }
    return 0;
}