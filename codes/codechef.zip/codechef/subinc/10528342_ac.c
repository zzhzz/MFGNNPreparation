#include<stdio.h>
#include<math.h>

int main()
{
    int t;
    long a[5][100000],n[5],count[5],i,j,l,k,b[100000],sum[5];
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d",&n[i]);
        for(j=0;j<n[i];j++)
        {
            scanf("%li",&a[i][j]);
            b[0] = 1;
                if(a[i][j] >= a[i][j-1] && j >= 1)
                {
                    b[j] = b[j-1] + 1;
                }
                else
                {
                    b[j] = 1;

                }
                //printf("%li\t",b[j]);
        }
        //printf("\n");
        sum[i] = 0;
        for(l=0;l<n[i];l++)
        {
            sum[i] = sum[i] + b[l];
        }
    }
    for(i=0;i<t;i++)
    {
        printf("%li\n",sum[i]);
    }
    return 0;
}
