#include<stdio.h>
#define max 1000 
int main()
{
	
    int i,j,k,count[max];
	int T,A[max],N,L,M;

	scanf("%i",&T);
	for(i=0;i<T;i++)
	{
		count[i]=0;
        scanf("%i",&N);
		for(j=0;j<N;j++)
			scanf("%i",&A[j]);
		for (j=0;j<N;j++)
		{
			L=j;
			M=j;
			k=j;
			while(A[M]>=A[L]&&k<N)
			   {
				L=M;
				M=k;
				k++;
				if(A[M]>=A[L])
				count[i]++;
			
			   } ;
	    }

    }

	for(i=0;i<T;i++)
		printf("%i\n",count[i]);
	return 0;
}
