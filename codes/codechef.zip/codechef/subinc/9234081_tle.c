#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
int t, i, j, k, l, n, sum, prod, flag;
scanf("%d", &t);
int ans[t];
for(i=0;i<t;i++)
{
    scanf("%d", &n);

    int arr[n];
    if(n==1) {scanf("%d", &arr[0]); ans[i]=n;} else {
    for(j=0;j<n;j++)
    {
        scanf("%d", &arr[j]);
    }

    for(j=0;j<n;j++)
    {
        ans[i]=n;
        for(k=0;k<=j;k++)
        {
            flag=0;
            for(l=k;l<j;l++)
            {
                if(arr[l]<=arr[l+1]) flag++; else break;
            }
            if(flag==(j-k)) ans[i]++;
        }

    }}
}
for(i=0;i<t;i++)
{
    printf("%d\n", ans[i]);
}

return 0;
}
