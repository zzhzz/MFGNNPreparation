#include<stdio.h>
int main(){
	int t;
	long long n,i,ans,num;
	long long int a[1000];
	scanf("%d",&t);
while(t){
	ans=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	num=0;
	for(i=0;i<n;i++){
		if(a[i]<=a[i+1]){
			num++;
		}
		else{
			ans+=(num*num+1)/2;
			num=1;
		}
		
	}
	ans+=(num*num+1)/2;
	printf("%d\n",ans);
		t--;
}

		return 0;
	}