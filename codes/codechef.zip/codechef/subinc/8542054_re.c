
#include<stdio.h>
int main()
{
	int i,j,k,l,m,n,c=0,arr[10];
	scanf("%d",&l);
	scanf("%d",&n);
        for(k=0;k<l;l++)
        {
            c=0;
	    for(i=0;i<n;i++)
	    {
		scanf("%d",&arr[i]);
	    }
	    for(i=0;i<n;i++)
	    {
		k=i;
		for(j=i;j<n;j++)
		{
			if(arr[k]<=arr[j])
			{
			   c++;
			   k=j;
			 }
			 else
			    break;
		}
	    }
	    printf("no. of subarry=%d",c);
         }
         return 0;
 } 
 