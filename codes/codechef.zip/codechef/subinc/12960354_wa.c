#include<stdio.h>
int main()
{
	long long int testCase,i;
	scanf("%lld",&testCase);
	
	for(i=0;i<testCase;i++)
	{
		long long int num,arr[100001],j;
		scanf("%lld",&num);
		long long int count=num;
		for(j=0;j<num;j++)
		{
			scanf("%lld",&arr[j]);
		}
		for(j=0;j<num;j++)
		{
			if(arr[j+1]>arr[j])
			{
				count++;
			}
		}
		printf("%lld\n",count);
	}
	return 0;
}