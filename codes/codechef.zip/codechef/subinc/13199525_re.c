#include<stdio.h>
int Calculate(int *,int);
int main()
{
    int a[1000],i,t,n,j,count;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d",&n);
        for(j=0;j<n;j++)
            scanf("%d",&a[i]);
        count=Calculate(a,n);
        printf("%d\n",count);
    }
    return 0;
}
int Calculate(int *a,int n)
{
    int i,count=0,j,temp1=0,temp2=0;
    for(i=0,j=1;i<n-1;i++,j++)
    {
        if(a[i]<a[j])
        {
            temp1++;
        }
        temp2++;
        if(temp2>temp1)
        {
            count++;
            temp1=temp2=0;
        }
    }
    return count+n;
}




