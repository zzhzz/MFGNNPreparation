#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t-->0)
    {
        int n,i,j=0,sum=0,m=0;
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        for(i=1;i<n;i++)
        {
            if(a[i]<a[i-1])
                {
                    m=i-j;
                    sum+=(m+1)*(m)/2;
                    j=i;
                }
        }
        if(j<i)
        {
            m=i-j;
            sum+=(m+1)*(m)/2;
            j=i;
        }

        printf("%d\n",sum);
    }
}
