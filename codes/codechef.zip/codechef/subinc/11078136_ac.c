#include<stdio.h>
int main()
{
  int t;
  scanf("%d",&t);
  while(t)
  {
    int n,i,j,c=0,flag=0;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
      scanf("%d",&a[i]);
    for(i=0;i<n;i++)
    {
      for(j=i;j<n;j++)
      {
          if(j==i)
            flag=1;
          else
            flag=0;
        if(a[i]<=a[j])
        {
           if(j!=0 && flag==1)
           {
             ++c;
             continue;
           }
          if(j!=0 && a[j-1]<=a[j])
            ++c;
          if(j!=0 && a[j-1]>a[j])
            break;
          if(j==0)
            ++c;
    }
        else
          break;
      }

      flag=0;
    }
      printf("%d\n",c);
    --t;
  }
  return 0;
}
