#include<stdio.h>
int main()
{
int n;
scanf("%d", &n);
int i=0,j=0,k=0,c=1,count=0;
for(i=0;i<n;i++)
{    c=1;
    count =0;
int s;
scanf("%d", &s);
int a[s];
for(j=0;j<s;j++)
scanf("%d", &a[j]);
for(j=0;j<s-1;j++)
{
if(a[j]<a[j+1])
c++;
else
{
for(k=c-1;k>0;k--)
count=count+k;
c=1;
}

}
if(c>1)
{
    for(k=c-1;k>0;k--)
count=count+k;
}
count =count +s;
printf("%d\n",count);
}
return 0;
}