#include<stdio.h>
int main()
{
        int T;
        scanf("%d",&T);
        while(T--){
        int N,A[10000];
        scanf("%d",&N);
        for(int i=0;i<N;i++)
        {
         scanf("%d",&A[i]);
         }
         int c=0;
     
        for (int startPoint = 0; startPoint <N ; startPoint++) {
            
            for (int grps = startPoint; grps <N; grps++) {
               
                if(A[startPoint]==A[grps]||(A[grps]-A[startPoint]==1))
                   c++;
            }
             }    
             printf("%d",c);
        } 
            return 0;}

