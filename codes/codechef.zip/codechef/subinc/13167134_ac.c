#include<stdio.h>
int main()
  {
  	int t,tc;
  	long long n,i,j,k,c;
  	scanf("%d",&t);
  	for(tc=1;tc<=t;tc++)
  	  {
  	  	c=0;
		scanf("%lld",&n);
		long long a[n];
  	  	for(i=0;i<n;i++)
  	  	  scanf("%lld",&a[i]);
  	  	for(j=0;j<n;j++)
  	      {
  	  	    for(k=j;k<n-1;k++)
  	  	  	  {
  	  	  	  	if(a[k]<=a[k+1])
  	  	  	  	  c++;
  	  	  	  	else
  	  	  	  	  break;
			  }
		  }
		  c=c+n;
		printf("%lld\n",c);
		
      }
  }
			
