#include <stdio.h>

int main(void) {
int t,i,j,k,count;
long long int n;
scanf("%d",&t);
for(k=0;k<t;k++)
{
    count=0;
    scanf("%lld",&n);
    long long int arr[1000];
    for(i=0;i<n;i++)
        scanf("%lld",&arr[i]);
    for(i=0;i<n;i++)
        {
            for(j=i;j<i+2;j++)
                {
                if(arr[i]<=arr[j])
                count++;
                }
        }
    printf("%d\n",count);
}
	return 0;
}
