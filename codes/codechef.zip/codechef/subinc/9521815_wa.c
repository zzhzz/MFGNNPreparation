#include<stdio.h>
main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long long int i,q,n;
		scanf("%lld",&n);
		long long int sum=0,count=0;
		long long int a;
		scanf("%d",&a);
		count++;
		q=a;
		for(i=1;i<n;i++)
		  {
		   scanf("%lld",&a);
	        
			  if(a<q || i==n-1)
	            {
	            	if(i==n-1)
	            	 count++;
	            	
				  sum+=(count*(count+1))/2;	
				   count=1;
				   q=a;
				}    
				else
				{
				count++;
				q=a;
			}
		  }
		  printf("%lld\n",sum);
	}
	return 0;
}