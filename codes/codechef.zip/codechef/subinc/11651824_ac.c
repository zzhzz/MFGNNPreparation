#include<stdio.h>
#include<stdlib.h>
main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long long n,i,*ptr;
		scanf("%d",&n);
		ptr=(long long *)malloc(n*sizeof(long long));
		for(i=0;i<n;i++)
		{
			scanf("%lld",&ptr[i]);
		}
		long long j;
		long long count=n;
		for(i=0;i<n;i++)
		{
			for(j=i;j<n-1;j++)
			{
				if(ptr[j]<=ptr[j+1])
				{
					count++;
				}
				else
				break;
			}
		}
		printf("%lld\n",count);
	}
}