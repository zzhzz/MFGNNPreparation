# include<stdio.h>
int main() 
{
long long int c,t,n,i,a[100000],j;
scanf("%lld",&t);
while(t--)
{
c=0;    
scanf("%lld",&n);
for(i=0;i<n;i++)
scanf("%lld",&a[i]);
c=n;
for(i=0;i<n-1;i++)
{
for(j=i+1;j<n;j++)
{
if(a[i]>a[j])    
break;
}
if(j==n)
c++;
}
printf("%lld\n",c);
}
return 0;
}