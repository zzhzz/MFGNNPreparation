#include <stdio.h>
#include <stdlib.h>

int main()
{

    int k,t,i,j,n,a[100000],l,m;
scanf("%d",&t);
for(j=0;j<t;j++)
{k=0;
    scanf("%d",&n);
    
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(l=0;l<n;l++)
    {
        for(m=l;m<n;m++)
         {

           if(a[m]<=a[m+1])
                k++;
        else
            break;
    }
    }
    printf("%d\n",k+n);
}
    return 0;
}
