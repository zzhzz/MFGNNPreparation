#include <stdio.h>
int main()
{
	int t,a=0;
	scanf("%d",&t);
	while(a<t)
	{ long int n,b=0,sum=0,c=0;
      scanf("%ld",&n);
      long int ar[100000];
      while(b<n)
      {
         scanf("%ld",&ar[b]);
         ++b;
      }
      while(c<(n-1))
      {
         if(ar[c]<ar[c+1])
         {
         	sum++;
         }
         ++c;
      }
      printf("%ld\n",(sum+n));
      ++a;
	}return 0;
}