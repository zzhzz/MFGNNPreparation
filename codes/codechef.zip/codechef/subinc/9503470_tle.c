#include <stdio.h>
#include <stdlib.h>

main()
{
    int i,j,t,n;
    scanf("%d",&t);
    while(t--)
    {int c=0;
        scanf("%d",&n);
        int a[n];
        for(i=1;i<=n;i++)
        {
            scanf("%d",&a[i]);
        }
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=i;j++)
            {
                if(a[i]<=a[j])
                {
                    c++;
                }
            }
        }
        printf("%d\n",c);
    }
    return 0;
}
