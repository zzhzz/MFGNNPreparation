#include<stdio.h>
int Calculate(int *,int);
int main()
{
    int a[1000],i,t,n,j,count;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d",&n);
        for(j=0;j<n;j++)
            scanf("%d",&a[i]);
        count=Calculate(a,n);
        printf("%d\n",count);
    }
    return 0;
}
int Calculate(int *a,int n)
{
    int i,count=0,j;
    for(i=0;i<n-1;i++)
    {
       for(j=i+1;j<n;j++)
       {
           if(a[i]<a[j])
           {
               count++;
           }
       }
    }
    return count;
}




