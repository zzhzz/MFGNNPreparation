#include<stdio.h>
int main(){
	int t,n,i,j,k;
	long long int a[100000],count=0;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d",&n);
		for(j=0;j<n;j++){
	scanf("%lld",&a[j]);
}
for(j=0;j<n-1;j++){
	for(k=j+1;k<n;k++){
		if(a[k-1]>a[k])
		break;
		count+=1;
	}
}
printf("%lld\n",count+n);
}
return 0;
}