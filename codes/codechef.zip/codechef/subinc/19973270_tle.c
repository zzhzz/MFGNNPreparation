#include<stdio.h>
int main()
{int t,n,i,j;
scanf("%d",&t);
while(t--)
{
 scanf("%d",&n);
int a[n],count=0;
for(i=0;i<n;i++)
scanf("%d",&a[i]);
for(i=0;i<n;i++)
{for(j=0;j<n&&j!=i;j++)
{if((a[i]-a[j])==1)
 count++;
}
}
printf("%d\n",n+count);
}
}
