#include<stdio.h>
int main()
{
    int a[100],i,j,k,s=0,T,b[100];
    scanf("%d",&T);
    while(T){
    int n;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    b[0]=1;
    for(i=1;i<n;i++)
    {
        {
            if(a[i]>=a[i-1]){
                b[i]=b[i-1]+1;
            }
            else
                b[i]=1;
        }
    }
    for(i=0;i<n;i++)
        s=s+b[i];
    printf("%d\n",s);
    T--;
    s=0;
    }
}
