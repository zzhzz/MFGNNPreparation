
#include <stdio.h>


int main() {
    
    long int T,i,N;
    scanf("%d",&T);
    for(i=0;i<T;i++)
    {
        scanf("%d",&N);
        long int A[N],i;
        for(i=0;i<N;i++)
        {
            scanf("%d", &A[i]);
        }
        
        int sum=0;
        for(i=0;i<N;)
        {
            int count=1;
            if(A[i]<=A[i+1])
            {
               while(A[i]<=A[i+1])
               {
                count++;
                i++;
               }
            }
            
            else i++;
            sum= sum+count;
            
        }
        printf("%d\n", sum);
    }
    
    
	return 0;
}
