#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        int i,arr[n],b[n],sum=0;
        for(i=0;i<n;i++)
            scanf("%d",&arr[i]);

        b[0]=1;
        for(i=1;i<n;i++)
        {
            if(arr[i-1]<=arr[i])
                b[i]=b[i-1]+1;
            else
                b[i]=1;
        }
        for(i=0;i<n;i++)
            sum=sum+b[i];
        printf("%d\n",sum);
    }
    return 0;
}
