#include <stdio.h>
int main(){
	int T;
	long int A[100001], acc, N, i, c;
	scanf("%d", &T);
	while(T--){
		scanf("%ld", &N);
		for(i=0; i<N; i++)
			scanf("%ld", &A[i]);
		A[N]=0;
		c=1, acc=1;
		for(i=1; i<N; i++){
			if(A[i]<= A[i+1]){
				c++;
				acc+=c;
			}
			else{
				acc+=1;
				c=1;
			}
		}
		printf("%ld\n", acc);
	}
	return 0;
}