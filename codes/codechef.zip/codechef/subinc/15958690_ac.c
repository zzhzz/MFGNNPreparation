# include <stdio.h>
int main()
{
	int t,i;
	scanf("%d",&t);
	while(t--)
	{
		long long int n,c=1,s=1;
		scanf("%lld",&n);
		int a[n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(i=1;i<n;i++)
		{
			if(a[i]<a[i-1])
			c=1;
			else
			 c++;
			 
			 s+=c;
		}
		printf("%lld\n",s);
	}
	return 0;
}