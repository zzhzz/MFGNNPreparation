#include<stdio.h>
#include<stdlib.h>
int main()
{
    int totTests,totArray;
    int i,j;
    scanf("%d", &totTests);
    for (i=0; i<totTests; i++)
    {
        int n=0;
        int total = 1;
        int start = 0;
        scanf("%d", &totArray);
        int array[totArray];
        for(j=0;j<totArray;j++)
        {   
            scanf("%d",&array[j]);
        }   

        while(1)
        {   
            if (totArray==1)
            {   
                n++;
                break;
            }   
            else 
            {   
            if ((n+1)>(totArray-1))
            {   
                total++;
                break;
            }   
            else if(array[n+1] >= array[n])
            {   
                total++;
                n++;
            }   
            else
            {
                start++;
                n = start;
                total++;
            }
            }
        }
        return 0;
    }
}