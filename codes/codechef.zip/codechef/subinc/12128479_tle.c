#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t;
    int i;
    int n;
    int f;
    int j;
    scanf("%d", &t);
    while(t--)
    {
        scanf("%d", &n);
        int a[n];
        for(i = 0; i < n; i++)
        {
            scanf("%d", &a[i]);
        }
        f = 0;
        for(i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                if(a[i] < a[j])
                {
                    f++;
                }
            }
        }
        if(n == 1)
        {
            printf("1\n");
        }
        else
        {
            printf("%d\n", f);
        }
    }
    return 0;
}
