#include<stdio.h>
int main()
{
	long long int t,i,n,a[100002],d[100002],temp,j;
	scanf("%lld",&t);
	for(i=0;i<t;i++)
	{
		scanf("%lld",&n);
		for(j=1;j<=n;j++)
		{
			scanf("%lld",&temp);
			a[j]=temp;
		}
		d[1]=1;
		if(a[2]>=a[1])
		{
			d[2]=3;
		}
		else
		{
			d[2]=2;
		}
		
		for(j=3;j<=n;j++)
		{
			if(a[j]>=a[j-1])
			{
				d[j]=2*d[j-1]-d[j-2]+1;
				
			}
			else
			{
				d[j]=d[j-1]+1;
			}
		}
		printf("%lld\n",d[n]);
	}
	return 0;
}