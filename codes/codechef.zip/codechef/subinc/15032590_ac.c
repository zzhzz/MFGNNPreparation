// Code By:- Kaustav Vats (2016048)
#include <stdio.h>
#include <string.h> // String library, to use methods like strlen().

int main()
{
	int T;
	scanf("%d", &T);
	while ( T-- > 0 )
	{
		int N;
		scanf("%d", &N);
		int Arr[N];
		for ( int i=0; i<N; i++ )
		{
			scanf("%d", &Arr[i]);
		}
		int Prev = Arr[0];
		long Count = 1;
		long Ans = N;
		for ( int i=1; i<N; i++ )
		{
			if ( Arr[i] >= Prev )
			{
				Count++;
			}
			else
			{
				Ans += ( Count*(Count+1)/2 )-Count;
				Count = 1;
			}
			Prev = Arr[i];
		}
		Ans += ( Count*(Count+1)/2 )-Count;
		printf("%ld\n", Ans);
	}

	return 0;
}