#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t!=0)
    {
        long int i,n;
        scanf("%ld",&n);
        long int c=1,c1=0,d=n;
        long int arr[n];
        for(i=0;i<n;i++)
        {
            scanf("%ld",&arr[i]);
        }
        i=0;
        while(i<(n-1))
        {
            c=1;
                while(arr[i+1]>arr[i])
                {
                        c++;
                        i++;
                        if(i==(n-1))
                        {
                            break;
                        }
                }
            i=i+1;
            c1=((c*(c+1))/2)-c;
            d=d+c1;
        }
        printf("%ld\n",d);
        t--;
    }
    return 0;
}
