#include<stdio.h>

#define READ_INT(_x)\
{\
	register int ch = getchar();\
	int temp = 0;\
	while(ch < 48)\
	{\
		ch = getchar();\
	}\
	while(ch >= 48)\
	{\
		temp = (temp << 3) + (temp << 1) + ch - 48;  	\
		ch = getchar();\
	}\
	(_x) = temp;\
}				

#define WRITE_INT(_x)\
{\
	register int i = 0;\
	char str[10];\
	long long temp = (_x);\
	do\
	{\
		*(str + i++) = temp % 10 + 48;\
		temp /= 10;\
	}while(temp != 0);\
	for(i--; i >= 0; i--)\
		putchar(*(str + i));\
}

int main (void)
{
	long long count, sum = 0;
	int t, n;
	register int a, b;
	READ_INT(t);
	while(t--)
	{
		READ_INT(n);
		READ_INT(a);
		count = 0;
		sum = 0;
		for(n--; n > 0; n--)
		{
			READ_INT(b);
			if(b >= a)
			{
				count++;
			}
			else
			{
				sum += (count * (count + 1) >> 1);
				count = 1;
			}
		}
		sum += (count * (count + 1) >> 1);
		WRITE_INT(sum);
		putchar('\n');
	}
	return 0;
}
