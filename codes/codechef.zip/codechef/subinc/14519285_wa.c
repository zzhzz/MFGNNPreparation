#include<stdio.h>
int main()
{   long a[100000],t,c,n,i;
	scanf("%ld",&t);
	while(t--)
	{   c=0;
		scanf("%ld",&n);
		for(i=0;i<n;i++)
		scanf("%ld",&a[i]);
		for(i=0;i<n-1;i++)
		{
			if(a[i+1]<a[i])
			c++;
		}
		if(a[n-2]<a[n-1])
		c++;
		printf("%ld\n",c+n);
	}
}