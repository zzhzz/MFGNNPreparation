#include <stdio.h>

int main(void) {
	unsigned long long int t,i,count,n,j;
	scanf("%llu",&t);
	while(t--)
	{
	    count=0;
	    scanf("%llu",&n);
	    unsigned long long int a[n+1][n+1],s[n+1];
	    s[0]=0;
	    count=n;
	    for(i=0;i<=n;i++)
	    {
	        for(j=0;j<=n;j++)
	        {
	            if(i==j)
	            a[i][j]=1;
	            else
	            a[i][j]=0;
	        }
	    }
	    for(i=1;i<=n;i++)
	    {
	        scanf("%llu",&s[i]);
	    }
	    for(i=1;i<=n;i++)
	    {
	        for(j=i+1;j<=n;j++)
	        {
	            if(a[i][j-1]==1&&s[j-1]<=s[j])
	            {
	                a[i][j]=1;
	                count++;
	            }
	            else 
	            break;
	        }
	    }
	    printf("%llu\n",count);
	    
	}
	return 0;
}

