#include<stdio.h>
int main()
{
    int t,i,j;
    scanf("%d",&t);
    while(t--)
    {
        int n,c=0,s=0;
        scanf("%d",&n);
        int p[n];
        for(i=0;i<n;i++)
        {
            scanf("%d",&p[i]);
        }
        for(i=0;i<n-1;i++)
        {
            if(p[i]<p[i+1])
            c++;
        }
        s=n+c;
        printf("%d\n",s);
    }
    return 0;
}
