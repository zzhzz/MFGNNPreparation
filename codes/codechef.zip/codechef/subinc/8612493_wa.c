#include<stdio.h>

 int main()
  {
    int  tcase,i,j,num,sum,temp,prev,curr;
     scanf("%d",&tcase);
      for(i=0;i<tcase;i++)
      {
         scanf("%d",&num);
         sum=1;temp=0;
         for(j=0;j<num;j++)
         { 
           if(j==0)
            scanf("%d",&prev);
            else
          {  scanf("%d",&curr);
            if(curr<prev)temp=j;
            sum=sum+(j-temp+1);
              prev=curr;        
          }         
         }  
        printf("%d",sum);    
      }
    return 0; 
  }