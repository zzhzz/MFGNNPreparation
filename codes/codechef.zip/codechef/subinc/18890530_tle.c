#include <stdio.h>
int main(void) {
	// your code goes here
	int t;
	scanf("%d",&t);
	while(t--) {
	    int n;
	    scanf("%d",&n);
	    int arr[n];
	    for(int i=0;i<n;i++)
	        scanf("%d ",&arr[i]);
	    int sum,max=0,count=0;
	   for(int i=0;i<n;i++) {
	       max=0;
	       for(int j=i;j<n;j++) {
	           sum=arr[i]+arr[j];
	       if(sum>max) {
	       max=sum;
	         count++;
	       }
	       }
	       //printf("%d   ",max);
	   }
	   printf("%d\n",count);
	}
	return 0;
}

