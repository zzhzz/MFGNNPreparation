#include<stdio.h>
int main()
{
	int arr[100001],t,n,count,i;
	scanf("%d",&t);
	while(t--)
	{   
	count=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
		for(i=0;i<n-1;i++)
		{
			if(arr[i]<arr[i+1])
			count++;
		}
		printf("%d\n",count+n);
	}
	return 0;
}