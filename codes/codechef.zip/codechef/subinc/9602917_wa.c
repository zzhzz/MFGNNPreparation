#include <stdio.h>

int main()
{
	int t, n, x, sub_arrays, m, z;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d", &n);
		sub_arrays = 1, m = 1;
		scanf("%d", &z);
		while (--n)
		{
			scanf("%d", &x);
			sub_arrays++;
			if (z < x)
				m++, z = x;
			else
				sub_arrays += (m * (m + 1)) / 2, m = 1, z = x;
		}
		sub_arrays += (m * (m + 1)) / 2;
		printf("%d\n", sub_arrays);
	}
	return 0;
}
