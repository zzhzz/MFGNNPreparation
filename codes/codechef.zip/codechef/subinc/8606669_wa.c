#include<stdio.h>
#include<math.h>
int main()
{
	long int t,n,i;
	scanf("%ld",&t);
	if(t<=5)
	{
	for(i=1;i<=t;i++)
	{
		scanf("%ld",&n);
		printf("%ld\n",calc(n));
	}
  }
	return 0;
}

int calc(long int n)
{
	long int a[n],i,c=n;
	for(i=0;i<n;i++)
		scanf("%ld",&a[i]);
	for(i=0;i<n-1;i++)
	{
		if(a[i]<=a[i+1])
			c++;
	}
	return c;
	
}