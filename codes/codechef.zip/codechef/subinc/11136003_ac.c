#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *a,t,n,count,i,j;
	scanf("%d",&t);
	while(t--)
	{  int count=0;
		scanf("%d",&n);
		a=malloc(n*sizeof(int));
		for(i=0;i<n;i++)
		scanf("%d",&a[i]);
		
		for(i=0;i<n;i++)
		{
			for(j=i;j<n;j++)
			    if(a[j+1]>a[j])
			    count++;
			    else
			    break;
	
	count++;
			}
	printf("%d\n",count);
		}
return 0;	
}



