#include <stdio.h>

typedef long long int ll;

int main()
{
    int t;
    scanf("%d", &t);
    while(t--){
        int n;
        scanf("%d", &n);
        int arr[100001];
        int i, j;
        ll ans = n;
        
        for(i=1; i <= n; i++)
            scanf("%d", &arr[i]);
        
        for(i=1; i <= n; i++){
            for(j=i; j < n; j++){
                if(arr[j] <= arr[j+1])
                    ans++;
                
                else break;
            }
        }
        
        printf("%lld\n", ans);
        
    }
    
}