#include<stdio.h>
void main()
{
     int t,i,j,k=0,a,p=0;
     long int n,arr[100000];
       scanf("%d",&t);
     while(t--)
     {
     scanf("%ld",&n);
     a=n;k=0;
     for(i=0;i<n;i++)
     {
         scanf("%ld",&arr[i]);
     }
     for(j=0;j<n-1;j++)
     {
         while(n-1>j)
         {
             for(i=j;i<n-1;i++)
             {
                 if(arr[i]<=arr[i+1])
                  {
                   if(i==(n-2)&&p==0)
                    k++;
                  }
                 else
                   {p++;}

             }
                    n--;p=0;
         }
         n=a;
     }printf("%d",k+n);
   }
}
