#include<stdio.h>
int main()
{
long long t,n,i,c,sum;
scanf("%lld",&t);
while(t--)
	{
	scanf("%lld",&n);
	long long a[n];
	for(i=0;i<n;i++)
	scanf("%lld",&a[i]);
	if(n==1)
	printf("%d\n",1);
	else
	{sum=0;
	for(i=0;i<n-1;i++)
	{
	c=1;
	while(a[i]<=a[i+1]&&i<n-1)
		{
		c++;
		i++;
		}
	sum+=(c*(c+1))/2;
	}
	printf("%lld\n",sum);
	}
	}
return 0;
}
	