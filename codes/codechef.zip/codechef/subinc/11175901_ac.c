#include<stdio.h>
int main()
{ int t;
scanf("%d",&t);
while(t--)
{ int i,n;
long long int sum=0,k=1;
scanf("%d",&n);
int a[n];
for(i=0;i<n;i++)
{scanf("%d",&a[i]);}
for(i=0;i<n-1;i++)
{if(a[i+1]>=a[i])
k++;
  else
  {
      sum+=(k*(k+1))/2;
      k=1;
  }
}
sum+=(k*(k+1))/2;
printf("%lld\n",sum);
}
return 0;}
