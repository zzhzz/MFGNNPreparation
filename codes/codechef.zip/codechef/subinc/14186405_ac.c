#include <stdio.h>

int main(void) {
	int test;
	scanf("%d",&test);
	while(test--)
	{
	    int n;
	    scanf("%d",&n);
	    int i,b[n];
	    long long int a[n];
	    for(i=0;i<n;i++)
	     scanf("%lld",&a[i]);
	    b[0]=1;
	    int sum=1;
	    for(i=1;i<n;i++)
	    {
	        if(a[i-1]<=a[i])
	         b[i]=b[i-1]+1;
	        else
	         b[i]=1;
	        sum=sum+b[i];
	    }
	    printf("%d\n",sum);
	    
	}
	return 0;
}

