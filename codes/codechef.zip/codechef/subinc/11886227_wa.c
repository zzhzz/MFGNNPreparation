#include <stdio.h>

int main(void) {
    int t;
    scanf("%d",&t);
	while(t--)
	{
	    long long int a[100001],b[100001],i,j,n,sum,min,min1;
	    scanf("%lld",&n);
	    for(i=0;i<n;i++)
	    {
	        scanf("%lld",&a[i]);
	    }
	    min=a[n-1];
	    min1=n-1;
	    b[n-1]=1;
	    sum=b[n-1];
	    for(j=n-2;j>=0;j--)
	    {
	        if(a[j]<=min)
	        {
	            b[j]=1+b[min1];
	            min=a[j];
	            min1=j;
	        }
	        sum=sum+b[j];
	    }
	    printf("%lld\n",sum);
	  
	}
	return 0;
}

