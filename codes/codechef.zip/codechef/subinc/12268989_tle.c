#include<stdio.h>
int a[100005];
int b[100005];
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        int i,j;
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
        b[n-1]=1;
        for(i=n-2;i>=0;i--)
        {
            int max=-1;
            for(j=i+1;j<n;j++)
            {
                if((a[i]<a[j])&&(max<b[j]))
                max=b[j];

            }
            b[i]=max+1;
        }
        long long int sum=0;
        for(i=0;i<n;i++)
        {
            sum+=b[i];
        }
        printf("%lld\n",sum);

    }
    return 0;
}
