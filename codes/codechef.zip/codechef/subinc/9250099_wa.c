#include<stdio.h>
#include<stdlib.h>
int main ()
{
	int test, n, *a, k, i, j, count = 0;
	scanf("%d", &test);
	while(test--)
	{
		scanf("%d", &n);
		a = (int *)malloc(n * sizeof(int));
		for(i = 0; i < n; i++)
		{
			scanf("%d", &a[i]);
		}
		count = 0;
		for(i = 0; i < n; i++)
		{
			for(j = i; j < n - 1; j++)
			{
				if(a[j] > a[j + 1])
				{
					break;
				}
			}
			
			if(j > i)
			{
				count++;
			}
		}
		printf("%d\n",count + n);
	}
	return 0;
}