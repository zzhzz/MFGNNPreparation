#include <stdio.h>
int n;
void subset(int arr[n+1],int n)
{int l=0;
int m=0;
    int i=0;
  int j=1;
  int k=0;
  int count=1;
  int ans[100001];
  
  while(i<n)
  {
  if(arr[j]>arr[i])
  {
      count++;
      i++;
      j++;
  }
 else{
     ans[k]=count;
  count=1;
  k++;
  i=j;
  j=j+1;}
  
  }
  for(i=0;i<k;i++)
  {
      l=ans[i];
      l=(l*(l+1))/2;
      m=m+l;
 }
 printf("%d\n",m);
}

int main() {
    int t,i,j;
    int n;
scanf("%d",&t); //no. of test cases
for(j=0;j<t;j++)
{
scanf("%d",&n); //size of array
int arr[n+1];
for(i=0;i<n+1;i++)
{
  arr[i]=0;  
}
for(i=0;i<n;i++)
{
  scanf("%d",&arr[i]);  
}
subset(arr,n);
}


}

