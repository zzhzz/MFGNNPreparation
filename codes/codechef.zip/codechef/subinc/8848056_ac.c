#include<stdio.h>

int main()
{
    int t;

    scanf("%d", &t);

    while(t > 0)
    {
        unsigned long int n, i, ans=0;
        unsigned long long int count=1;
        scanf("%lu", &n);

        unsigned long int A[n];

        for(i=0; i<n; i++)
        {
            scanf("%lu", &A[i]);

            if(A[i] >= A[i-1] && i != 0)
                count++;


            else
            {
                while(count != 0)
                    ans += --count;

                count=1;
            }
        }
        while(count != 0)
            ans += --count;

        ans += n;

        printf("%llu\n", ans);

        t--;
    }
    return 0;
}




