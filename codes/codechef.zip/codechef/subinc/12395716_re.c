#include<stdio.h>
int main()
{
long long int a[99999];
    int tc;
    long long int i,n,num[99999];
    long long int sum=0;
    scanf("%d",&tc);
    while(tc--)
    {
        sum=0;
        scanf("%lld",&n);for(i=0;i<n;i++)
                        a[i]=1;
        for(i=0;i<n;i++)
        {
            scanf("%lld",&num[i]);
        }
        for(i=n-2;i>=0;i--)
        {
            if(num[i]<=num[i+1])
                a[i]+=a[i+1];
        }

        for(i=0;i<n;i++)
            sum+=a[i];
        printf("%lld\n",sum);
    }
    return 0;
}
