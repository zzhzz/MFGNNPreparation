#include<stdio.h>

int main()
 {
  int t,a[100001];
 
   scanf("%d",&t);
 
  while(t--)
   {
    long long int count=0;
    int i,j,n;
 
    scanf("%d",&n);

     for(i=0;i<n;i++) scanf("%d",&a[i]);

    if(n==1) count=1;    

    for(i=1;i<n;i++)
       {
         
         for(j=1;(i<n) && (a[i]>=a[i-1]) ;i++,j++);
  
         count=count+j*(j+1)/2;
      } 
     
    printf("%lld\n",count);
 }
  return 0;
 }
