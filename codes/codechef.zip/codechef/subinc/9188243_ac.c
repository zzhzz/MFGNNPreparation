#include<stdio.h>
int main()
{
	int i,t,n,j,k,c;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%d",&n);
		c=n;
		int a[n];
		for(j=0;j<n;j++)
		scanf("%d",&a[j]);
		for(j=0;j<n;j++)
		{
		for(k=j+1;k<n;k++)
		{
		if(a[k]>a[k-1])
		{c++;continue;}
		else
		break;
		}
		}
		printf("%d\n",c);
	}
}