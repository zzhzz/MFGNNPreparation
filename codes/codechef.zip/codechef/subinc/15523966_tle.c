#include <stdio.h>
 
int main(void) {
int t;
scanf("%d",&t);
while(t--){
    int n;
    scanf("%d",&n);
    int ar[n];
    for(int i = 0;i < n;i++) {
        scanf("%d",&ar[i]);
    }
    int cnt = 0;
    for(int i = 0;i < n;i++) {
        for(int j = i+1;j < n;j++) {
            cnt++;
        }
    }
    if(n == 1) {
        cnt = 1;
    }
    printf("%d\n",cnt);
}
return 0;
}

