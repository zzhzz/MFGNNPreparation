#include<stdio.h>
int main()
{
	int t,n,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		long int a[n],c=0;
		for(i=0;i<n;i++)
		{
			scanf("%ld",&a[i]);
			c++;
		}
		for(i=0;i<n;i++)
		{
			if(a[i]<a[i+1])
			c++;
		}
		printf("%ld\n",c);
   	}
   	return 0;
}