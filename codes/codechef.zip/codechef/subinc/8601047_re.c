#include <stdio.h>
int calc(int,int []);
int main(void) {
	// your code goes here
	int T,k,l,c,N,q,i=0,p,a[10] ;
		scanf("%d\n",&T);
		while(i<T)
		{
		scanf("%d\n",&N);
		for(p=0;p<N;p++)
		{
		scanf(" %d",&a[p]);
		}
		    printf("\n");
		
		if(N==1)
		printf("%d",N);
		  else
		  {
		c=N;
		
	
		for(k=0;k<N;k++)
		{
		    for(l=k+1;l<N;l++)
		    {
		        if(a[k]<=a[l])
		        c++;
		        else 
		        break;
		        }
		}	    
	}
	printf("%d",c);
	i++;	    
		}
	
			return 0;
}

	
	
	
