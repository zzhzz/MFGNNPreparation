#include<stdio.h>
int main()
{
long long int a[100000],t,n,i,count=0,ic=0;
scanf("%lld",&t);
while(t--)
{
count=0;ic=0;
scanf("%lld",&n);
for(i=0;i<n;i++)
{
    scanf("%lld",&a[i]);
    if(i>0)
        {
            if(a[i]>=a[i-1])
                {ic++;}
            else{
                if(ic){
                        ic=ic+1;
                count=count+((ic*(ic+1))/2)-ic;
                ic=0;
                }
                }

        }

}
if(ic){ic=ic+1;
count=count+((ic*(ic+1))/2)-ic;}
count=count+n;
printf("%lld\n",count);
}
return 0;
}
