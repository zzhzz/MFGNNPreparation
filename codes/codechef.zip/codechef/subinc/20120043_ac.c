#include<stdio.h>
main()
{
    int t,i,sum;
    scanf("%d",&t);
    while(t>0)
    {
        int n;
        scanf("%d",&n);
        int a[n],d[n];
        for(i=1;i<=n;i++)
        {
            scanf("%d",&a[i]);
        }
        d[1]=1;
        for(i=2;i<=n;i++)
        {
            if(a[i-1]<=a[i])
            {
                d[i]=d[i-1]+1;
            }
            else
            {
                d[i]=1;
            }
        }
        sum=0;
        for(i=1;i<=n;i++)
        {
            sum=sum+d[i];
        }
        printf("%d\n",sum);
        t--;
    }
}
