#include<stdio.h>
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        long int N,i,sum=0;
        scanf("%ld",&N);
        long int A[N],record[N];
        for(i=0;i<N;i++)
        {
            scanf("%d",&A[i]);
            record[i]=1;
            if(i==0)
                continue;
            if(A[i]>=A[i-1])
                record[i]+=1;
        }
        for(i=0;i<N;i++)
            sum+=record[i];
        printf("%ld\n",sum);
    }
    return 0;
}
