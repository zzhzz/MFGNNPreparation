#include<stdio.h>
int main()
{
    long long int t,i;
    scanf("%lld",&t);
    while(t--)
    {
       long long int n,c=0;
       scanf("%lld",&n);
       long long int a[n];
       for(i=0;i<n;i++)
        scanf("%lld",&a[i]);

       for(i=0;i<n;i++)
       {
           c++;
           if(a[i]<=a[i+1]&&i!=(n-1))
            c++;
           i++;
       }
       printf("%lld\n",c);
    }
    return 0;
}
