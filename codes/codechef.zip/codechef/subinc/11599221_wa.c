#include<stdio.h>
#include<stdlib.h>
int main()
{
int t;
scanf("%d",&t);
while(t--)
{
int n;
scanf("%d",&n);
int a[n];
int count=0,i;
for( i=0;i<n;i++)
scanf("%d",&a[i]);


for( i=0;i<n;i++)
{
if((i+1)==n)
   break;
if(a[i]<=a[i+1])
{
while(a[i]<=a[i+1]&&(i+1)==n)
i++;
count+=1;



}

}
printf("%d\n",(count+n));
      }




}
