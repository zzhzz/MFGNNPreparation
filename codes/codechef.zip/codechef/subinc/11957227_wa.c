#include <stdio.h>

int main(void)
{
    int t;
    scanf("%d",&t);
    
    while(t>0)
    {
        int n,i,j;
        int count=0;
        scanf("%d",&n);
        int a[n];
        for(i=1;i<=n;i++)
        {
            scanf("%d",&a[i]);
        }        
        for(i=1;i<=n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(a[j]>a[i])
                count++;
                
                else
                break;
                
            }
        }count=count+n;
        printf("%d\n",count);
        t--;
    }
   return 0; 
}
