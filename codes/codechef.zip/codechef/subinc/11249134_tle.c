#include<stdio.h>
int main()
{
 int t;
 scanf("%d",&t);
 while(t--)
  {
    long n,i,j;
    scanf("%d",&n);
    long long int a[n];
    for(i=0;i<n;i++)
    {
       scanf("%lld",&a[i]);
     }
     long int c=n,r;
    for(i=0;i<n;i++)
    {
        r=1;
       for(j=(i+1);j<n;j++)
         {
           if(a[i]<=a[j])
             {
                r++;
              }
              else
                c+=(r*(r+1))/2;
              r=1;
          }
    }
    printf("%ld",c);
  }
  return 0;
}
