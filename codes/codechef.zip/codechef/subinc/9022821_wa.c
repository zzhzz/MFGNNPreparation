#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
	int n,i,a[100000],j,c=0,flag,pn=1e9+5;

	scanf("%d",&n);
	
	i=-1;
	while(++i<n)
	{
		scanf("%d",&a[i]);
		flag=0;
		if(a[i]>=pn)
			{
				flag=1;
				
			}
		else flag=0;			
	
			c+=flag;
			pn=a[i];
	
	}
	
	printf("%d\n",c+n);
	}
	return 0;	
}