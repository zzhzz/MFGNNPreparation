#include <stdio.h>

int main(void) {
     int t,n,i,k;
     long int arr[100000];
       scanf("%d",&t);
     while(t--)
     {
     scanf("%d",&n);
      k=0;
     for(i=0;i<n;i++)
     {
         scanf("%ld",&arr[i]);
     }
      for(i=0;i<n-1;i++)
      {
          if(arr[i]<=arr[i+1])
          {
              if(i==(n-2))
              {
                k++;
              continue;
              }
          }
          else
            k++;
      }printf("%d",k+n);
     }
	return 0;
}
