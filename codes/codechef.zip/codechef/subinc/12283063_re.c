#include <stdio.h>

int main(void) {
	// your code goes here
	int t,n,a[10000],i,count,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		count=n;
		for(i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(i=1;i<n;i++)
		{
			for(j=i+1;j<=n;j++)
			{
				if(a[j]>=a[j-1])                   
 			    count = count + 1;
 			    else 
 			     break;
 			}
		}
	 printf("%d\n",count); 
	}
	return 0;
}
