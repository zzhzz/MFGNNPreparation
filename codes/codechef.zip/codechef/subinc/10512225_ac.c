#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h> 

#define max(a, b) a > b? a : b
#define min(a, b) a < b? a : b

int main()
{
	int t, n, k, i;
	long long int count;

	scanf("%d", &t);
	
	while(t--)
	{
		scanf("%d", &n);
		int arr[n];

		for(i = 0; i < n; i++)
			scanf("%d", &arr[i]);

		i = 1, k = 1, count = 0;

		while(i < n)
		{
			if(arr[i-1] <= arr[i])
				k++;
			else
			{
				count += k*(k+1)/2;
				k = 1;
			}

			i++;
		}
		count += k*(k+1)/2;

		printf("%lld\n", count);
	}


	return 0;
}
