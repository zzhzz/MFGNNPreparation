#include<stdio.h>
int main(){
int t;
scanf("%d",&t);
while(t--){
int n;
scanf("%d",&n);
long long int A[n];
int i,j,count=0;
for(i=0;i<n;i++){
    scanf("%lld",&A[i]);
}
for(i=0;i<n;i++){
    for(j=i;j<n-1;j++){
        if(A[j]<=A[j+1]){
            count++;
        }else{
        break;
        }

}
}
printf("%d\n",count+n);
}
return 0;
}
