#include<stdio.h>
int main()
{
	int l,n,m,k,count,temp=0,i,j;
	scanf("%d", &m);
	for(k=1;k<=m;k++)
	{
		scanf("%d ", &n);
		int a[n];
		for(l=0;l<n;l++)
			scanf("%d", &a[l]);
		count=n;
		for(i=0;i<=n-2;i++)
		{
			temp=0;
			for(j=i;j<=n-1;j++)
			{
				if(a[j]<=a[j+1])
				{
					temp=1;
					continue;
				}
				else
					break;
			}
			
			if(temp==1)
				count++;
		}
		printf("%d", count);
	}
	return 0;
}