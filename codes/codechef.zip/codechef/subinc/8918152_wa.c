#include <stdio.h>

int main(void)
{
    int t,s,i,n;
    scanf("%d",&t);
    while(t--)
    {
        s=0;
        scanf("%d",&n);
        int a[n];int b[n];
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
        for(i=0;i<n;i++)
        {
        b[i]=0;
        }
        b[0]=1;
        for(i=1;i<n;i++)
        {
            if(a[i]<a[i-1])
            {
            b[0]=i;
            break;
            }
        }
        for(i=1;i<n;i++)
        {
            if(a[i]<=a[i-1])
            b[i]=b[i-1]+1;
            else
            b[i]=1;
        }
        for(i=0;i<n;i++)
        s+=b[i];
       
        
        printf("%d\n",s);
    }
	
	return 0;
}
