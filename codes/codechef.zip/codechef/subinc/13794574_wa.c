#include<stdio.h>
int main()
{
	int t,n,x,count,i,j,k,l;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&n);
		int a[n];
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[j]);
		}
		x=0;
		for(k=0;k<n-1;k++)
		{
			count=0;
			for(l=0;l<n-1-k;l++)
			{
				if(a[l+k]<=a[l+k+1])
				{
					count++;
				}
				else
				break;
			}
			x+=count;
		}
		printf("%d",x+n);
	}
	return 0;
}
