#include<stdio.h>
#include<stdlib.h>

int main()
{
    int t,i;
    long int n,j;

    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%ld",&n);
        long long int ans = n;
        int test =1;
        long long int a[n];
        for(j=0;j<n;j++)
        {
            scanf("%ld",&a[j]);
        }
        for(j=0;j<n-1;j++)
        {
            
            if(a[j]<=a[j+1])
            {
            
                ans = ans + test;
                test++;
            }
            else{
            
                test = 1;
            }
           
        }
        
        printf("%lld\n",ans);
    }
}
