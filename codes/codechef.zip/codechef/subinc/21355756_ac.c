#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    for(int it=0;it<t;it++)
    {
        int n,arr[100000];
        scanf("%d",&n);
        for(int i=0;i<n;i++)
            scanf("%d",&arr[i]);
        int l=0,f=0;
        long long sum=0;
        while(f<n)
        {
            if(f!=n-1 && arr[f+1]>=arr[f])
                f++;
            else
            {
                int n1=f-l+1;
                sum+=(n1*(n1+1))/2;
                f++;
                l=f;
            }
        }
        printf("%lld\n",sum);
    }
    return 0;
}


