#include <stdio.h>
#define get getchar_unlocked
int scan()
{
    char ch=get();
    int n=0;
    while(ch<'0'||ch>'9')
    ch=get();
    while(ch<='9'&&ch>='0')
    {
        n=(n<<3)+(n<<1)+ch-'0';
        ch=get();
    }
    return n;
}
int main() 
{

int T,N,i;
T=scan();
while(T--)
    {
        N=scan();
       int array[N],count=1,res=0;
            for(i=0;i<N;i++)
            array[i]=scan();
            if(N==1)
            printf("%d\n",count);
            else
        {
        for(i=1;i<N;i++)
            {
                if(array[i]>array[i-1])
                    count++;
                        else
                        {
                            res+=count*(count+1)/2;
                       //     printf("%d.\n",res);
                        count=1;
                            
                        }
            }
                            res+=count*(count+1)/2;
            
                printf("%d\n",res);
    }}
	return 0;
}
