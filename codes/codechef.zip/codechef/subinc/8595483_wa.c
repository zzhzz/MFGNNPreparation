#include<stdio.h>
int main()
{
	int a[10],i,k,j,count=0,subcount=0,n;
	printf("Enter the size of the array \n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n-1;i++)
	{
		j=i+1;k=i;
		while(a[j]>=a[i])
		{
			count++;
			j++;
			i++;
		}
		subcount=subcount+(count/count);
		i=k;
	}
	subcount=subcount+n;
	printf("%d is the number of subarrays\n",subcount);
	return 0;
}