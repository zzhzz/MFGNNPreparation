#include <stdlib.h>
#include <stdio.h>

int main()
{
    int t,n,i,j;

    scanf("%d",&t);
    int res[t];
    for(i=0; i<t; i++)
    {
        
        int sum=0, count=0, low=0, x;
        scanf("%d",&n);
        int arr[n];
        x=n;
        for(j=0; j<n; j++)
        {
            scanf("%d",&arr[j]);
        }

        for(j=0; j<n; j++)
        {
            if(arr[j]<arr[j-1])
            {
                //printf("i(%d) arr[j](%d) arr[j-1](%d)\n", res[i], arr[j], arr[j-1]);
                count=(j)-low;
                //printf("count %d \n", count);
                if(count>1)
                {
                    sum=(count*(count-1))/2;
                    x+=sum;
                    //printf("count %d sum %d x %d\n", count, sum, x);
                }
                low=j;
            }
            else if(j == n-1)
            {
                count=(j+1)-low;
                if(count>1)
                {
                    sum=(count*(count-1))/2;
                    x+=sum;
                    //printf("count %d sum %d x %d\n", count, sum, x);
                }
                
            }
        }
        res[i]=x;
        
    }
    for(i=0; i<t; i++)
    {
        printf("%d\n", res[i]);
    }

    return 0;
}

