#include<stdio.h>
int main()
{
 int T;
 scanf("%d", &T);
 for(int i=0; i<T; i++)
 {
  long long int N, count=0, ans=0;
  scanf("%d", &N);
  int A[N];
  scanf("%d", &A[0]);
  for(int j=1; j<N; j++)
  {
   scanf("%d", &A[j]);
   if(A[j]>=A[j-1])
    count++;
   else
   {
    ans+=(count*(count+1))/2;
    count=0;
   }
  }
  ans+=(count*(count+1))/2;
  printf("%d\n", ans+N);
 }
} 
