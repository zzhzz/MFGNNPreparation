#include<stdio.h>
int check(long int *arr,int i,int j)
{
    int k;
    for(k=i;k<j;k++)
    {
        if(arr[k]>arr[k+1]) return 0;
    }
    return 1;
}
int main()
{
    int t,k;
    scanf("%d",&t);
    for(k=0;k<t;k++)
    {
        int n,i,j;
    scanf("%d",&n);
    long int arr[n],count=0;
    for(i=0;i<n;i++)
      scanf("%ld",&arr[i]);
    for(i=0;i<n;i++)
    {
        for(j=i;j<n;j++)
        {
            if(check(arr,i,j))
            count++;
        }
    }
    printf("%ld\n",count);
    }
    return 0;
}
