#include<stdio.h>


main()
{
 long int t,a,i,j;
   scanf("%d",&t);
   while(t--)
   {int count=0;
     scanf("%d",&a);
     long int A[a];
     for(i=0;i<a;i++)
        scanf("%ld",&A[i]);
     for(i=0;i<a;i++)
     {
        long int bigger=A[i];
         for(j=i;j<a;j++)
         {
             if(A[j]>=bigger)
             {count++;
             bigger=A[j];}
             else break;
         }
     }
     printf("%d\n",count);
   }
}
