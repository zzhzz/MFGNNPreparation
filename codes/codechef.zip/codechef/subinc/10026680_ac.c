#include <stdio.h>

int main() {
	long long int t,n,i,a[100000],count[100000],total;
	scanf("%lld",&t);
	while(t--){
	    scanf("%lld",&n);
	    for(i=0;i<n;i++){ scanf("%lld",&a[i]);count[i]=1; }
	    for(i=1;i<n;i++){ 
	        (a[i]>=a[i-1])?(count[i]=count[i-1]+1):(count[i]=1);
	    }total=0;
	    for(i=0;i<n;i++){ total=total+count[i]; }
	    printf("%lld\n",total);
	}
	return 0;
}