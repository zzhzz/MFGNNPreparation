#include <stdio.h>
int main(){
	long long t, n,count=0;
	scanf("%lld",&t);
	int i,j;
	for(i = 0;i<t;i++){
		scanf("%lld",&n);
		count =0;
		int pnum, cnum;
		int inter = 1;
		scanf("%lld",&pnum);
		for(j = 1; j<n;j++){
			scanf("%lld",&cnum);
			if(cnum>=pnum){
				inter++;
			}else{
				count += (inter * (inter+1))/2 ;
				inter = 1;
			}
			pnum=cnum;
		}
        count += (inter * (inter+1))/2 ;
		printf("%lld",count);
	}
	return 0;
}