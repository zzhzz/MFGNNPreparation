#include<stdio.h>
int main()
{
	int l,t,i,j,count,prev,cur,n;
	scanf("%d",&t);
	for(l=0;l<t;l++)
	{
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++)
		scanf("%d",&a[i]);
		count=0;
		for(i=0;i<n;i++)
		{
			for(j=i;j>=0;j--)
			{
				if(j==i)
				count++;
				else if(j!=0){
				
					prev=a[j-1];
					cur=a[j];
					if(prev>cur)
					break;
				}
				else
				count++;
			}
		}
		printf("%d\n",count);
	}
	return 0;
}