#include<stdio.h>
int main()
{
    long long int n,a[100000];
    int i=0,j,k=0,t;
    scanf("%d",&t);
    while(t)
    {
        scanf("%lld",&n);
        for(i=0;i<n;i++)
        scanf("%lld",&a[i]);
        k=0;
        for(i=0;i<n-1;i++)
        {
            for(j=i;j<n-1;j++)
            {
                if(a[j]>a[j+1])
                   break;
                else 
                    k++;
            }
        }
        printf("%lld\n",k+n);
        t--;
    }
}