#include<stdio.h>
int main(void)
{
     int tc,num,i,j,pre,current;
     long long int ans;
     scanf("%d",&tc);
     for(i=0;i<tc;i++)
     {
         scanf("%d", &num);
         ans = 1;
         for(j=0;j<num;j++)
         {
             if(j==0)
             scanf("%d",&pre);
             else
             {
                 scanf("%d",&current);
                 ans++;
                 if(current>pre)
                     ans++;
                 pre = current;
             }
            
         }
         printf("\n%lld",ans);
     }
}