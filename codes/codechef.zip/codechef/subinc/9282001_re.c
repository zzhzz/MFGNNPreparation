#include<stdio.h>
int main(){
	int t,n;
	long int a[1000];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);int i=0;
	
		
		
		while(i<n){
			scanf("%ld",&a[i]);
			i++;
		}
		int k=0;
		for(i=0;i<n;i++){
			if(a[i]>a[i+1])
			k++;
		}
		
			if(n==1)
		printf("\n1");
		else
		printf("\n%d",(k+n+1));
	}
}