#include <stdio.h>
int main(void)
{	long long int a, b;
	long int x=0, i, n, t;
int y, j;
scanf("%i", &y);
for(j=0; j<y; j++)
{
	scanf("%li", &n);
	a=0;
	b=0;
	t=0;
	for(i=0; i<n; i++)
	{	scanf("%lli", &a);
		if(a>=b)
		{	t++;
		}
		else
		{	x+=((t*(t+1))/2);
			t=1;
		}
		b=a;
	}
	x+=((t*(t+1))/2);
	printf("%lli\n", x);
}
	return 0;
}
