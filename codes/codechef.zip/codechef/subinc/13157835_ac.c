#include <stdio.h>
int main(void) {
	// your code goes here
	int size,i,T,j,temp;
	long long int cnt,a[100000];
	scanf("%d",&T);
	while(T-->0)
	{
    scanf("%d",&size);
    cnt=size;
    temp=0;
    for(i=0;i<size;i++)
    {
        scanf("%lld",&a[i]);
        if(a[i]>=a[i-1]&&(i-1)>=0)
        {
            temp++;
            cnt=cnt+temp;
        }
        else 
        temp=0;
    }
    printf("%lld\n",cnt);
	}
    return 0;
}
