#include<stdio.h>
void second()
{
	long int size,i,j,p,count=0;
	scanf("%ld",&size);long long int prime[size];
	for(i=0;i<size;i++)
	{
		scanf("%lld",&prime[i]);
	}
	for(i=0;i<size;i++)
	{
		p=i;count++;
		for(j=i+1;j<size;j++)
		{
			if(prime[j]>prime[p]){count++;p=j;}
			else{break;}	
		}	
	}
	printf("%ld",count);	
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		second();
		printf("\n");
	}
}
