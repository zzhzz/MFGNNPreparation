#include <stdio.h>
int main(void)
{
int n,t,i,a[1000000],l=0;
scanf("%d",&t);
while(t--)
{
scanf("%d",&n);
for(i=0;i<n;i++);
{
scanf("%d",&a[i]);
}
for(i=0;i<n-1;i++)
{
if(a[i]<=a[i+1])
l++;
}
--l;
}
printf("%d",l+n);
	return 0;
}

