#include <stdio.h>

int main(void) {
	int t,a[100000000],i;
	long long int sum,n;
	scanf("%d",&t);
	while(t--)
	{
	     scanf("%llu",&n);
	     for(i=0;i<n;i++)
	     {
	          scanf("%d",&a[i]);
	     }
	    int b[n];
	    sum=1;
	    b[0]=1;
	  for(i=1;i<n;i++)
	  {
	
	    if(a[i-1]<a[i])
	            {
	              b[i]=b[i-1]+1;
	            }
	     else
	     b[i]=1;
	     
	     sum+=b[i];
	  }
	 printf("%llu\n",sum);    
	}
	return 0;
}

