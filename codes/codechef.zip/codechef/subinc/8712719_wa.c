#include<stdio.h>
void main()
{
	int a[100];
	int N,k,i;
	scanf("%d",&N);
	for(i=0;i<N;i++)
	{
		scanf("%d",&a[i]);
	}
	k=N;
	for(i=0;i<(N-1);i++)
	{
		if(a[i]<=a[i+1])
		k++;
	}
	printf("%d",k);
}