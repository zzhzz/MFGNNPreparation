#include<stdio.h>
int Calculate(long long int *,long long int);
int main()
{
    long long int a[100005];
    long long int i,t,n,j,count;
    scanf("%lld",&t);
    for(i=0;i<t;i++)
    {
        scanf("%lld",&n);
        for(j=0;j<n;j++)
            scanf("%lld",&a[j]);
        count=Calculate(a,n);
        printf("%lld\n",count);
    }
    return 0;
}
int Calculate(long long int *a,long long int n)
{
    int i,count=0,sum=0,temp=0,j,b[100005];
    b[temp]=-1;
    for(i=0;i<n;i++)
    {
       if(a[i]>a[i+1])
       {
           temp++;
           b[temp]=i;
       }
    }
    temp=temp+1;
    b[temp]=i-1;
    for(i=1;i<=temp;i++)
        {
            sum=b[i]-b[i-1];
            count+=(sum*(sum+1))/2;
        }
    return count;
}




