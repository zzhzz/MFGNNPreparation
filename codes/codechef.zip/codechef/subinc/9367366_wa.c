#include<stdio.h>

int main()
{
	 int i,j,t,k=0;
	long int N,count=0,n=0;
	
	scanf("%d",&t);
	while(t>0)
	{
	
	n=0;
	k=0;
	scanf("%ld",&N);
	
	long int A[N];
	
	for(i=0;i<N;i++)
	{
		scanf("%ld",&A[i]);
	
		
	}
	
	for(i=0;i<N;i++)
	{	
		
	if(A[i]>A[i+1])
	{
		 count=i-k;
		n+=count*(count+1)/2;
		k=i+1;
	}
	
	}
	

	t--;

	printf("%ld\n",n+N);
}
	return 0;
	
}