#include <stdio.h>
int main()
{
    int t,N,i,j,a,coun;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&N);a=0;
        long long int A[N];
        for(i=0;i<N;i++)
        {
            scanf("%lld",A[i]);coun=1;
            for(j=i-1;j>=0;j--)            {
             if(A[j]<=A[i])
             {
                 coun++;
             }
             else break;
            }
        a=a+coun;
        }printf("%d\n",a);
    }
return 0;
    
}
