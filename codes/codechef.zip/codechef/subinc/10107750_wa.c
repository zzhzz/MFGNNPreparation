#include<stdio.h>

int main()
{
    int t;
    
    scanf("%d",&t);
    while (t!=0)
    {
        call();
        t--;
        
    }
    return 0;
}

call()
{
    
    long long int a[100005],c=0,t,n,i;
   scanf("%lld",&n);
   for(i=1;i<n+1;i++) scanf("%lld",&a[i]);
   for(i=1;i<n;i++)
   {
       if(a[i]<=a[i+1]) c++;
   }
   
   printf("%lld\n",c+n);
    
}
    
