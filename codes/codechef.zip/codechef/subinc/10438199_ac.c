#include<stdio.h>
int a[100005];
int main()
{
    int t,n,i;
    long long int len,sum;
    scanf("%d",&t);
    while(t--)
    {sum=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
        len=1;
        for(i=1;i<n;i++)
        {
            if(a[i]>=a[i-1])
            {
                len++;
            }
            else
            {
                sum+=(len*(len+1))/2;
                len=1;
            }
        }
        sum+=(len*(len+1))/2;
        printf("%lld\n",sum);
    }
}
