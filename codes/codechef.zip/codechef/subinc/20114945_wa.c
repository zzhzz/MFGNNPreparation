#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
	long long	int n,i,count=0;

		scanf("%lld",&n);
	long long	int a[n],b[n];
		for(i=0;i<n;i++)
		scanf("%lld",&a[i]);
		for(i=0;i<n;i++){
            b[i]=1;}
for(i=1;i<n;i++)
{
    if(a[i-1]<=a[i])
        b[i]=b[i-1]+b[i];
}
for(i=0;i<n;i++)
{
    count=count+b[i];
}

	printf("%lld",count);

	}return 0;
}
