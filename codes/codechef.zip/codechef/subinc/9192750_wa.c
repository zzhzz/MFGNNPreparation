#include<stdio.h>
int main()
{
   int i,t,a,sum;
   scanf("%ld",&t);
   while(t--)    
      {
          scanf("%d",&a);
          int arr[a];
          int sub[a];
          for(i=0;i<a;i++)
          scanf("%d",&arr[i]);
          for(i=0;i<a;i++)
          sub[i]=1;
          for(i=1;i<a;i++)
            {
              if(arr[i]>=arr[i-1])
              sub[i]=sub[i-1]+1;
            }
          sum=0;  
          for(i=0;i<a;i++)
          sum += sub[i];
          printf("%d",sum);                   
      }
   return 0; 
}
