#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        long long int n,i,len=1,count=0;
        scanf("%lld",&n);
        long long int a[n];
        for(i=0;i<n;i++)
            scanf("%lld ",&a[i]);
        for(i=0;i<n-1;i++){
            if(a[i+1]>a[i]){
                len++;
            }
            else{
                count += (len*(len-1))/2;
                len=1;
            }
        }
        if(len>1){
            count += (len*(len-1))/2;
        }
        printf("%lld\n",count);
    }
    return 0;
}