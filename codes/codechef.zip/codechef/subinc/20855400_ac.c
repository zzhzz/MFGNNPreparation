#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,i,j;
        scanf("%d",&n);
        long long int a[n];
        for(i=0;i<n;i++)
            scanf("%lld",&a[i]);
        long long int count=0,x=1;
        for(i=1;i<n;i++)
        {
            if(a[i]>=a[i-1])
                x++;
            else
            {
                count+=x*(x+1)/2;
                x=1;
            }
        }
        count+=x*(x+1)/2;
        printf("%lld\n",count);
    }
}
