#include<stdio.h>
int subarray(int A[],int p)
{
    int i=0,j,count,sum=0,size=p;
    while(i<p)
    {
        j=i;
        count=0;
        while(j<size-1)
        {
            if(A[j]<=A[j+1])
            {
                j++;
                i++;
                count=1;
            }
            else
                break;
        }
        sum=sum+count;
        i++;
    }
    return sum+p;
}
int main()
	{
	int n,i,p,j;
	scanf("%d",&n);
	printf("\n");
	int b[n];
	for(i=0;i<n;i++)
		{
		scanf("%d",&p);
		int a[p];
		for(j=0;j<p;j++)
			{
			scanf("%d",&a[j]);
			}
		b[i]=subarray(a,p);
		printf("\n");
		}
	for(i=0;i<n;i++)
		{
		printf("%d\n",b[i]);
		}
	}
