int main()
{   int noele[5],count[1000],ele[1000][1000];
	int T,N,A[1000];
	int a,b;
	
	scanf("%d",&T);
	
	
	for(a=0;a<T;a++)
	{
		scanf("%d",&N);
		noele[a]=N;
		   for(b=0;b<N;b++)
		   {
		   	scanf("%d",&A[b]);
		   	ele[a][b]=A[b];
		   			   	
		   }
		
		
	}
	
	
	
	for(a=0;a<T;a++)
	{count[a]=0;
		for(b=0;b<noele[a];b++)
		{
			while(ele[a][b]<ele[a][b+1])
			  {
			  	count[a]++;
			  	b++;
			  }
			
		}
		printf("\n%d",count[a]);
	}
	
	return 0;
}
