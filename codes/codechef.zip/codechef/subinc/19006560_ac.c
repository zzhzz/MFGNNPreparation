#include<stdio.h>
int main()
{int t,n,i,j,k,d;
scanf("%d",&t);
for(i=0;i<t;i++)
{scanf("%d",&n);
int a[n],c=0;
for(j=0;j<n;j++)
{scanf("%d",&a[j]);
}
for(j=0;j<n-1;j++)
{d=0;
    for(k=j;k<n;k++)
{
    if(a[k+1]>=a[k])
   {d++;
   continue;
    }
    else
    {
    c+=d;
    break;
    }
}
}
c=c+n;
printf("%d\n",c);
}
} 