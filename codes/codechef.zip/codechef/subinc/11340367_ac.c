#include <stdio.h>

int main(){
    
    int T,n,i;
    unsigned long long a[100001],ans;
    long res[100001];
    scanf("%d",&T);
    while(T--){
        
        scanf("%d",&n);
        for(i=0; i<n; i++)
          scanf("%llu",&a[i]);
        for(i=0; i<n; i++)
          res[i] = 1;
        for(i=1; i<n; i++){
            if(a[i-1] <= a[i])
                res[i] = res[i-1]+1;
             else
                res[i] = 1;
        }
        ans = 0;
        for(i=0; i<n; i++)
          ans += res[i];
        printf("%llu\n",ans);
        
    }
    return 0;
}