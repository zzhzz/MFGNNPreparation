#include<stdio.h>
void main()
{
	int loop,i,j,n;
	long int a[100];
    long long int b[10000], count=0;
	scanf("%d",&loop);
	while(loop--)
	{
	scanf("%d",&n);
	i=0;
	while(i<n)
	{
		scanf("%lu",&a[i]);
		i++;
	}	
		j=0;
		while(j<n)
		{
			i=j-1;
			if(j=0)
			b[j]=1;
			else
			{
				if(a[i]<=a[j])
				b[j]=b[i]+1;
				else
				b[j]=1;
			}
			count+=b[j];
		}
		printf("The sub array is: %llu",count);
	}
	
}