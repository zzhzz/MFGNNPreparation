#include<stdio.h>
long long int count1(long int n)
{
	return ((n+1)*n)/2;
}
int main()
{
	int n,i,t;
	scanf("%d",&t);
	while(t--)
	{
		
	scanf("%d",&n);
	unsigned long int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%lu",&a[i]);
	}
	long long int ans;
	ans=1;
	long int count=0;
	for(i=1;i<n;i++)
	{
		
		if(a[i]>a[i-1])
		{
			count++;
		}
		else
		{
			ans=ans+count1(count);
			count=1;
		}
	}
	printf("%lld\n",ans);
	}
	return 0;
}