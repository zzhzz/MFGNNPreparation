#include <stdio.h>
int main()
{
	int testcases;
	scanf("%d",&testcases);
	for(int c=1;c<=testcases;c++)
	{
		int n,a,b;
		scanf("%d",&n);
		int entry[n],count = 0;
		for(int e=0;e<n;e++)
		{
			scanf("%d",&entry[e]);
		}
		int index1 = -1,index2 = -1;
		for(a=0;a<n-1;a++)
		{
			if(entry[a]>entry[a+1])
			{
				index2 = a;
				count = count+(index2-index1)*(index2-index1+1)/2;
				index1 = a;
			}
		}
		if(index2!=(n-1))
		{
		    index1 = index2;
		    index2 = n-1;
		    count = count+(index2-index1)*(index2-index1+1)/2;
		}
		printf("%d\n",count);
	}
}