#include <stdio.h>
 
int main()
{
 int a[10],i,j,t,n,k=0,count=0;
 int temp=0;
 scanf("%d\n",&t);
 for(i=0;i<t;i++)
 {
    scanf("%d\n",&n);
    for(j=0;j<n;j++)
    {
        scanf("%d ",&a[j]);
    }
    count=n;
    for(j=k;j<n-1;)
    {
        temp = 0 ;
        for(k=j;k<n-1;)
        {
           
          if(a[k]<a[k+1])
          {
            temp = temp + 1;
            k++;
          }
          else
          {
            k++;
            break;
          }
        }
        count = count + ((temp*(temp+1))/2);
        j=k;
    } 
    printf("%d",count);
 }
 return 0;
 }    