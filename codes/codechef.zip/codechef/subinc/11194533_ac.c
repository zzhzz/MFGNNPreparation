#include <stdio.h>
#include <stdlib.h>

int main(){

	long long int i,j,t,k,n,count=0;

	scanf("%lld",&t);

	while(t--){

		scanf("%lld",&n);
		long long int arr[n];

		for(i=0;i<n;i++)
			scanf("%lld",&arr[i]);

		for(i=0;i<n;i++){
			k=i+1;
			j=i;
			while(arr[j]<=arr[k] && k<n){
				j++;
				k++;
				count++;
			}
		}
		printf("%lld\n",(count+n));
		count=0;
	}
}