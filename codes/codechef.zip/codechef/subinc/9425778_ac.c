#include<stdio.h>
long long int count1(int n)
{
	return ((n+1)*n)/2;
}
int main()
{
	int n,i,t,flag;
	scanf("%d",&t);
	while(t--)
	{
				
			scanf("%d",&n);
			unsigned long int a[n];
			for(i=0;i<n;i++)
			{
				scanf("%lu",&a[i]);
			}
			long long int ans;
			ans=0;
			int count=1;
			for(i=0;i<n-1;i++)
			{
				
				if(a[i]<a[i+1])
				{
					count++;
					flag=0;
				}
				else
				{
					ans=ans+count1(count);
					count=1;
					flag=1;
				}
			}
			if(flag==0)
			{
				ans=ans+count1(count);
			}
			else
			ans=ans+1;
			printf("%lld\n",ans);
	}
	return 0;
}