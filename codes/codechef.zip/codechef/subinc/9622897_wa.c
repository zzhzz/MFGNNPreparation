#include <stdio.h>

int main(void) {
	// your code goes here
	int t,n,i;int long count; scanf("%d",&t);
	while(t--)
	{
	    count=0;
	    scanf("%d",&n);
	   long int a[n+1];
	    for(i=1;i<=n;i++)
	    {
	        scanf("%ld",&a[i]);
	    }
	      for(i=1;i<=n;i++)
	      {
	    if(a[i]<=a[i+1]||a[i]==a[i+1])
	    {
	        count++;
	    }
	    }
	    count=count+n;
	    printf("%ld\n",count);
	}
	return 0;
}
