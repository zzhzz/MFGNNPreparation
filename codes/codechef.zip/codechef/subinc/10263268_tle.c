#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t;
    scanf("%d",&t);

    int i;
    long int j;
    long int k;

    long int n;
    long int a[105000];
    long long int s=0;

    for(i=0;i<t;i++){

       scanf("%d",&n);

       for(j=0;j<n;j++){

            scanf("%d",&a[i]);

       }
       s=n;

       for(j=0;j<n-2;j++){

            for(k=j;k<n-1;k++){


                if(a[k+1] >= a[k]){

                    s++;

                }else{

                    break;

                }

            }



       }

      printf("%lld\n",s);

    }


    return 0;
}
