#include <stdio.h>
#include <stdlib.h>

long long int fact(int num) {
	if(num == 0) return 1;
	else return num * fact(num-1);
}

int main(void) {
	int t, n, i, top, lb, ub, *a, *inc;
	long long int cnt;
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		cnt = n;
		top = 0;
		a = (int*) malloc(n*sizeof(int));
		inc = (int*) malloc(n*sizeof(int));
		for(i=0 ; i<n ; i++) {
			scanf("%d", &a[i]);
			if(i==0) lb = ub = 0;
			else if(a[i] > a[i-1]) ub++;
			else if(lb != ub) {
				inc[top++] = lb;
				inc[top++] = ub;
				lb = ub = i;
			}
		}
		if(lb < ub) {
			inc[top++] = lb;
			inc[top++] = ub;
		}
		inc[top] = -1;
		/*
		for(i=0 ; inc[i]+1 ; i++) printf("%d ", inc[i]);
		printf("\n");
		*/
		for(i=0 ; inc[i]+1 ; i+=2) cnt += fact(inc[i+1] - inc[i]);
		printf("%lld\n", cnt);
		free(inc);
		free(a);
	}
	return 0;
}
