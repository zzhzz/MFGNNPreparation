#include <stdio.h>
#include <stdlib.h>

int main()
{
	long long int i,j,t,count1,s;
	long int *A[5];
	long int N[5];

	scanf("%d",&t);

	for(i=0;i<t;i++)
	{
		scanf("%d",&N[i]);
		A[i] = (long int *) malloc(N[i] * sizeof(long int));
		for(j=0;j<N[i];j++)
		{
			scanf("%ld",&A[i][j]);
		}
        count1=0; s=1;
		for(j=1;j<N[i];j++)
		{
			if(A[i][j]<=A[i][j+1])
			{
				s++;
			}
			else s=1;
			count1+=s;
		}

		printf("%lld\n",count1+1);
	}

	return 0;
}
