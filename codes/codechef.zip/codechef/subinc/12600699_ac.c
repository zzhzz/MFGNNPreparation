#include<stdio.h>
int main()
{
    int i,j,t,n,c=0,sum=0;
    scanf("%d",&t);
    for(i=1;i<=t;++i)
    {
        scanf("%d",&n);
        int a[n];
        for(j=0;j<n;++j)
            scanf("%d",&a[j]);
        for(j=0;j<n-1;++j)
        {
               if(a[j]<=a[j+1])
               {
                 ++c;
                 sum+=c;
               }
               else{
                c=0;
               }
        }
        printf("%d\n",sum+n);
        c=0;sum=0;
    }
    return 0;
}
