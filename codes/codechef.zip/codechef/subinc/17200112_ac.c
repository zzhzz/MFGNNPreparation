#include<stdio.h>
typedef long long int ll;
int main()
{
 ll n,i,j,t;
 scanf("%lld",&t);
 while(t--)
 {
  scanf("%lld",&n);
  ll p[100005],sum[100005],count=0,b=1;
  for(i=0;i<n;i++)
  {
  scanf("%lld",&p[i]);
  sum[i]=1;
  }
  for(i=1;i<n;i++)
  {
   if(p[i-1]<p[i])
   {
    sum[i]=sum[i-1]+1;
   }
  }
  for(i=0;i<n;i++)
  {
   count+=sum[i];
  }
  printf("%lld\n",count);
 }
 return 0;
}
