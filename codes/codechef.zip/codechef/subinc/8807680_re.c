#include<stdio.h>
#include<stdlib.h>
#define MAX 1000

void input(int a[],int n){
    int i;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
}

//void makeNew(int a[],int n)

int countSubArrays(int a[],int n){
    int i,j,c=0;
    for(i=0;i<n;i++){

        for(j=i;j<n;j++){
            c++;
            if(a[j]==a[n-1] || a[j]>a[j+1]){
            //if(a[j]>a[j+1]) break;
            //}
            break;}
            }

    }
return c;
}



int main(){
int a[MAX],n,t,ti;
scanf("%d",&t);
for(ti=0;ti<t;ti++){
    scanf("%d",&n);
    input(a,n);
    printf("%d\n",countSubArrays(a,n));
    //system("pause");
    //free(a);
}
return 0;
}
