#include<stdio.h>
main()
{
	int t;
	long n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		long long arr[n];
		long long sum=1;
		long i,j;
		for(i=0;i<n;i++)
		scanf("%lld",&arr[i]);
		long long arr2[n];
		arr2[0]=1;
		for(i=1;i<n;i++)
		{
			if(arr[i]>=arr[i-1])
			arr2[i]=arr2[i-1]+1;
			else
			arr2[i]=1;
			sum=sum+arr2[i];
		}
		
		printf("%lld\n",sum);
	}
}
		