#include<stdio.h>

void main()
{
 int t,c,i,j,k;long n;long long int  a[10000];

 scanf("%d",&t);

 while(t--)
 {
 scanf("%ld",&n);
 c=n;


 for(i=0;i<n;i++)
 scanf("%lld",&a[i]);

  for(k=0;k<n-1;k++)
  {
    j=k;
    while(j<=n)
    {
	if(a[j]<a[j+1])
	{
	c++;j++;
	}
	else
	break;

    }
  }
  printf("%d",c);
 }
}