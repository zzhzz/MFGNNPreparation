#include<stdio.h>
int main()
{
int i,j,tc,num,prev,curr,temp;
long long count=1;
scanf("%d",&tc);

for(i=1; i<=tc; i++)
{
	scanf("%d",&num);
	for(j=1; j<=num; j++)
	{
		if(j==1)scanf("%d",&prev);
		else{
		scanf("%d",&curr);
			if(prev>curr)temp=j;
			else
			count+=(j-temp+1);
		}
	}
	printf("%lld",count);
}
}