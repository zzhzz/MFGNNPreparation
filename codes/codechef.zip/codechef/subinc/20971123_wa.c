#include<stdio.h>
int main()
{
	int t;
	scanf("%d", &t);
	while(t--)
	{
		int n;
		scanf("%d", &n);
		int a[n], i, j;
		for(i=0; i<n; i++)
			scanf("%d", &a[i]);
		int count=0, pi=-1;
		for(i=0; i<n-1; i++)
		{
			if(a[i]<=a[i+1])
			{
				if(pi==-1)
					pi=i;
				continue;
			}
			else
			{
				//printf("%d %d\n", pi, i);
				int numOf = i-pi;
				count += (numOf*(numOf+1))/2;
				pi=-1;
			}
		}
		if(pi!=-1)
		{
			//printf("%d %d\n", pi, i);
			int numOf = i-pi;
			count += (numOf*(numOf+1))/2;
			pi=-1;
		}
			printf("%d\n", count+n);
	}
}