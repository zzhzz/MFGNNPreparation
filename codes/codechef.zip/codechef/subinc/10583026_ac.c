#include <stdio.h>
#include <stdlib.h>

int main()
{
   int t;
   scanf("%d",&t);
   while(t--)
   {
       int n;
       scanf("%d",&n);
       int a[n],i,j,c=0;
       for(i=0;i<n;i++)
        scanf("%d",&a[i]);
        int r=1;
       for(i=0;i<(n-1);i++)
       {
           if(a[i+1]>=a[i])
            r++;
           else
           {
             c+=(r*(r+1))/2;
             r=1;
           }
       }
        c+=(r*(r+1))/2;
       printf("%d\n",c);
   }
    return 0;
}
