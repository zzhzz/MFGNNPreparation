#include<stdio.h>

int main(){
	int got2=0,x,z,got=0,i,j,b,got1=0,c;
	printf("No. of testcases:");
	scanf("%d",&x);
	for(c=0; c<x; c++){
		got1=0;
		printf("\n");
		scanf("%d",&z);
		int array[z];
		for(b=0; b<z; b++)
			scanf("%d",&array[b]);
		for (i=0; i<z; i++){
			got = 0;
			got2 = 0;
			for(j=i+1; j<z; j++){
				if (array[j] == array[i]){
					if(j>(i+1)){
						if(array[j-1] > array[j]) 
							break;
						got2++;
					}
					else if(j == (i+1))
						got2++;
				}
				else if (array[j] >= array[i]){
					if(j>(i+1)){
						if(array[j-1] > array[j]) 
							break;
						got++;
					}
					else if(j == (i+1))
						got++;
				}
				else
					break;
			}
			got1 = got1 + got2 + got;
		}	
		printf("%d",z+got1);
	}
}

