#include <stdio.h>
#include <stdlib.h>

void code()
{
    int n,i,j;
    long int k;
    scanf("%d",&n);
    long long int a[n];
    k=0;
    for(i=0;i<n;i++)
    {
        scanf("%lld",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i;j<n;j++)
        {
            if(a[j+1]>=a[j]&&(j+1)<n)
            k++;
            else
            break;
        }
    }
    printf("%ld\n",k+n);
    return;


}

int main()
{
    int t,i;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        code();
    }
    return 0;
}
