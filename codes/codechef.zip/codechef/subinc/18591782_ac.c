#include<stdio.h>
int main()
{
	int T,N,j,i;
	scanf(" %d",&T);
    if(T>=1 && T<=5)
    {
    for(j=0;j<T;j++)
	{
		scanf(" %d",&N);		
			int a[N],sum=N,k;
			for(i=0;i<N;i++) scanf(" %d",&a[i]);

			for(i=0;i<N-1;i++)
			{ 
			    
				for(k=i+1;k<N;k++)
				{
					if(a[k]>=a[k-1]) sum=sum+1;
					else break;
				}
			if(i==0 && k==N) 
			{
			sum=((N*N)+N)/2;
			break;
		    }
			}
			printf("%d\n",sum);
		
		
	}
	}
}