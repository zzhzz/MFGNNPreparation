#include<stdio.h>
int main(){
int a[100];
int t,i,n,j,k;
scanf("%d",&t);
for(i=0;i<t;i++)
{
scanf("%d",&n);
for(j=0;j<n;j++)
{
    scanf("%d",&a[j]);
}
if(n%2==0)
{
    k=2*n-2;
}
else
{
    k=2*n-1;
}
printf("%d",k);
}
return 0;
}
