#include <stdio.h>

int main(void) {
	long long int t,n,a[100],i,j,sum,product,count,x,sort;
	scanf("%lld",&t);
	while(t--){
	    scanf("%lld",&n);count=0;
	    for(i=0;i<n;i++){ scanf("%lld",&a[i]);}
	    for(i=0;i<n;i++){
	        for(j=i;j>=0;j--){
	            for(x=j;x<i;x++){if(a[x]>a[x+1]){break;}}
	            if(x==i){count++;}
	        }
	    }
	    printf("%lld\n",count);
	}
	return 0;
}