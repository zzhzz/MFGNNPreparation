#include <stdio.h>
int main(void)
{
int i,n;
long t,a[1000],l;
scanf("%ld",&t);
while(t--)
{
l=0;    
scanf("%d",&n);
for(i=0;i<n;i++)
scanf("%d",&a[i]);
for(i=0;i<=n-1;i++)
{
if(a[i]<a[i+1])
l++;
}
if(n==1)
printf("%d\n",n);
else
printf("%d\n",l+n);
}
	return 0;
}