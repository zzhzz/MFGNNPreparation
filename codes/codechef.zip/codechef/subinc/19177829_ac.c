#include<stdio.h>
int main()
{long int t,n,i,j,k,d,c;
scanf("%ld",&t);
for(i=0;i<t;i++)
{scanf("%ld",&n);
long int a[n];
c=0;
for(j=0;j<n;j++)
{scanf("%ld",&a[j]);
}
a[j]=0;
d=0;
for(k=0;k<n;k++)
{
    if(a[k+1]>=a[k])
   {d=d+1;
 
   }
    else
    {d++;
    c+=(d*(d-1))/2;
    d=0;
    
    }
}
c=c+n;
printf("%d\n",c);
}
}  