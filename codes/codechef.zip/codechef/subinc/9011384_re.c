#include<stdio.h>
int main(void)
{
    unsigned long int t,n,*a,i,j,k,r[5],l,p;
    scanf("%lu",&t);
    for(i=0;i<t;i++)
    {
                    r[i]=0;
                    scanf("%lu",&n);
                    for(j=0;j<n;j++)
                                 scanf("%lu",&a[j]);
                    for(k=1;k<n-1;k++)
                    {
                                      for(l=0;l<n-k;l++)
                                      {
                                                        p=1;
                                                        for(j=l;j<l+k;j++)
                                                        {
                                                                          if(j+1==n)
                                                                          {
                                                                                    p=0;break;
                                                                          }
                                                                          if(a[j]<=a[j+1])
                                                                          continue;
                                                                          else
                                                                          {
                                                                              p=0;break;
                                                                          }
                                                        }
                                                        if(p==1)
                                                        r[i]++;
                                      }
                    }
                    r[i]=r[i]+n;
    }
    for(i=0;i<t;i++)
    printf("%lu\n",r[i]);
    return 0;
}
                                     
