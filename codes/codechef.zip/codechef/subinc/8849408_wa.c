#include<stdio.h>

int main()
{
    int t,i,j;
    long long int c;
    long int n;
    scanf("%d",&t);

    while(t--)
    {
        scanf("%ld",&n);
        int a[n];
        c=0;
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);

        for(i=0;i<n;i++)
        {
            j=i;
            if(n==1)
            {
            c++;
            break;
            }
            if(a[j]<=a[j+1])
            {
                j++;
                c++;
            }
            if(i!=j)
                c++;
        }

        printf("%lld\n",c);

    }
    return 0;
}
