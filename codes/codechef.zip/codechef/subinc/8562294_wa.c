#include<stdio.h>

void main()
{
	int N, i, T,k, n,s, j;

	scanf("%d", &T);
	int Sum[T+1];
	for(k=1; k<= T; k++)
    {
	scanf("%d", &N);

	int A[N+1];
	A[0]=0;
	for(i=1; i<=N; i++)
		scanf("%d", &A[i]);

	s=0;

	for(i=1; i<=N; )
	{
		for(j=i+1; j<=N; j++)
        {
           if(A[j] < A[j-1])
				break;
        }

		n=j-i;
		s = s + n*(n+1)/2;
		i=j;
	}
        Sum[k]=s;

    }

    for(k=1; k<=T; k++)
        printf("\n%d", Sum[k]);
}
