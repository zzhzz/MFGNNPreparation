#include <stdio.h>
 
int main(void) {int t,m,i,j,k,h=0,r,l;
    scanf("%d",&t);
    long int n;
    for(i=0;i<t;i++)
    {   m=0;
        n=0;
        scanf("%ld",&n);
       long int ar[n];
        for(k=0;k<n;k++)
        {scanf("%ld",&ar[k]);
        }
        for(j=1;j<n;j++)
        {  if(ar[j-1]<ar[j])
            m++;
        }
        if(n==1)
        printf("%d",n);
        else
        {for(r=0;r<n;r++)
        {for(l=r+1;l<n;l++)
        {if(ar[r]==ar[l])
        h++;
        }
        }
        printf("\n%d\n",m+n-h);
        
        }}return 0;
}