#include<stdio.h>
#include<stdlib.h>

void sub(int *a,int n)
{   int i;
    long long int count,len;
    len=1,count=0;

    for(i=0;i<n-1;i++)
    {
        if(a[i+1]>=a[i])///non decreasing
            len++;
        else
        {
            count+=(len*(len-1))/2;
            len=1;
        }
    }
    if(len>1)
        count+=(len*(len-1))/2;
    printf("%lld\n",(count+n));

}



int main()
{
	int *a,t,n,i;
	scanf("%d",&t);
	while(t--)
	{  int count=0;
		scanf("%d",&n);
		a=malloc(n*sizeof(int));
		for(i=0;i<n;i++)
		scanf("%d",&a[i]);
		sub(a,n);

		}
return 0;
}



