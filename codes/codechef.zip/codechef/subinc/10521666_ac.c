#include <stdio.h>
#include<math.h>
#include<string.h>
int main ()
{
   int i,j,k,n,t,c,d,l;
   int A[100000];
   scanf("%d",&t);
   for(i=1;i<=t;i++)
   {
       scanf("%d",&n);
       for(j=0;j<n;j++)
       {
           scanf("%d",&A[j]);
       }
       d=0;
       for(j=0;j<n;j++)
       {
           for(k=j+1;k<n;k++)
           {
               c=0;
               for(l=j;l<k;l++)
               {
                   if(A[l+1]>=A[l])
                   c++;
                   else
                   break;
               }
               if(c==(k-j))
               d++;
               else
               break;
           }
       }
       printf("%d\n",d+n);
   }
   
   	return 0;
}
