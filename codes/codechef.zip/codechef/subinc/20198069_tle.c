#include<stdio.h>
#include<string.h>
int main()
{
int t,c;
long int n,i,j,k;
scanf("%d",&t);
for(i=1;i<=t;i++)
{
    c=0;
    scanf("%ld",&n);
    long long int a[n];
    for(j=0;j<n;j++)
    {
        scanf("%lld",&a[j]);
    }
    
    for(j=0;j<n;j++)
    {
        for(k=0;k<n;k++)
        {
            if(j==k)
                c++;
            else if(a[j]<a[k] && a[k]-a[j]==1 )
               c++;
                    
        }
        
    }
    if(n==1)
    printf("%d\n",c);
    else
    printf("%d\n",c-1);
    
}
     return 0;
}