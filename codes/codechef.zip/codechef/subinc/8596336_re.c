#include<stdio.h>
int sub_count(int total)
{
	int ans=0,total_ans=0,l,i;
	for(l=2;l<total+1;l++)
	{
		//ans=0;
		ans=total-l+1+ans;
		/*for(i=0;i<total;i++)
		{
			if(i+l<total+1)
				ans++;
		}*/
		//total_ans=ans+total_ans;
		//printf("%d\n",ans);
	}
	//printf("%d\n",total_ans);

	return ans;
}
int main()
{
   int t;
   scanf("%d",&t);
   while(t--)
   { 
   	int arr[1000],size,x,i;
   	scanf("%d",&size);
   	for(i=0;i<size;i++)
   	{
   		scanf("%d",&x);
   		arr[i]=x;
   	}
   	i=0;
   	int j,cnt=0,result=0,temp_ans;
   	while(1)
   	{
   		cnt=1;
   		for(j=i;j<size;j++)
   		{
   			if(arr[j]<arr[j+1])
   				cnt++;
   			else
   				break;
   		}
   		//printf("uijkj\n");
   		//printf("%d\n",cnt);
   		temp_ans=sub_count(cnt);
   		result=result+temp_ans;
   		i=j+1;
   		if(j==size-1)
   			break;
   	}
   	printf("%d\n",result+size);
   }
return 0;
}