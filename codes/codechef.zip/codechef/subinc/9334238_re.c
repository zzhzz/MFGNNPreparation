#include <stdio.h>
int main() 
{
	int t,n,a[10000],i,j,k;
	int flag=0;
	int temp;
	
	scanf("%d",&t);
	if(t>5)
	exit(0);
	for(i=0;i<t;i++)
	{
		scanf("%d",&n);
		if(n<1)
		exit(0);
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[j]);
		}
		
		for(j=0;j<n;j++)
		{
			temp = a[j];
			for(k=j;k<n;k++)
			{
				if(temp<=a[k])
				{
					flag++;
					temp = a[k];
				}
				else 
				break;
			}
			
		}
		printf("%d",flag);
	}
	return 0;
}