#include<stdio.h>
int main ()
{
	int t,i,j=0,k,count;
	scanf("%d", &t);
	for (i=1 ; i<=t ; i++)
	{
		int n;
		scanf("%d", &n);
		
		int arr1[n];
		for (j=0 ; j<n ; j++)
		{
			scanf("%d", &arr1[j]);
			count = 0;
		}
		for(j=0 ; j<n ; j++)
		{
			for (k=j ; k<n; k++)
			{
				if(arr1[j] <= arr1[k])
				{
					
				if(arr1[k] > arr1[k+1])
				count = count + 1;
				}	
			}	
		}
		printf("%d", count);
		
	}
	return 0;
}
