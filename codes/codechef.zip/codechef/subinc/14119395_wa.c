#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    int t,i,flag=0;
    scanf("%d",&t);
    long long n,arr[100005],j,k,count,total;
    for(i=0;i<t;i++)
    {
    	scanf("%lld",&n);
    	
    	for(j=0;j<n;j++)
    	{
    		scanf("%lld",&arr[j]);
		}
		
		flag=0;
		total=n;
		for(j=0;j<n-1;j++)
		{
			if(flag==0 && arr[j+1]>arr[j])
			{
				total++;
				flag=1;
			}
			else if(flag==1 && arr[j+1]>arr[j])
			{
				total=total+j+1;
				flag=1;
			}
			else
			flag=0;
		}
		printf("%lld\n",total);
	
    	
	}
   
	return 0;
}