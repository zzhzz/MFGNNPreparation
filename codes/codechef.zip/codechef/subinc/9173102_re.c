#include<stdio.h>
int main()
{
	int a[100],n,t,i,j,k,l,m,count=0;
	printf("enter the no of test");
	scanf("%d",&t);
	
	for(i=0;i<t;i++)
	{
		printf("enter the no of elements");
	    scanf("%d",&n);
	    printf("enter the elements");
		for(j=0;j<n;j++)
		{
		scanf("%d",&a[j]);
		printf(" %d ",a[j]);
	}
	for(m=0;m<n;m++)
	{
	 for(k=m,l=m+1;k<n,l<n;k++)
		{
		if(a[k]<a[l])
		{
			count++;
		}
		else
		break;
		
	}
}
		printf("no of subarray=%d",count+n);
}	
	
		return 0;
}
