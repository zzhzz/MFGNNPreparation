#include<stdio.h>
int main()
{
	int size,test,z=0;
	printf("\n enter the number of test cases");
	scanf("%d",&test);
	int a[100];
	if(test!=0)
	do
	{
	
	printf("\n enter the size of the array");
	scanf("%d",&size);
	
	int count,i,j;
	count=0;
	printf("\n enter the elements");
	for(i=0;i<size;i++)
	scanf("%d",&a[i]);
	for(i=0;i<size;i++)
    { count++;
     int k=i;
    	for(j=k+1;j<size;j++)
    	{
    	 	
         if(a[k]<a[j])
    	 { 
		   count++;
	       k++;
        	}
		  else
		  break;

	   	}
    }
printf("%d",count);
z++;
}while(z<test);
return 0;
}