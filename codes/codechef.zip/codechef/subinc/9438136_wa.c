#include<stdio.h>
#include<stdlib.h>
int main()
{
    long i=1,j=1,n,count,num,prev,pres;
    printf("enter the size  of array and value of k\n ");
    scanf("%ld",&n);
    scanf("%ld",&num);
    prev=num;
    count=0;
    while(i<n)
    {
    
       scanf("%ld",&num);
       
       if(num>prev)
       {
          prev=num;
          j++;
          i++;
         
       }   
       else
       {
       prev=num;
       i++;
       count=count+j*(j+1)/2;
       j=1;
       
       }
   }
   count=count+j*(j+1)/2;
   printf("%ld",count);
   return 0;
   }
