#include<stdio.h>
#include<stdlib.h>
int main()
{
int t;
long int n,a[100000],i,j,c,p,q,f;
scanf("%d",&t);
while(t--)
{
scanf("%d",&n);

for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
c=0;
q=0;
f=0;
for(i=0;i<n-1;i++)
{
if(a[i]<a[i+1])
{
c++;
p=i;
for(j=p+1;j<n-1;j++)
{
if(a[j]<a[j+1])
{
c=c+2;
i++;
q++;
}
else
    break;
}
}
}
for(i=1;i<=q-1;i++)
{

    f=f+i;
}
printf("%d\n",c+n+f);
}
}
