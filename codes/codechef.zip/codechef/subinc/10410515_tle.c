#include<stdio.h>

main()
{
    int t,i,j,k,flag,min,x;
    long int n;
    long long int a[100000];

    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        flag=n;
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
        for(j=1;j<n;j++)
        {
            for(i=0;(i+j)<n;i++)
            {
               // min=a[i];
                x=0;
                for(k=0;k<j;k++)

                {
                    if(a[i+k]>a[i+(k+1)])
                        {
                            x=1;
                            break;
                        }
                }
                if(!x)
                    ++flag;
            }
        }
        printf("%d\n",flag);
    }
}
