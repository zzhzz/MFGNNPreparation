#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t,c,n,i,j,a[1000];
    scanf("%d",&t);
    while(t--)
    {
        c=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
     scanf("%d",&a[i]);
if(n==1)
c=1;
else
{
    for(i=0;i<n;i++)
    for(j=i+1;j<n;j++)
    {
    if(a[j]>=a[i]);
    c++;
    }
 }
    printf("%d\n",c);
    }
    return 0;
}