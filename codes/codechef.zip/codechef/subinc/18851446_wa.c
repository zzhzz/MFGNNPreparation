    #include<stdio.h>
    int main()
    {
        int t;
        scanf("%d",&t);
        while(t--)
        {
            long long int n,k,c=0,i,j;
            scanf("%lld",&n);
            c=n;
           long long int a[n];
            for(i=0; i<n; i++)
                scanf("%lld",&a[i]);

                for(j=i; j<n-1; j++)
                {
                    if (a[j]<=a[j+1])
                    {
                        c++;
                    }


                }

            printf("%lld\n",c);
        }
        return 0;
    }
