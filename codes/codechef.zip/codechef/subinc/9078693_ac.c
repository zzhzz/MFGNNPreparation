#include<stdio.h>
int main()
{
    int  t,count,n,i,k,j;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        count=0;
        scanf("%d",&n);
        long a[n];
        for(k=0;k<n;k++)
        scanf("%ld",&a[k]);
        for(j=0;j<n;j++)
        {
            for(k=j+1;k<n;k++)
            {
                if(a[k]>a[k-1])
                count+=1;
                if(a[k]<=a[k-1])
                break;
            }
        }
        printf("%d\n",count+n);
    }
    return 0;
}
