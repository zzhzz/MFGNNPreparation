#include<stdio.h>
#include <string.h>
#include<math.h>
    int main()
    {
        int t,i,l,temp,m,j,f,x,l1,n1,d,flag=0,c,n;
        long long int b,e,count;
        scanf("%d",&t);
        while(t--)
        {
            count=0;
            scanf("%d",&n);
            int a[n];
            for(i=0;i<n;i++)
                scanf("%d",&a[i]);
            for(i=0;i<n;i++)
            {
                j=i;
                while(a[i+1]>=a[i]&&i<n-1)
                    i++;

                    if(i!=j&&i<n)
                        {
                            e=i-j+1;
                            b=e*(e-1);
                            count+=b/2;
                        }
            }

            count+=n;



            printf("%lld\n",count);
        }

        return 0;
    }
