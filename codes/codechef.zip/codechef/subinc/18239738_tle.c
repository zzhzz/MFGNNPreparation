#include <stdio.h>
int sub(int a[],int e,int e1)
{
    int j,c1=0;
    for(j=e;j<e1;j++)
    {
       if(a[j]<a[j+1])
       {
           c1++;
       }
    }
    if(c1==(e1-e))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int main(void) {
	int n;
	scanf("%d",&n);
	while(n--)
	{
	    int m,c=0,s=0,k,b;
	    scanf("%d",&m);
	   int a[m],i;
	    for(i=0;i<m;i++)
	    {
	        scanf("%d",&a[i]);
	    }
	    if(m==1)
	        {
	            c++;
	            printf("%d\n",1);
	        }
	    for(k=1;k<=(m-1);k++)
	    {
	    for(i=0;i<m;i++)
	    {
	        if((i+k)<m)
	        {
	        b=sub(a,i,i+k);
	        s=s+b;
	        }
	    }
	    }
	   
	    if(c==0)
	    {
	        printf("%d\n",s+m);
	    }
	}
	return 0;
}

