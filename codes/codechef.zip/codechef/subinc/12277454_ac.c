#include<stdio.h>
int main()
{
 int t,n,i,k,x;
 long long sum;
 scanf("%d",&t);
 while(t--)
 {
  scanf("%d",&n);
  long int a[n];
  for(i=0;i<n;i++)
  scanf("%ld",&a[i]);
  sum=0;
   for(k=0;k<n-1;k++)
   { 
       x=k;
for(i=k+1;i<n;i++)
   { 
      
if(a[i]>=a[x])
     {
sum++;
 x=i;
  }
   else
   break;
   }
}
 printf("%lld\n",sum+n);
 
 }
 return 0;
}