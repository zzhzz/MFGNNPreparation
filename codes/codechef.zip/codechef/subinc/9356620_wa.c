#include<stdio.h>
void main()
{
unsigned int i,j,t,n,a[100000],nos;
scanf("%d",&t);
while(t--)
{
nos=0;
scanf("%d",&n);
for(i=0;i<n;i++)
    scanf("%d",&a[i]);
for(i=0;i<n;i++)
    {
        //printf("%d\n",(nos));
        if(j<n-1)
        for(j=i;j<n;)
        {
        if(a[j]<=a[j+1])
            {
                nos++;
                j++;
            }
        else
            break;
    }

    }
printf("%d",(nos+n));
}
}
