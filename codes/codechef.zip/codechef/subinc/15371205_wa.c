#include <stdio.h>

int main() 
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,i,j,k=0,m=0,d=0,f,b=0;
        scanf("%d",&n);
        int a[n];
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
            for(j=m;j<n;j++)
            {
                if(j==n-1&&a[n-1]-a[n-2]>=0)
                {
                    d=d+1;
                    break;
                }
                else if(j==n-1)
                break;
                else if(a[j+1]-a[j]>=0)
                k++;
                else if(a[j+1]-a[j]<0&&k==b)
                m=m+1;
                else if(a[j+1]-a[j]<0&&k!=b)
                {
                f=k-b;    
                d=d+(f*(f+1))/2;
                m=m+j;
                b=k;
                }
            }
        printf("%d\n",d+n);
    }
	return 0;
}

