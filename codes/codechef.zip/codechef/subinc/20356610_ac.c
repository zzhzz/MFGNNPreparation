#include <stdio.h>

int main()
{
	int t;
	int n;
	int a[100000];
	scanf("%d", &t);
	while(t--)
	{
		scanf("%d", &n);
		for(int i=0; i<n; i++)
			scanf("%d", &a[i]);
		int count = 0;
		for(int i=0; i<n; i++)
		{
			int temp = a[i];
			for(int j=i; j<n; j++)
			{
				if(a[j] >= temp){
					count ++;
					temp = a[j];
				}
				else
					break;
			}
		}
		printf("%d\n", count);
	}
	return 0;
}
