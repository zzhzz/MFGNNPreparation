#include<stdio.h>
#include<stdlib.h>
#include<string.h>
long long int wowop(long long int c)
{
    long long int sol=((c+1)*(c+2))/2;
    return sol;
}
int main()
{
  int t;
  scanf("%d",&t);
  while(t--){
    long long int N;
    scanf("%lld",&N);
    long long int A[N],k=0,ans=0;
    long long int y=0;
    while(y<N){
        scanf("%lld",&A[y]);
        y++;
    }
    long long int i=0;
    while(i<N){
        if(A[i]>A[i+1]){
            ans+=wowop(i-k);
            k=i;
        }
        else{ans=1;}
        i++;
    }
    ans+=wowop(N-2-k);
    printf("%lld",ans);
  }
    return 0;
}
