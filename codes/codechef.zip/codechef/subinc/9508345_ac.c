#include <stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long long int n,first=0,next=1,count=0,count1=0;
        scanf("%lld",&n);
        long long int a[n];
        long long int i,j;
        for(i=0;i<n;i++)
        {
            scanf("%lld",&a[i]);
        }
        for(i=0;i<n;i++)
        {
            first=i;
            next=i+1;
            count1++;
            if(next>n-1)
                break;
            while(a[first]<a[next])
            {
                first=next;
                next++;
                count++;
                if(next>n-1)
                {
                    break;
                }
            }
        }
        printf("%lld\n",count+count1);
    }
    return 0;
}
