#include<stdio.h>
int main()
{  int t,i=0,j=0;long long int a[100000],n,temp=0;
   scanf("%d",&t);
   while(t--)
   {
     scanf("%lld",&n);temp=0;
     for(i=0;i<n;i++)
     {
         scanf("%lld",&a[i]);
     }
      for(i=0;i<n-1;i++)
     {

         if(a[i+1]<a[i])
         {
          continue;
         }
         temp++;
     }
     printf("%lld\n",temp+n);
   }





    return 0;
}
