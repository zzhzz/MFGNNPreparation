#include <stdio.h>

int main(void) {
int t,n;  long int i,j=0,k=0,d=0,p;
scanf("%d",&t);
while(t--)
{
	scanf("%d",&n);
	long int a[n];
	for(i=0; i<n; i++)
	scanf("%ld",&a[i]);
	j=0;  d=0;
	for(i=0; i<n-1; i++)
	{
		if(a[i]<=a[i+1])
		j++;
		else
		{
			if(j>0)
			d=d+(j*(j+1))/2;  j=0;    
		}
		
	}
	if(j>0)
	d=d+(j*(j+1))/2;
	printf("%ld\n",d+n);
}// your code goes here
	return 0;
}
