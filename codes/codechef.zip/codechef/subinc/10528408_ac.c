#include<stdio.h>
#include<math.h>

int main()
{
    int t;
    long long int a[5][100001],n[5],count[5],i,j,l,k,b[5][100001],sum=0;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%li",&n[i]);
        for(j=0;j<n[i];j++)
        {
            scanf("%li",&a[i][j]);
            b[i][0] = 1;
                if(a[i][j] >= a[i][j-1] && j >= 1)
                {
                    b[i][j] = b[i][j-1] + 1;
                }
                else
                {
                    b[i][j] = 1;
                }
                //printf("%li\t",b[j]);
        }
        //printf("\n");
    }
    for(i=0;i<t;i++)
    {
        sum = 0;
        for(l=0;l<n[i];l++)
        {
            sum = sum + b[i][l];
        }
        printf("%li\n",sum);
    }
    return 0;
}
