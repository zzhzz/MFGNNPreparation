#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    long long int t,i,j;
    scanf("%d",&t);
    while(t>0)
    {   long long int x,y,z,l,p=0;
        scanf("%lld",&x);
        long long int a[100005];
        for(i=0;i<x;i++)
        {
            scanf("%lld",&a[i]);
        }
        for(i=0;i<x;i++)
        {
            for(j=i;j<x;j++)
            {   p++;
                if(a[j]>a[j+1])
                {
                    break;
                }
            }
        }
        printf("%lld\n",p);
    t--;
    }

}
