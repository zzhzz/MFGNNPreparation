#include<stdio.h>
#define  sf(n) scanf("%d",&n)
int main()
{
	int t;
	sf(t);
	while(t--)
	{
		int n,i,j,k,flag1=0,flag2=0,count=0,counti=0;
		sf(n);
		int a[n];
		for(i=0;i<n;i++)
		sf(a[i]);
		count+=n;
		/*
		for(i=0;i<n;i++)
		{
			//count++;
			for(j=i;j<n-1;j++)
			{
				if(a[j]<=a[j+1])
				count++;
				
				else
				break;
			}
		}
		*/
		for(i=0;i<n-1;i++)
		{
			if(a[i]<=a[i+1])
			{
				counti++;
				count+=counti;
			}
			else
			counti=0;
			
		}
		
		printf("%d\n",count);
	}
	
	return 0;
}