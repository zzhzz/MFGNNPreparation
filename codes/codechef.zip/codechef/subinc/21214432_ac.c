#include<stdio.h>

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        long long int n,i,len=0,count=1;
        scanf("%lld",&n);
        long long int a[n];
        for(i=0;i<n;i++)
            scanf("%lld ",&a[i]);
        for(i=0;i<n-1;i++){
            len += count;
            if(a[i+1]>a[i]){
                count++;
            }
            else{
                count=1;
            }
        }
        len += count;
        printf("%lld\n",len);
    }
    return 0;
}