#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t>0)
	{
		int n,i,b=-1,count=0,result=0,a;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d",&a);	
			if(a>=b)
			count++;
			else
			{
				result=result+count*(count+1)/2;
				count=1;
			}
			b=a;
		}
		result=result+count*(count+1)/2;
		printf("%d",result);
		t--;
	}
}
