#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        long long int n,s,i;
        s=0;
        scanf("%lld",&n);
        int a[n+1],b[n+1];
        for(i=1;i<=n;i++)
            scanf("%lld",&a[i]);
        b[n]=1;
        for(i=n-1;i>=1;i--)
        {
            b[i]=1;
            if(a[i]<=a[i+1])
                {
                   b[i]+=b[i+1];
                }
            s+=b[i];
        }
        printf("%lld\n",s);
    }
    return 0;
}
