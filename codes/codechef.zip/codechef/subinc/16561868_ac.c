#include<stdio.h>
int main()
{
  int i,j,t,a[1000000],l,cnt,n;
  scanf("%d",&t);
  while(t--)
  {
    cnt=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    
    for(i=0;i<n-1;i++)
    {l=a[i];
      for(j=1+i;j<n;j++)
      {
        if(l<=a[j])
        {
          cnt++;
          l=a[j];
        }
        else break;
      }
    }
    printf("%d\n",cnt+n);
  }
  return 0;
}