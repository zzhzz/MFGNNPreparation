#include<stdio.h>
 
int main() {
    int t;
    scanf("%d", &t);
    for(int i = 0; i < t; i++) {
        int n;
        scanf("%d", &n);
        int a[n], b[n];
        for(int j = 0; j < n; j++) scanf("%d", &a[j]);
        b[0] = 1;
        for(int j = 1; j < n; j++) {
            if(a[j - 1] <= a[j]) b[j] = b[j - 1] + 1;
            else b[j] = 1;
        }
        long int sum = 0;
        for(int j = 0; j < n; j++) {
            sum += b[j];
        }
        printf("%ld\n", sum);
    }
    return 0;
} 