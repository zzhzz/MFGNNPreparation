#include<stdio.h>
int main(void)
{
int t;
scanf("%d",&t);
while(t--)
{
    int n;
    scanf("%d",&n);
    long a[n];
    int i;
    for(i=0;i<n;i++)
    {
        scanf("%ld",&a[i]);
    }
    long dp[n];
    for(i=0;i<n;i++)
        dp[i]=1;
    for(i=1;i<n;i++)
    {
        if(a[i]>a[i-1])
            dp[i]=dp[i-1]+1;
    }
    long sum=0;
    for(i=0;i<n;i++)
        sum=sum+dp[i];
        printf("%ld\n",sum);
}


    return 0;
}
