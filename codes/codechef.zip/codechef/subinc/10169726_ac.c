#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t!=0)
    {
        long int i,n;
        scanf("%ld",&n);
        long int arr[n];
        for(i=0;i<n;i++)
        {
            scanf("%ld",&arr[i]);
        }
    int l = 0, r = 0;
    long int ans = 0;
    while (r < n)
    {
      if (r && arr[r] < arr[r - 1])
      l = r;
      r++;
      ans += r - l;
    }
    printf("%d\n",ans);
    t--;
  }
  return 0;
}
