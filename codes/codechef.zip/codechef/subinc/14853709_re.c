#include<stdio.h>
int main()
{
int a[100],t,n,i,count=0,ic=0;
scanf("%d",&t);
while(t--)
{
count=0;ic=0;
scanf("%d",&n);
for(i=0;i<n;i++)
{
    scanf("%d",&a[i]);
    if(i>0)
        {
            if(a[i]>a[i-1])
                {ic++;}
            else{
                if(ic){
                count++;
                ic=0;
                }
                }

        }

}
if(ic)
    count++;
count=count+n;
printf("%d\n",count);
}
return 0;
}
