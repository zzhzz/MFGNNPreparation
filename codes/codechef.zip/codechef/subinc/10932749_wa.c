#include<stdio.h>
#include<math.h>
int main(){
int t,i,j,p,n;
long long int sum;
scanf("%d",&t);
for(i=0;i<t;i++){
    sum=0;
    scanf("%d",&n);
    int a[n];
    for(j=0;j<n;j++){
        scanf("%d",&a[j]);
    }
    for(j=0;j<n;j++){
        p=1;
        while(j<n-1){
            if(a[j]>a[j+1]){
                break;
            }
            j++;
            p++;
        }
        sum+=(p*p-1)/2+p;
    }

 printf("%d\n",sum);
}
return 0;
}
