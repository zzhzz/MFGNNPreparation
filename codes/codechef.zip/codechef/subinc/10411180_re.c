#include<stdio.h>

main()
{
    int t,i,n,a[100000];
    long long int sum=0;

    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        int dp[n];
        for(i=0;i<n;i++)
            dp[i]=1;
        for(i=0;i<n;i++)
        {
            if(i>0)
            {
                if(a[i]>a[i-1])
                    dp[i]=dp[i]+dp[i-1];
                else
                    dp[i]=1;
            }
            sum+=dp[i];
        }
        printf("%lld",sum);
    }
}
