#include<stdio.h>
int main()
{
	long int a[100000],i,k,j,n,t,co=0;
	scanf("%d",&t);
	while(t)
	{
		co=0;
		scanf("%ld",&n);
     	for(i=0;i<n;i++)
     	 scanf("%ld",&a[i]);
     	for(i=0;i<n;i++)
		{  k=i;
		 for(j=i;j<n;j++)
		  { 
		 	if(a[j]>=a[k])
		 	{
		 	   co++;
		 	   k=j;
		    }
		 	else
			    break;   
	      }	
		}
		printf("\n%ld",co); 
    }
  return 0;
}