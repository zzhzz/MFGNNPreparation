#include <stdio.h>
int main()
{
    int t;int p;
    scanf("%d",&t);
    for(p=0;p<t;p++)
    {
        int n;
        scanf("%d",&n);
    int i;long long int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%lld",&a[i]);
    }
    long long int count=1;long long int sum=0;long long int sum1=1;
    for(i=0;i<n-1;i++)
    {
        if(a[i]<=a[i+1])
        {
        count++;
        sum1+=count;
        }
        else
        {
        sum+=sum1;
        count=1;
        sum1=1;
        }
    }
    sum+=sum1;
    printf("%lld\n",sum);
    }
    return 0;
}
  