#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        int i,count=0;
        long long int a[100000];
        for(i=0;i<n;i++)
        {
            scanf("%lld",&a[i]);
        }
        for(i=1;i<n;i++)
        {
            if(a[i]>a[i-1])
                count++;
        }
        printf("%d\n",count+n);
    }
	return 0;
}
