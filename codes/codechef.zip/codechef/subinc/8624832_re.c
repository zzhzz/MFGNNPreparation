#include<stdio.h>
int main()
{
 int i,j,k,n,a[100],count,l,t,temp,m,temp1;
scanf("%d",&t);
for(i=0;i<t;i++)
{
 scanf("%d",&n);
  for(j=0;j<n;j++)
    scanf("%d",&a[j]);
    count=0;
    for(k=0;k<n;k++)
    {
        for(l=k+1;l<n;l++)
        {
            if(a[k]>a[l])
            {
                temp=a[k];
                a[k]=a[l];
                a[l]=temp;
            }
        }
    }
     for(k=0;k<n;k++)
       {
           temp1=a[k];
        for(l=k;l<n;l++)
         {
           if(temp1==a[l]||temp1==a[l]+1||temp1==a[l]-1)
           {
           if(temp1!=0)
           {
            count++;
            a[l]=a[l]-1;
            }
           }
            }
       }
      
            printf("%d\n",count);
            }
            return 0;
            }
